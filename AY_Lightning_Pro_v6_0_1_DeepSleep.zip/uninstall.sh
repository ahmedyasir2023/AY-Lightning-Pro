#!/system/bin/sh
MODDIR=${YASIR_MODDIR:-${0%/*}}
AY_DATA_DIR=${AY_DATA_DIR:-/data/adb/ay_lightning}
if [ -r "$MODDIR/deep-lib.sh" ]; then
    . "$MODDIR/deep-lib.sh"
    ds_cancel || { echo "AY: Restore radios manually; deep restore failed: $DS_ERROR"; exit 1; }
fi
# Preserve the original release behaviour: stop our own monitor, which
# restores only values that are still under AY control.
if [ -r "$MODDIR/monitor.pid" ]; then
    pid=$(cat "$MODDIR/monitor.pid" 2>/dev/null)
    case "$pid" in ''|*[!0-9]*) : ;; *) kill "$pid" 2>/dev/null || : ;; esac
fi
# This directory is owned exclusively by this module. Removing it prevents
# stale configuration from unexpectedly applying on a later clean install.
PERSIST=${AY_DATA_DIR:-/data/adb/ay_lightning}
case "$PERSIST" in
  /data/adb/ay_lightning) rm -rf "$PERSIST" 2>/dev/null || : ;;
esac
