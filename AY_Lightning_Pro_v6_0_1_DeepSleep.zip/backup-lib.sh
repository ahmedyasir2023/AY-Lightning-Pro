#!/system/bin/sh
# Fixed-slot settings backups. CPU baselines and root secrets are never included.
backup_slot_valid() { case "$1" in 1|2|3) return 0;; *) return 1;; esac; }
backup_root() { printf '%s/backups' "$AY_DATA_DIR"; }
backup_list() {
    for b_slot in 1 2 3; do
        b_dir="$(backup_root)/slot$b_slot"
        if [ -s "$b_dir/config.conf" ] && [ -s "$b_dir/safety.conf" ]; then
            b_date=$(cat "$b_dir/saved.at" 2>/dev/null)
            b_profile=$(cat "$b_dir/profile.id" 2>/dev/null)
            printf 'BACKUP|%s|%s|%s\n' "$b_slot" "${b_date:-unknown}" "${b_profile:-custom}"
        else
            printf 'BACKUP|%s|empty|none\n' "$b_slot"
        fi
    done
}
backup_save() {
    backup_slot_valid "$1" || return 1
    mkdir -p "$(backup_root)" || return 1
    chmod 700 "$(backup_root)" 2>/dev/null || :
    b_temp="$(backup_root)/.slot$1.$$"
    mkdir -m 700 "$b_temp" || return 1
    cp -f "$MODDIR/config.conf" "$b_temp/config.conf" || { rm -rf "$b_temp"; return 1; }
    cp -f "$MODDIR/safety.conf" "$b_temp/safety.conf" || { rm -rf "$b_temp"; return 1; }
    [ ! -s "$AY_DATA_DIR/profile.id" ] || cp -f "$AY_DATA_DIR/profile.id" "$b_temp/profile.id"
    for b_f in "$AY_DATA_DIR"/freq.policy*; do
        [ -s "$b_f" ] || continue
        cp -f "$b_f" "$b_temp/" || { rm -rf "$b_temp"; return 1; }
    done
    date '+%Y-%m-%d %H:%M' > "$b_temp/saved.at"
    b_dest="$(backup_root)/slot$1"
    rm -rf "$b_dest"
    mv -f "$b_temp" "$b_dest" || return 1
    return 0
}
backup_validate() {
    backup_slot_valid "$1" || { BACKUP_ERROR=bad_slot; return 1; }
    b_dir="$(backup_root)/slot$1"
    [ -s "$b_dir/config.conf" ] && [ -s "$b_dir/safety.conf" ] || { BACKUP_ERROR=empty_slot; return 1; }
    # Backup files are only created by root backend but still validate every loaded value.
    b_mode=$(sed -n 's/^MODE=//p' "$b_dir/config.conf" | head -n1)
    b_on=$(sed -n 's/^ON_GOVERNOR=//p' "$b_dir/config.conf" | head -n1)
    b_off=$(sed -n 's/^OFF_GOVERNOR=//p' "$b_dir/config.conf" | head -n1)
    b_poll=$(sed -n 's/^POLL_SECONDS=//p' "$b_dir/config.conf" | head -n1)
    allowed_mode "$b_mode" && allowed_gov "$b_on" && allowed_gov "$b_off" && valid_interval "$b_poll" || { BACKUP_ERROR=invalid_config; return 1; }
    b_bat=$(sed -n 's/^LOW_BATTERY=//p' "$b_dir/safety.conf" | head -n1)
    b_temp=$(sed -n 's/^HIGH_TEMP=//p' "$b_dir/safety.conf" | head -n1)
    case "$b_bat" in off|15|20|25|30) : ;; *) BACKUP_ERROR=invalid_battery; return 1;; esac
    case "$b_temp" in off|40|42|45|48) : ;; *) BACKUP_ERROR=invalid_temp; return 1;; esac
    for b_f in "$b_dir"/freq.policy*; do
        [ -e "$b_f" ] || continue
        b_n=${b_f##*/}; b_n=${b_n#freq.}
        read -r b_min b_max < "$b_f" || { BACKUP_ERROR=invalid_limits; return 1; }
        freq_validate_pair "$b_n" "$b_min" "$b_max" || { BACKUP_ERROR="limits_$b_n:$FREQ_ERROR"; return 1; }
    done
    if [ -s "$b_dir/profile.id" ]; then
        b_prof=$(cat "$b_dir/profile.id")
        case "$b_prof" in extreme|normal|adaptive|quiet|ultra|smart|gaming|charging|stability|custom|manual|off) : ;; *) BACKUP_ERROR=invalid_profile; return 1 ;; esac
    fi
}
backup_import() {
    b_dir="$(backup_root)/slot$1"
    cp -f "$b_dir/config.conf" "$MODDIR/config.conf" || return 1
    cp -f "$b_dir/safety.conf" "$MODDIR/safety.conf" || return 1
    cp -f "$b_dir/config.conf" "$AY_DATA_DIR/config.conf" || return 1
    cp -f "$b_dir/safety.conf" "$AY_DATA_DIR/safety.conf" || return 1
    rm -f "$AY_DATA_DIR"/freq.policy*
    for b_f in "$b_dir"/freq.policy*; do
        [ -e "$b_f" ] || continue
        cp -f "$b_f" "$AY_DATA_DIR/" || return 1
    done
    if [ -s "$b_dir/profile.id" ]; then
        cp -f "$b_dir/profile.id" "$AY_DATA_DIR/profile.id" || return 1
    else
        rm -f "$AY_DATA_DIR/profile.id"
    fi
}
