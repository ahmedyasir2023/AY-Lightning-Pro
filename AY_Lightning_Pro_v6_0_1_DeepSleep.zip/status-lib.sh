#!/system/bin/sh
# AY Lightning Pro - live KernelSU Next module card description.
# Sourced by control.sh and monitor.sh; no new background daemon.
# Does not touch CPU governors or thermal controls.

ay_profile_name() {
    case "${MODE:-off}" in
        off) printf 'متوقف' ;;
        performance) printf 'يدوي - أقصى أداء' ;;
        powersave) printf 'يدوي - توفير الطاقة' ;;
        schedutil) printf 'يدوي - متوازن' ;;
        auto)
            ay_selected=$(gov_read "$AY_DATA_DIR/profile.id" 2>/dev/null)
            case "$ay_selected" in
                stability)
                    [ "$ON_GOVERNOR" = schedutil ] && [ "$OFF_GOVERNOR" = powersave ] && [ "$SAFE_BATTERY" = 25 ] && [ "$SAFE_TEMP" = 40 ] && { printf 'الثبات'; return; } ;;
                extreme|normal|quiet|ultra)
                    if [ "$SAFE_BATTERY" = off ] && [ "$SAFE_TEMP" = off ] && [ "$OFF_GOVERNOR" = powersave ]; then
                    case "$ay_selected:$ON_GOVERNOR" in
                        extreme:performance) printf 'الأقصى'; return ;;
                        normal:schedutil) printf 'العادي'; return ;;
                        quiet:conservative) printf 'الهادئ'; return ;;
                        ultra:powersave) printf 'التوفير الشديد'; return ;;
                    esac
                    fi ;;
            esac
            [ "$SAFE_BATTERY" = off ] && [ "$SAFE_TEMP" = off ] && [ "$OFF_GOVERNOR" = powersave ] || { printf 'مخصص'; return; }
            case "${ON_GOVERNOR:-}" in
                performance) printf 'الأقصى' ;; schedutil) printf 'العادي' ;;
                conservative) printf 'الهادئ' ;; powersave) printf 'التوفير الشديد' ;; *) printf 'مخصص' ;;
            esac ;;
        *) printf 'مخصص' ;;
    esac
}

ay_cpu_actual() {
    AY_CPU_ACTUAL=unknown
    AY_CPU_COUNT=0
    for ay_pol in "$POLICY_ROOT"/policy*; do
        [ -r "$ay_pol/scaling_governor" ] || continue
        ay_cur=$(cat "$ay_pol/scaling_governor" 2>/dev/null) || continue
        # Whitelist sysfs result before including it in module metadata.
        case "$ay_cur" in
            performance|powersave|schedutil|ondemand|conservative|userspace) : ;;
            *) ay_cur=unknown ;;
        esac
        if [ "$AY_CPU_COUNT" -eq 0 ]; then
            AY_CPU_ACTUAL=$ay_cur
        elif [ "$AY_CPU_ACTUAL" != "$ay_cur" ]; then
            AY_CPU_ACTUAL=mixed
        fi
        AY_CPU_COUNT=$((AY_CPU_COUNT + 1))
    done
}

ay_desc_write_prop() {
    [ -f "$MODDIR/module.prop" ] || return 1
    [ -f "$MODDIR/remove" ] && return 1
    if grep -Fqx "description=$AY_DESCRIPTION" "$MODDIR/module.prop" 2>/dev/null; then
        return 0
    fi
    ay_tmp="$MODDIR/.module.prop.$$"
    # Copy all existing metadata except the old description (ID/version unchanged).
    ( umask 022
      sed '/^description=/d' "$MODDIR/module.prop" > "$ay_tmp" && \
      printf 'description=%s\n' "$AY_DESCRIPTION" >> "$ay_tmp"
    ) || { rm -f "$ay_tmp"; return 1; }
    chmod 644 "$ay_tmp" 2>/dev/null || :
    mv -f "$ay_tmp" "$MODDIR/module.prop" || { rm -f "$ay_tmp"; return 1; }
}

ay_desc_set_override() {
    # KernelSU Next supports override.description in module config on recent versions.
    # Explicit KSU_MODULE works even when invoked from Termux or the WebUI bridge.
    ay_ksud=${YASIR_KSUD:-}
    if [ -z "$ay_ksud" ]; then
        if command -v ksud >/dev/null 2>&1; then
            ay_ksud=$(command -v ksud)
        elif [ -x /data/adb/ksu/bin/ksud ]; then
            ay_ksud=/data/adb/ksu/bin/ksud
        else
            return 1
        fi
    fi
    KSU_MODULE=eng_ahmed_yasir_screen_gov "$ay_ksud" module config set override.description "$AY_DESCRIPTION" >/dev/null 2>&1
}

ay_update_description() {
    # $1 screen status ON/OFF/MANUAL/UNKNOWN, $2 safety reason, $3 expected governor.
    [ -f "$MODDIR/module.prop" ] || return 0
    [ -f "$MODDIR/remove" ] && return 0
    AY_SCREEN=${1:-UNKNOWN}
    AY_REASON_DISPLAY=${2:-normal}
    AY_EXPECTED=${3:-unknown}
    AY_PROF=$(ay_profile_name)
    ay_cpu_actual
    case "$AY_SCREEN" in
        ON) AY_SCREEN_LABEL='الشاشة تعمل' ;;
        OFF) AY_SCREEN_LABEL='الشاشة مطفأة' ;;
        MANUAL) AY_SCREEN_LABEL='تحكم يدوي' ;;
        *) AY_SCREEN_LABEL='حالة الشاشة غير معروفة' ;;
    esac
    case "$AY_REASON_DISPLAY" in
        deep_sleep) AY_SCREEN_LABEL='نوم عميق - الاتصالات مفصولة' ;;
        low_battery) AY_SCREEN_LABEL='حماية البطارية' ;;
        high_battery_temp|extreme_heat) AY_SCREEN_LABEL='حماية الحرارة' ;;
    esac
    ay_radio_state=$(ds_state 2>/dev/null)
    if [ "$ay_radio_state" = active ] || [ "$ay_radio_state" = entering ]; then
        AY_DESCRIPTION="☾ Deep Sleep Ultra: الاتصالات مفصولة حتى الإلغاء يدويًا | CPU: $AY_CPU_ACTUAL | Eng/ Ahmed Yasir"
    elif [ "${MODE:-off}" = off ]; then
        ay_sleep_auto_label='تلقائي بعد ساعة'
        ds_auto_options
        [ "$DS_AUTO" = 1 ] || ay_sleep_auto_label='تلقائي معطل'
        AY_DESCRIPTION="⏸️ البروفايل: متوقف | النوم: $ay_sleep_auto_label | CPU: $AY_CPU_ACTUAL | Eng/ Ahmed Yasir"
    elif [ "$AY_EXPECTED" != unknown ] && [ "$AY_CPU_ACTUAL" != "$AY_EXPECTED" ]; then
        AY_DESCRIPTION="⚠️ البروفايل: $AY_PROF | CPU: $AY_CPU_ACTUAL (غير مطابق) | $AY_SCREEN_LABEL"
    else
        AY_DESCRIPTION="⚡ البروفايل: $AY_PROF | CPU: $AY_CPU_ACTUAL | $AY_SCREEN_LABEL"
    fi
    # Update only on actual text changes. Both paths are used for version compatibility.
    if [ -f "$MODDIR/description.current" ] &&
       [ "$(cat "$MODDIR/description.current" 2>/dev/null)" = "$AY_DESCRIPTION" ] &&
       grep -Fqx "description=$AY_DESCRIPTION" "$MODDIR/module.prop" 2>/dev/null; then
        return 0
    fi
    # module.prop provides broad compatibility; override is the official dynamic API.
    ay_desc_write_prop || return 1
    ay_desc_set_override || :
    printf '%s\n' "$AY_DESCRIPTION" > "$MODDIR/description.current" 2>/dev/null || :
    return 0
}
