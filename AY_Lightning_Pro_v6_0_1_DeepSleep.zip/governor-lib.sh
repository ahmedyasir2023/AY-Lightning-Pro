#!/system/bin/sh
# AY Governor Control: shared sysfs helpers. Imported by control.sh and monitor.sh.
# The only sysfs write is scaling_governor. Never change clocks or thermal limits.
# Requires MODDIR and POLICY_ROOT to be set by the caller.

gov_read() {
    [ -r "$1" ] || return 1
    cat "$1" 2>/dev/null
}

gov_supported() {
    GOVERNOR_AVAILABLE=$(gov_read "$1/scaling_available_governors") || return 1
    case " $GOVERNOR_AVAILABLE " in
        *" $2 "*) return 0 ;;
    esac
    return 1
}

gov_write_verify() {
    # usage: gov_write_verify /sys/.../policy0 performance
    # sets GOV_WRITE_ERROR on failure. Use the same `echo >` command as manual root tests.
    GOV_WRITE_ERROR=
    gov_path="$1/scaling_governor"
    gov_wanted="$2"
    if [ ! -e "$gov_path" ]; then
        GOV_WRITE_ERROR=missing_governor_file
        return 1
    fi
    # sysfs `test -w` can be misleading under some root contexts. Try the write.
    if [ -w "$gov_path" ]; then writability=YES; else writability=NO; fi
    write_err=$( ( echo "$gov_wanted" > "$gov_path" ) 2>&1 )
    write_rc=$?
    if [ "$write_rc" -ne 0 ]; then
        # Flatten shell error messages so the status log always keeps one line.
        write_err=$(printf '%s' "$write_err" | tr '\n\r' '  ')
        GOV_WRITE_ERROR="write_rc=$write_rc;writable=$writability:${write_err:-unknown}"
        return 1
    fi
    attempt=0
    while [ "$attempt" -lt 4 ]; do
        observed=$(gov_read "$gov_path" 2>/dev/null)
        [ "$observed" = "$gov_wanted" ] && return 0
        attempt=$((attempt + 1))
        sleep 0.1
    done
    GOV_WRITE_ERROR="readback=${observed:-empty};wanted=$gov_wanted"
    return 1
}

gov_boot_id() {
    id=$(cat /proc/sys/kernel/random/boot_id 2>/dev/null)
    [ -n "$id" ] || id="btime-$(awk '/^btime / {print $2; exit}' /proc/stat 2>/dev/null)"
    [ -n "$id" ] || id=unknown
    printf '%s' "$id"
}

gov_capture_baseline() {
    # Keep the originally observed governors per boot. Reuse the baseline across restarts.
    boot=${YASIR_BOOT_ID:-$(gov_boot_id)}
    was=$(gov_read "$MODDIR/boot.id" 2>/dev/null)
    if [ "$was" != "$boot" ]; then
        rm -f "$MODDIR"/original.policy* "$MODDIR"/applied.policy*
        printf '%s\n' "$boot" > "$MODDIR/boot.id" || return 1
    fi
    captured=0
    for gov_pol in "$POLICY_ROOT"/policy*; do
        [ -r "$gov_pol/scaling_governor" ] || continue
        gov_name=${gov_pol##*/}
        if [ ! -r "$MODDIR/original.$gov_name" ]; then
            gov_read "$gov_pol/scaling_governor" > "$MODDIR/original.$gov_name" || return 1
        fi
        captured=$((captured + 1))
    done
    [ "$captured" -gt 0 ]
}
