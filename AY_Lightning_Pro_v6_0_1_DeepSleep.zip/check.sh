#!/system/bin/sh
MODDIR=${YASIR_MODDIR:-${0%/*}}
[ -r "$MODDIR/control.sh" ] || exit 1
sh "$MODDIR/control.sh" status
printf '\n--- LAST LOG ENTRIES ---\n'
sh "$MODDIR/control.sh" logs
