#!/system/bin/sh
# AY Lightning Pro v5: optional, per-policy CPU min/max limits.
# Never writes thermal nodes, voltage tables or values outside cpuinfo range.
# Custom limits only apply with the physical display ON. OFF restores observed boot limits.
FREQ_ROOT=${AY_FREQ_ROOT:-$AY_DATA_DIR}

freq_valid_policy() {
    case "$1" in policy*) freq_tail=${1#policy}; case "$freq_tail" in ''|*[!0-9]*) return 1;; esac;; *) return 1;; esac
    [ -d "$POLICY_ROOT/$1" ] && [ -r "$POLICY_ROOT/$1/scaling_min_freq" ] && [ -r "$POLICY_ROOT/$1/scaling_max_freq" ]
}
freq_uint() { case "$1" in ''|*[!0-9]*) return 1;; *) [ "$1" -gt 0 ] 2>/dev/null;; esac; }
freq_range_read() {
    F_CUR_MIN=$(gov_read "$1/scaling_min_freq") || return 1
    F_CUR_MAX=$(gov_read "$1/scaling_max_freq") || return 1
    freq_uint "$F_CUR_MIN" && freq_uint "$F_CUR_MAX"
}
freq_boot_prepare() {
    mkdir -p "$FREQ_ROOT" || return 1
    chmod 700 "$FREQ_ROOT" 2>/dev/null || :
    fb=$(gov_boot_id)
    fb_old=$(gov_read "$MODDIR/freq.boot.id" 2>/dev/null)
    if [ "$fb" != "$fb_old" ]; then
        rm -f "$MODDIR"/freq.original.policy* "$MODDIR"/freq.applied.policy*
        printf '%s\n' "$fb" > "$MODDIR/freq.boot.id" || return 1
    fi
    for fp in "$POLICY_ROOT"/policy*; do
        [ -r "$fp/scaling_min_freq" ] && [ -r "$fp/scaling_max_freq" ] || continue
        fn=${fp##*/}
        if [ ! -s "$MODDIR/freq.original.$fn" ]; then
            freq_range_read "$fp" || return 1
            printf '%s %s\n' "$F_CUR_MIN" "$F_CUR_MAX" > "$MODDIR/freq.original.$fn" || return 1
        fi
    done
}
freq_original() {
    [ -r "$MODDIR/freq.original.$1" ] || return 1
    read -r F_BASE_MIN F_BASE_MAX < "$MODDIR/freq.original.$1" || return 1
    freq_uint "$F_BASE_MIN" && freq_uint "$F_BASE_MAX" && [ "$F_BASE_MIN" -le "$F_BASE_MAX" ]
}
freq_hw_range() {
    F_HW_MIN=$(gov_read "$1/cpuinfo_min_freq" 2>/dev/null)
    F_HW_MAX=$(gov_read "$1/cpuinfo_max_freq" 2>/dev/null)
    freq_uint "$F_HW_MIN" && freq_uint "$F_HW_MAX" && [ "$F_HW_MIN" -le "$F_HW_MAX" ] || return 1
}
freq_available() {
    F_ALLOWED=$(gov_read "$1/scaling_available_frequencies" 2>/dev/null)
    # Some kernels omit the list; range validation and write verification are fallback.
    [ -n "$F_ALLOWED" ] || return 0
    case " $F_ALLOWED " in *" $2 "*) return 0;; esac
    return 1
}
freq_validate_pair() {
    fv_pol=$1; fv_min=$2; fv_max=$3
    freq_valid_policy "$fv_pol" || { FREQ_ERROR=unknown_policy; return 1; }
    freq_original "$fv_pol" || { FREQ_ERROR=baseline_missing; return 1; }
    min_is_stock=0; max_is_stock=0
    if [ "$fv_min" = stock ]; then fv_min=$F_BASE_MIN; min_is_stock=1; fi
    if [ "$fv_max" = stock ]; then fv_max=$F_BASE_MAX; max_is_stock=1; fi
    freq_uint "$fv_min" && freq_uint "$fv_max" || { FREQ_ERROR=invalid_number; return 1; }
    [ "$fv_min" -le "$fv_max" ] || { FREQ_ERROR=min_exceeds_max; return 1; }
    freq_hw_range "$POLICY_ROOT/$fv_pol" || { FREQ_ERROR=hardware_range_unavailable; return 1; }
    [ "$fv_min" -ge "$F_HW_MIN" ] && [ "$fv_max" -le "$F_HW_MAX" ] || { FREQ_ERROR=outside_hardware_limits; return 1; }
    if [ "$min_is_stock" -eq 0 ]; then
        freq_available "$POLICY_ROOT/$fv_pol" "$fv_min" || { FREQ_ERROR=unsupported_min_frequency; return 1; }
    fi
    if [ "$max_is_stock" -eq 0 ]; then
        freq_available "$POLICY_ROOT/$fv_pol" "$fv_max" || { FREQ_ERROR=unsupported_max_frequency; return 1; }
    fi
    F_TARGET_MIN=$fv_min; F_TARGET_MAX=$fv_max
}
freq_put() {
    ff_path=$1; ff_value=$2
    ff_err=$( ( printf '%s\n' "$ff_value" > "$ff_path" ) 2>&1 )
    ff_rc=$?
    if [ "$ff_rc" -ne 0 ]; then
        FREQ_ERROR="write_rc=$ff_rc:$(printf '%s' "$ff_err" | tr '\n|' '  ')"
        return 1
    fi
    ff_real=$(gov_read "$ff_path" 2>/dev/null)
    if [ "$ff_real" != "$ff_value" ]; then
        FREQ_ERROR="readback=$(printf '%s' "$ff_real" | tr '\n|' '  '):wanted=$ff_value"
        return 1
    fi
}
freq_write_pair() {
    # Safe ordering avoids transient min > max errors.
    fw_pol=$1; fw_min=$2; fw_max=$3
    freq_range_read "$fw_pol" || { FREQ_ERROR=read_failed; return 1; }
    [ "$F_CUR_MIN" = "$fw_min" ] && [ "$F_CUR_MAX" = "$fw_max" ] && return 0
    if [ "$fw_max" -gt "$F_CUR_MAX" ]; then
        freq_put "$fw_pol/scaling_max_freq" "$fw_max" || return 1
    fi
    if [ "$fw_min" -lt "$F_CUR_MIN" ]; then
        freq_put "$fw_pol/scaling_min_freq" "$fw_min" || return 1
    fi
    if [ "$fw_max" -lt "$F_CUR_MAX" ]; then
        freq_put "$fw_pol/scaling_max_freq" "$fw_max" || return 1
    fi
    if [ "$fw_min" -gt "$F_CUR_MIN" ]; then
        freq_put "$fw_pol/scaling_min_freq" "$fw_min" || return 1
    fi
    freq_range_read "$fw_pol" || return 1
    [ "$F_CUR_MIN" = "$fw_min" ] && [ "$F_CUR_MAX" = "$fw_max" ] || { FREQ_ERROR=final_readback_mismatch; return 1; }
}
freq_restore_one() {
    fr_n=$1
    freq_original "$fr_n" || return 0
    [ -s "$MODDIR/freq.applied.$fr_n" ] || return 0
    read -r fr_ap_min fr_ap_max < "$MODDIR/freq.applied.$fr_n" || return 0
    freq_range_read "$POLICY_ROOT/$fr_n" || return 1
    # Never overwrite changes made by a different kernel tuner since our last apply.
    if [ "$F_CUR_MIN" = "$fr_ap_min" ] && [ "$F_CUR_MAX" = "$fr_ap_max" ]; then
        freq_write_pair "$POLICY_ROOT/$fr_n" "$F_BASE_MIN" "$F_BASE_MAX" || return 1
        rm -f "$MODDIR/freq.applied.$fr_n"
    else
        rm -f "$MODDIR/freq.applied.$fr_n"
    fi
}
freq_restore_all() {
    for fr_p in "$POLICY_ROOT"/policy*; do
        [ -r "$fr_p/scaling_min_freq" ] || continue
        freq_restore_one "${fr_p##*/}" || return 1
    done
}
freq_apply_screen() {
    # Never enforce custom CPU clocks during sleep, unknown screen state or while paused.
    fa_screen=$1
    freq_boot_prepare || { FREQ_ERROR=baseline_capture_failed; return 1; }
    [ "$fa_screen" = UNKNOWN ] && return 0
    [ "$fa_screen" = ON ] || { freq_restore_all; return; }
    for fa_p in "$POLICY_ROOT"/policy*; do
        [ -r "$fa_p/scaling_min_freq" ] || continue
        fa_n=${fa_p##*/}
        fa_config="$FREQ_ROOT/freq.$fa_n"
        if [ ! -s "$fa_config" ]; then
            freq_restore_one "$fa_n" || return 1
            continue
        fi
        read -r fa_min fa_max < "$fa_config" || { FREQ_ERROR=bad_saved_config; return 1; }
        freq_validate_pair "$fa_n" "$fa_min" "$fa_max" || return 1
        freq_range_read "$fa_p" || return 1
        [ "$F_CUR_MIN" = "$F_TARGET_MIN" ] && [ "$F_CUR_MAX" = "$F_TARGET_MAX" ] && continue
        fa_prev_min=$F_CUR_MIN; fa_prev_max=$F_CUR_MAX
        if ! freq_write_pair "$fa_p" "$F_TARGET_MIN" "$F_TARGET_MAX"; then
            fa_last_error=$FREQ_ERROR
            freq_write_pair "$fa_p" "$fa_prev_min" "$fa_prev_max" || :
            FREQ_ERROR="$fa_n:$fa_last_error"
            return 1
        fi
        printf '%s %s\n' "$F_TARGET_MIN" "$F_TARGET_MAX" > "$MODDIR/freq.applied.$fa_n" || return 1
    done
}
freq_set() {
    fs_n=$1; fs_min=$2; fs_max=$3
    freq_boot_prepare || { FREQ_ERROR=baseline_capture_failed; return 1; }
    freq_validate_pair "$fs_n" "$fs_min" "$fs_max" || return 1
    if [ "$fs_min" = stock ] && [ "$fs_max" = stock ]; then
        rm -f "$FREQ_ROOT/freq.$fs_n"
        freq_restore_one "$fs_n" || return 1
    else
        fs_tmp="$FREQ_ROOT/.freq.$fs_n.$$"
        (umask 077; printf '%s %s\n' "$fs_min" "$fs_max" > "$fs_tmp") || return 1
        mv -f "$fs_tmp" "$FREQ_ROOT/freq.$fs_n" || return 1
    fi
}
freq_status() {
    freq_boot_prepare >/dev/null 2>&1 || :
    for fs_pol in "$POLICY_ROOT"/policy*; do
        [ -r "$fs_pol/scaling_min_freq" ] || continue
        fs_name=${fs_pol##*/}
        freq_original "$fs_name" || { F_BASE_MIN=unknown; F_BASE_MAX=unknown; }
        fs_cur_min=$(gov_read "$fs_pol/scaling_min_freq" 2>/dev/null)
        fs_cur_max=$(gov_read "$fs_pol/scaling_max_freq" 2>/dev/null)
        fs_cfg_min=stock; fs_cfg_max=stock
        if [ -s "$FREQ_ROOT/freq.$fs_name" ]; then
            read -r fs_cfg_min fs_cfg_max < "$FREQ_ROOT/freq.$fs_name" || :
        fi
        fs_available=$(gov_read "$fs_pol/scaling_available_frequencies" 2>/dev/null | tr ' ' ',')
        printf 'CLOCK|%s|%s|%s|%s|%s|%s|%s|%s\n' "$fs_name" "${fs_cur_min:-unknown}" "${fs_cur_max:-unknown}" "$F_BASE_MIN" "$F_BASE_MAX" "$fs_cfg_min" "$fs_cfg_max" "${fs_available:-unknown}"
    done
}
