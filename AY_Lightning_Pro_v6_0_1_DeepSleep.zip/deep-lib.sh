#!/system/bin/sh
# AY Lightning Pro v6: offline Deep Sleep controls.
# Screen wake DOES NOT restore radios. Explicit cancel restores the snapshot.
# All radio actions are attempted independently and their outcome is reported.
DS_DIR=${AY_DATA_DIR:-/data/adb/ay_lightning}/deep
DS_CMD=${YASIR_CMD:-/system/bin/cmd}
DS_SETTINGS=${YASIR_SETTINGS:-/system/bin/settings}
DS_DUMPSYS=${YASIR_DUMPSYS:-/system/bin/dumpsys}
DS_SVC=${YASIR_SVC:-/system/bin/svc}
DS_AM=${YASIR_AM:-/system/bin/am}
DS_BOOT_ID=${YASIR_BOOT_ID:-/proc/sys/kernel/random/boot_id}
DS_UPTIME=${YASIR_UPTIME:-/proc/uptime}
DS_ERROR=
DS_WARNINGS=

ds_state() {
    [ -s "$DS_DIR/state" ] || { printf off; return; }
    ds_s=$(cat "$DS_DIR/state" 2>/dev/null)
    case "$ds_s" in armed|entering|active|partial|restoring) printf '%s' "$ds_s" ;; *) printf off ;; esac
}
ds_write() {
    ds_path=$1; ds_payload=$2
    mkdir -p "$DS_DIR" || return 1
    chmod 700 "$DS_DIR" 2>/dev/null || :
    (umask 077; printf '%s\n' "$ds_payload" > "$DS_DIR/.tmp.$$.${ds_path##*/}") || return 1
    mv -f "$DS_DIR/.tmp.$$.${ds_path##*/}" "$ds_path"
}
ds_write_state() { ds_write "$DS_DIR/state" "$1"; }
ds_log() {
    ds_log_text=$1
    [ -n "${MODDIR:-}" ] || return 0
    printf '%s | DEEP %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$ds_log_text" >> "$MODDIR/status.log" 2>/dev/null || :
}
ds_warn() {
    if [ -z "$DS_WARNINGS" ]; then DS_WARNINGS=$1; else DS_WARNINGS="$DS_WARNINGS,$1"; fi
}
ds_lock() {
    mkdir -p "$DS_DIR" || { DS_ERROR=storage_unavailable; return 1; }
    ds_tries=0
    while ! mkdir "$DS_DIR/lock" 2>/dev/null; do
        ds_owner=$(cat "$DS_DIR/lock/pid" 2>/dev/null)
        case "$ds_owner" in
            ''|*[!0-9]*)
                ds_stale=$(find "$DS_DIR/lock" -maxdepth 0 -mmin +1 2>/dev/null)
                [ -n "$ds_stale" ] && rm -rf "$DS_DIR/lock" 2>/dev/null || : ;;
            *) kill -0 "$ds_owner" 2>/dev/null || rm -rf "$DS_DIR/lock" 2>/dev/null || : ;;
        esac
        ds_tries=$((ds_tries + 1))
        [ "$ds_tries" -lt 60 ] || { DS_ERROR=operation_busy; return 1; }
        sleep 0.2
    done
    printf '%s\n' "$$" > "$DS_DIR/lock/pid"
    return 0
}
ds_unlock() {
    [ "$(cat "$DS_DIR/lock/pid" 2>/dev/null)" = "$$" ] || return 0
    rm -f "$DS_DIR/lock/pid"
    rmdir "$DS_DIR/lock" 2>/dev/null || :
}
ds_options() {
    DS_AIR=1; DS_WIFI=1; DS_BT=1; DS_KILL=0
    if [ -r "$DS_DIR/options" ]; then
        read -r ds_oa ds_ow ds_ob ds_ok ds_ot < "$DS_DIR/options" || :
        case "$ds_ok" in 0|1) DS_KILL=$ds_ok ;; esac
    fi
}
ds_save_options() {
    DS_ERROR=
    [ "${1:-}" = 1 ] && [ "${2:-}" = 1 ] && [ "${3:-}" = 1 ] || { DS_ERROR=all_radios_required; return 1; }
    case "${4:-}" in 0|1) : ;; *) DS_ERROR=invalid_cached_apps; return 1 ;; esac
    ds_write "$DS_DIR/options" "1 1 1 $4" || { DS_ERROR=storage_unavailable; return 1; }
}
ds_auto_options() {
    DS_AUTO=1
    if [ -r "$DS_DIR/auto" ]; then
        ds_flag=$(cat "$DS_DIR/auto" 2>/dev/null)
        case "$ds_flag" in 0|1) DS_AUTO=$ds_flag ;; esac
    fi
    DS_DELAY=3600
}
ds_save_auto() {
    DS_ERROR=
    case "${1:-}" in 0|1) : ;; *) DS_ERROR=invalid_auto_option; return 1 ;; esac
    ds_write "$DS_DIR/auto" "$1" || { DS_ERROR=cannot_save_auto; return 1; }
    rm -f "$DS_DIR/screen_off_since" "$DS_DIR/off_bootid" "$DS_DIR/autodone"
}
ds_uptime() {
    [ -r "$DS_UPTIME" ] || return 1
    read -r ds_sec ds_rest < "$DS_UPTIME" || return 1
    ds_sec=${ds_sec%%.*}
    case "$ds_sec" in ''|*[!0-9]*) return 1 ;; esac
    printf '%s' "$ds_sec"
}
ds_auto_elapsed() {
    DS_ELAPSED=0
    [ -s "$DS_DIR/screen_off_since" ] || return 0
    ds_since=$(cat "$DS_DIR/screen_off_since" 2>/dev/null)
    ds_now=$(ds_uptime) || return 0
    case "$ds_since" in ''|*[!0-9]*) return 0 ;; esac
    [ "$ds_now" -ge "$ds_since" ] || return 0
    [ "$(cat "$DS_DIR/off_bootid" 2>/dev/null)" = "$(cat "$DS_BOOT_ID" 2>/dev/null)" ] || return 0
    DS_ELAPSED=$((ds_now - ds_since))
}
ds_read_air() {
    ds_val=$($DS_SETTINGS get global airplane_mode_on 2>/dev/null)
    case "$ds_val" in 0|1) printf '%s' "$ds_val" ;; *) return 1 ;; esac
}
ds_read_wifi() {
    ds_output=$($DS_CMD wifi status 2>/dev/null)
    case "$ds_output" in
        *'Wifi is enabled'*|*'Wi-Fi is enabled'*) printf 1; return 0 ;;
        *'Wifi is disabled'*|*'Wi-Fi is disabled'*) printf 0; return 0 ;;
    esac
    # wifi_on is a BOOLEAN setting (0/1), not WifiManager's 0-3 state enum.
    ds_val=$($DS_SETTINGS get global wifi_on 2>/dev/null)
    case "$ds_val" in 0|1) printf '%s' "$ds_val" ;; *) return 1 ;; esac
}
ds_read_bt() {
    # Read actual adapter status first, avoiding stale global bluetooth_on.
    ds_output=$($DS_DUMPSYS bluetooth_manager 2>/dev/null)
    case "$ds_output" in
        *'state: BLE_ON'*|*'state: 15'*) printf 1; return 0 ;;
        *'state: ON'*|*'state: 12'*) printf 1; return 0 ;;
        *'state: OFF'*|*'state: 10'*) printf 0; return 0 ;;
        *'enabled: true'*) printf 1; return 0 ;;
        *'enabled: false'*) printf 0; return 0 ;;
    esac
    ds_val=$($DS_SETTINGS get global bluetooth_on 2>/dev/null)
    case "$ds_val" in 0|1) printf '%s' "$ds_val" ;; *) return 1 ;; esac
}
ds_read_nfc() {
    ds_output=$($DS_CMD nfc status 2>/dev/null) || return 1
    case "$ds_output" in
        *'Nfc is enabled'*|*'NFC is enabled'*) printf 1 ;;
        *'Nfc is disabled'*|*'NFC is disabled'*) printf 0 ;;
        *) return 1 ;;
    esac
}
ds_read_radio() {
    case "$1" in
        air) ds_read_air ;; wifi) ds_read_wifi ;; bt) ds_read_bt ;; nfc) ds_read_nfc ;; *) return 1 ;;
    esac
}
ds_verify() {
    ds_kind=$1; ds_expected=$2; ds_attempt=0
    while [ "$ds_attempt" -lt 6 ]; do
        ds_actual=$(ds_read_radio "$ds_kind" 2>/dev/null) || ds_actual=x
        [ "$ds_actual" = "$ds_expected" ] && return 0
        ds_attempt=$((ds_attempt + 1))
        [ "$ds_attempt" -ge 6 ] || sleep 1
    done
    DS_ERROR="${ds_kind}_not_${ds_expected}_observed_${ds_actual}"
    return 1
}
ds_air_set() {
    ds_target=$1
    [ "$ds_target" = 1 ] && ds_arg=enable || ds_arg=disable
    ds_actual=$(ds_read_air 2>/dev/null) || ds_actual=x
    [ "$ds_actual" = "$ds_target" ] && return 0
    if "$DS_CMD" connectivity airplane-mode "$ds_arg" >/dev/null 2>&1; then
        ds_verify air "$ds_target" && return 0
    fi
    # Device-specific fallback. This is unverified unless Android's radio
    # state actually transitions. Settings alone do not prove radios are off.
    "$DS_SETTINGS" put global airplane_mode_on "$ds_target" >/dev/null 2>&1 || :
    [ "$ds_target" = 1 ] && ds_bool=true || ds_bool=false
    "$DS_AM" broadcast -a android.intent.action.AIRPLANE_MODE --ez state "$ds_bool" >/dev/null 2>&1 || :
    ds_verify air "$ds_target" || return 1
    ds_warn airplane_fallback_check_cellular
    return 0
}
ds_wifi_set() {
    ds_target=$1
    [ "$ds_target" = 1 ] && ds_arg=enabled || ds_arg=disabled
    ds_actual=$(ds_read_wifi 2>/dev/null) || ds_actual=x
    [ "$ds_actual" = "$ds_target" ] && return 0
    "$DS_CMD" wifi set-wifi-enabled "$ds_arg" >/dev/null 2>&1 && ds_verify wifi "$ds_target" && return 0
    [ "$ds_target" = 1 ] && ds_arg=enable || ds_arg=disable
    "$DS_SVC" wifi "$ds_arg" >/dev/null 2>&1 && ds_verify wifi "$ds_target" && return 0
    DS_ERROR="wifi_toggle_failed_observed_$(ds_read_wifi 2>/dev/null || printf x)"
    return 1
}
ds_bt_set() {
    ds_target=$1
    [ "$ds_target" = 1 ] && ds_arg=enable || ds_arg=disable
    ds_actual=$(ds_read_bt 2>/dev/null) || ds_actual=x
    [ "$ds_actual" = "$ds_target" ] && return 0
    "$DS_CMD" bluetooth_manager "$ds_arg" >/dev/null 2>&1 && ds_verify bt "$ds_target" && return 0
    "$DS_SVC" bluetooth "$ds_arg" >/dev/null 2>&1 && ds_verify bt "$ds_target" && return 0
    DS_ERROR="bluetooth_toggle_failed_observed_$(ds_read_bt 2>/dev/null || printf x)"
    return 1
}
ds_nfc_set() {
    ds_target=$1
    [ "$ds_target" = 1 ] && ds_arg=enable-nfc || ds_arg=disable-nfc
    "$DS_CMD" nfc "$ds_arg" >/dev/null 2>&1 || return 1
    ds_verify nfc "$ds_target"
}
ds_snapshot_validate() {
    [ -r "$DS_DIR/snapshot" ] || { DS_ERROR=missing_saved_radio_states; return 1; }
    read -r ds_prev_air ds_prev_wifi ds_prev_bt ds_prev_nfc < "$DS_DIR/snapshot" || :
    [ -n "$ds_prev_nfc" ] || ds_prev_nfc=x
    case "$ds_prev_air" in 0|1) : ;; *) DS_ERROR=invalid_air_snapshot; return 1 ;; esac
    case "$ds_prev_wifi" in 0|1|x) : ;; *) DS_ERROR=invalid_wifi_snapshot; return 1 ;; esac
    case "$ds_prev_bt" in 0|1|x) : ;; *) DS_ERROR=invalid_bt_snapshot; return 1 ;; esac
    case "$ds_prev_nfc" in 0|1|x) : ;; *) DS_ERROR=invalid_nfc_snapshot; return 1 ;; esac
}
ds_restore_core() {
    DS_ERROR=; DS_WARNINGS=
    ds_snapshot_validate || return 1
    ds_write_state restoring || { DS_ERROR=state_write_failed; return 1; }
    ds_restore_failures=
    # Undo airplane mode FIRST, then Wi-Fi and Bluetooth to restore desired
    # states even when Android's airplane-mode toggling affects other radios.
    if ! ds_air_set "$ds_prev_air"; then ds_restore_failures="$ds_restore_failures,air:$DS_ERROR"; fi
    if [ "$ds_prev_wifi" != x ]; then
        if ! ds_wifi_set "$ds_prev_wifi"; then ds_restore_failures="$ds_restore_failures,wifi:$DS_ERROR"; fi
    else
        ds_warn original_wifi_state_unknown
    fi
    if [ "$ds_prev_bt" != x ]; then
        if ! ds_bt_set "$ds_prev_bt"; then ds_restore_failures="$ds_restore_failures,bt:$DS_ERROR"; fi
    else
        ds_warn original_bluetooth_state_unknown
    fi
    if [ "$ds_prev_nfc" != x ]; then
        ds_nfc_set "$ds_prev_nfc" || ds_warn nfc_restore_unsupported
    fi
    if [ -n "$ds_restore_failures" ]; then
        DS_ERROR="restore_failed$ds_restore_failures"
        ds_write "$DS_DIR/last_error" "$DS_ERROR" || :
        ds_log "RESTORE_ERROR $DS_ERROR"
        return 1
    fi
    [ -z "$DS_WARNINGS" ] || ds_log "RESTORE_WARNING $DS_WARNINGS"
    rm -f "$DS_DIR/snapshot" "$DS_DIR/bootid" "$DS_DIR/state" "$DS_DIR/activated" "$DS_DIR/source" "$DS_DIR/radio_warning" "$DS_DIR/last_error"
    ds_log 'RESTORED_RADIOS by explicit cancel / boot recovery'
    DS_ERROR=
    return 0
}
ds_restore() {
    ds_lock || return 1
    ds_restore_core; ds_rc=$?
    ds_unlock
    return "$ds_rc"
}
ds_apply_off() {
    DS_WARNINGS=; DS_ERROR=
    ds_failures=
    ds_air_set 1 || { ds_failures="$ds_failures,air:$DS_ERROR"; ds_warn airplane_not_confirmed; }
    ds_wifi_set 0 || { ds_failures="$ds_failures,wifi:$DS_ERROR"; ds_warn wifi_not_confirmed; }
    ds_bt_set 0 || { ds_failures="$ds_failures,bt:$DS_ERROR"; ds_warn bluetooth_not_confirmed; }
    if [ "$(ds_read_nfc 2>/dev/null || printf x)" = 1 ]; then
        ds_nfc_set 0 || ds_warn nfc_not_disabled
    fi
    "$DS_CMD" wifi stop-softap >/dev/null 2>&1 || :
    "$DS_CMD" wifi stop-lohs >/dev/null 2>&1 || :
    ds_final_air=$(ds_read_air 2>/dev/null || printf x)
    ds_final_wifi=$(ds_read_wifi 2>/dev/null || printf x)
    ds_final_bt=$(ds_read_bt 2>/dev/null || printf x)
    [ "$ds_final_air" = 1 ] || ds_warn airplane_not_offline
    [ "$ds_final_wifi" = 0 ] || ds_warn wifi_not_offline
    [ "$ds_final_bt" = 0 ] || ds_warn bluetooth_not_offline
    if [ "$ds_final_air" = 1 ] && [ "$ds_final_wifi" = 0 ] && [ "$ds_final_bt" = 0 ] && [ -z "$ds_failures" ] && [ -z "$DS_WARNINGS" ]; then
        ds_write_state active || { DS_ERROR=state_write_failed; return 1; }
    else
        ds_write_state partial || { DS_ERROR=state_write_failed; return 1; }
        DS_ERROR="partial_offline:$ds_failures final_air=$ds_final_air,wifi=$ds_final_wifi,bt=$ds_final_bt"
        ds_write "$DS_DIR/last_error" "$DS_ERROR" || :
    fi
    if [ -n "$DS_WARNINGS" ]; then
        ds_write "$DS_DIR/radio_warning" "$DS_WARNINGS" || :
    else
        rm -f "$DS_DIR/radio_warning" "$DS_DIR/last_error"
    fi
    ds_log "APPLY state=$(ds_state) final=$ds_final_air/$ds_final_wifi/$ds_final_bt details=$DS_WARNINGS"
    return 0
}
ds_enter_core() {
    DS_ERROR=; DS_WARNINGS=
    ds_current=$(ds_state)
    case "$ds_current" in
        active) DS_ERROR=already_active; return 1 ;;
        partial) ds_apply_off; return $? ;;
        armed) rm -f "$DS_DIR/state" ;;
        off) : ;;
        *) DS_ERROR=operation_in_progress; return 1 ;;
    esac
    ds_options
    ds_prevair=$(ds_read_air 2>/dev/null) || { DS_ERROR=cannot_read_airplane_state; return 1; }
    ds_prevwifi=$(ds_read_wifi 2>/dev/null) || ds_prevwifi=x
    ds_prevbt=$(ds_read_bt 2>/dev/null) || ds_prevbt=x
    ds_prevnfc=$(ds_read_nfc 2>/dev/null) || ds_prevnfc=x
    ds_write "$DS_DIR/snapshot" "$ds_prevair $ds_prevwifi $ds_prevbt $ds_prevnfc" || { DS_ERROR=cannot_save_radios; return 1; }
    ds_boot=$(cat "$DS_BOOT_ID" 2>/dev/null)
    ds_write "$DS_DIR/bootid" "$ds_boot" || :
    ds_write_state entering || { DS_ERROR=cannot_save_state; return 1; }
    ds_write "$DS_DIR/source" "${1:-manual}" || :
    # Snapshot is durable before any radio is touched. No implicit restoration
    # on wake. Partial state is still cancellable, never silently rolled back.
    ds_apply_off || return 1
    ds_options
    if [ "$DS_KILL" = 1 ]; then "$DS_AM" kill-all >/dev/null 2>&1 || ds_warn app_cache_trim_unavailable; fi
    ds_write "$DS_DIR/activated" "$(date +%s)" || :
    return 0
}
ds_enter() {
    ds_lock || return 1
    ds_enter_core "${1:-manual}"; ds_rc=$?
    ds_unlock
    return "$ds_rc"
}
ds_retry() {
    case "$(ds_state)" in partial|active) : ;; *) DS_ERROR=not_sleeping; return 1 ;; esac
    ds_lock || return 1
    ds_apply_off; ds_rc=$?
    ds_unlock
    return "$ds_rc"
}
ds_cancel() {
    DS_ERROR=
    ds_lock || return 1
    ds_current=$(ds_state)
    case "$ds_current" in
        off) ds_rc=0 ;;
        armed) rm -f "$DS_DIR/state"; ds_rc=0 ;;
        entering|active|partial|restoring) ds_restore_core; ds_rc=$? ;;
        *) ds_rc=0 ;;
    esac
    # One explicit cancel while screen OFF must not instantly re-arm auto.
    if [ "$ds_rc" -eq 0 ]; then
        if ds_screen_is_on; then
            rm -f "$DS_DIR/autodone" "$DS_DIR/screen_off_since" "$DS_DIR/off_bootid"
        else
            ds_write "$DS_DIR/autodone" 1 || :
        fi
    fi
    ds_unlock
    return "$ds_rc"
}
ds_screen_state() {
    # fb0/blank is often permanently 0 on DRM-based devices: don't trust it
    # if Android's display-power service is available.
    ds_power=$($DS_DUMPSYS power 2>/dev/null) || ds_power=
    case "$ds_power" in
        *'Display Power: state=OFF'*|*'Display Power: state=DOZE'*) printf OFF; return 0 ;;
        *'Display Power: state=ON'*) printf ON; return 0 ;;
    esac
    case "$ds_power" in
        *'mWakefulness=Asleep'*|*'mWakefulness=Dozing'*) printf OFF; return 0 ;;
        *'mWakefulness=Awake'*|*'mWakefulness=Dreaming'*) printf ON; return 0 ;;
    esac
    ds_display=$($DS_DUMPSYS display 2>/dev/null) || ds_display=
    case "$ds_display" in
        *'mScreenState=OFF'*|*'mState=OFF'*) printf OFF; return 0 ;;
        *'mScreenState=ON'*|*'mState=ON'*) printf ON; return 0 ;;
    esac
    ds_idle=$($DS_DUMPSYS deviceidle 2>/dev/null) || ds_idle=
    case "$ds_idle" in
        *'mScreenOn=false'*) printf OFF; return 0 ;;
        *'mScreenOn=true'*) printf ON; return 0 ;;
    esac
    ds_blank_path=${YASIR_SCREEN_BLANK:-/sys/class/graphics/fb0/blank}
    if [ -r "$ds_blank_path" ]; then
        ds_blank=$(cat "$ds_blank_path" 2>/dev/null)
        case "$ds_blank" in 0) printf ON; return 0 ;; 1|4) printf OFF; return 0 ;; esac
    fi
    printf UNKNOWN
    return 1
}
ds_screen_is_on() { [ "$(ds_screen_state)" = ON ]; }
ds_tick() {
    ds_physical=$1
    ds_auto_options
    case "$ds_physical" in
        ON) rm -f "$DS_DIR/screen_off_since" "$DS_DIR/off_bootid" "$DS_DIR/autodone" ;;
        OFF)
            [ "$DS_AUTO" = 1 ] || return 0
            [ "$(ds_state)" = off ] || return 0
            [ -f "$DS_DIR/autodone" ] && return 0
            ds_now=$(ds_uptime) || { DS_ERROR=uptime_unavailable; return 1; }
            ds_since=$(cat "$DS_DIR/screen_off_since" 2>/dev/null)
            ds_boot_now=$(cat "$DS_BOOT_ID" 2>/dev/null)
            ds_boot_old=$(cat "$DS_DIR/off_bootid" 2>/dev/null)
            case "$ds_since" in ''|*[!0-9]*) ds_since=invalid ;; esac
            if [ "$ds_since" = invalid ] || [ "$ds_since" -gt "$ds_now" ] || [ "$ds_boot_old" != "$ds_boot_now" ]; then
                ds_write "$DS_DIR/screen_off_since" "$ds_now" || return 1
                ds_write "$DS_DIR/off_bootid" "$ds_boot_now" || :
                return 0
            fi
            if [ $((ds_now - ds_since)) -ge "$DS_DELAY" ]; then
                if ds_enter auto; then
                    ds_write "$DS_DIR/autodone" 1 || :
                else
                    ds_log "AUTO_FAILED $DS_ERROR"
                    ds_write "$DS_DIR/last_error" "auto_failed:$DS_ERROR" || :
                    # Keep attempts bounded until next physical screen-on.
                    ds_write "$DS_DIR/autodone" 1 || :
                    return 1
                fi
            fi ;;
    esac
    return 0
}
ds_recover_previous_boot() {
    ds_lock || return 1
    ds_current=$(ds_state)
    ds_current_boot=$(cat "$DS_BOOT_ID" 2>/dev/null)
    ds_saved_boot=$(cat "$DS_DIR/bootid" 2>/dev/null)
    case "$ds_current" in
        armed) rm -f "$DS_DIR/state"; ds_rc=0 ;;
        entering|restoring) ds_restore_core; ds_rc=$? ;;
        active|partial)
            if [ -n "$ds_current_boot" ] && [ "$ds_current_boot" = "$ds_saved_boot" ]; then
                ds_rc=0
            else
                ds_restore_core; ds_rc=$?
            fi ;;
        *) ds_rc=0 ;;
    esac
    ds_unlock
    return "$ds_rc"
}
