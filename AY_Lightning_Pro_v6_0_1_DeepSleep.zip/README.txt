AY LIGHTNING PRO v6.0.1 — DEEP SLEEP ULTRA
Developer: Eng/ Ahmed Yasir / المهندس أحمد ياسر
Module: eng_ahmed_yasir_screen_gov
Target: KernelSU Next / Android (radio shell commands vary by ROM)

==================== اللغة العربية ====================

أهم تغيير في v6.0:
- زر واضح في WebUI > النوم: «تفعيل النوم العميق الآن».
- بمجرد الضغط والتأكيد، يحفظ حالات الشبكات ثم يفعّل وضع الطيران ويغلق Wi-Fi
  والبلوتوث، ويجرب إيقاف NFC عند دعم نظام الجهاز. يوقف نقطة اتصال Wi-Fi
  والمحطة المحلية (Hotspot/Local-only hotspot) بقدر ما تسمح به أوامر النظام.
- تظل الاتصالات مفصولة عند تشغيل الشاشة. *لا يوجد استرجاع تلقائي عند الاستيقاظ*.
- الخروج الطبيعي من النوم واستعادة الحالات المحفوظة يتم فقط عبر:
  WebUI > النوم > «إلغاء النوم واستعادة الاتصالات»؛ أو الأمر deep-cancel.
- لا توجد مهلة 1/4/8 ساعات تعيد الاتصالات من تلقاء نفسها.
- خيار بديل لمن يستخدم Magisk: اضغط زر Action في بطاقة الموديول لبدء النوم فورًا؛
  اضغط Action مرة أخرى لإلغاء النوم واستعادة الاتصالات يدويًا.
- إذا رفض روم الهاتف أوامر الاتصال فستظهر حالة «فصل جزئي» مع التفاصيل وزر إعادة المحاولة.
  لا يتظاهر الإصدار بأن جميع الشبكات معطلة عندما يتعذر تأكيد ذلك.
- يُعطي كشف إطفاء الشاشة الأولوية لـ dumpsys power لأن fb0/blank قد يبقى
  معروضًا على أنه يعمل حتى عندما تكون الشاشة مطفأة على الأجهزة الحديثة.
- النوم التلقائي مفعل افتراضيًا: بعد مرور 60 دقيقة متصلة والشاشة مطفأة،
  يتم تطبيق وضع النوم العميق دون لمس الهاتف، حتى لو كان بروفايل CPU متوقفًا.
  تشغيل الشاشة *قبل* نهاية الساعة يلغي العد، ثم يبدأ من الصفر عند إطفائها.
  لا يؤدي تشغيل الشاشة أثناء النوم النشط إلى استعادة أي اتصال.
- يمكن إيقاف النوم التلقائي من واجهة WebUI. النوم الفوري يبقى متاحًا.

ما الذي يتغير عند النوم؟
  شبكة الشريحة: وضع الطيران (انقطاع المكالمات العادية، SMS وبيانات الهاتف)
  Wi-Fi: إيقاف، بما يشمل محاولة إيقاف نقطة الاتصال
  Bluetooth: إيقاف؛ يفصل السماعات والساعات والأجهزة المتصلة
  NFC: إيقاف واسترداد حالته إن كانت أوامر cmd nfc مدعومة
  CPU: التبديل إلى powersave إذا كانت النواة تدعمه، وإلا تُترك القيم المدعومة
       دون إجبار kernel على ترددات غير صالحة
  التطبيقات المخزنة مؤقتًا: اختيار اختياري معطل افتراضيًا، باستخدام am kill-all
  نظام أندرويد: لا يتم قتل خدمات النظام الأساسية أو تعطيل SELinux والحرارة

التحكم بالمعالج:
- خمسة بروفايلات: أقصى أداء، متوازن، الثبات، الاقتصادي، التوفير الشديد.
- قراءة governor الذي تدعمه كل سياسة CPU والتحقق من قيمة الكتابة قبل اعتمادها.
- كل إعداد يدوي للتردد اختياري ومحفوظ مع نقطة رجوع للقيم الأساسية.
- حماية انخفاض البطارية/الحرارة تستخدم هامش رجوع لمنع التنقل المتكرر
  بين الأوضاع: +3 نقاط مئوية للبطارية، و-2 درجة مئوية للحرارة.
- حماية تلقائية إضافية من حرارة البطارية >=48°C عند طلب performance،
  مع الإبقاء على نظام الحماية الحرارية الأصلي للجهاز.
- عند إطفاء الشاشة يحاول مراقب CPU قراءة مؤشر blank منخفض التكلفة
  إن توفر، وإلا يستخدم dumpsys power، مع فحص الاستيقاظ حوالي كل ثانية.

الواجهة:
- واجهة WebUI محدّثة في v6.0 مع تبويب النوم في المقدمة؛ زر فوري واضح،
  مؤشر حالة الشبكات، عداد الساعة، وضع ليلي/نهاري، ولغتان عربي/إنجليزي.
- البنر والصورة والأيقونات الأصلية لم تُعدّل، بناءً على طلبك.
- تحديث الحالة عند الطلب لتقليل عمل الواجهة غير الضروري.

السلامة والقيود:
1. هذا ليس إغلاقًا حقيقيًا للهاتف. خدمة الشبكة والنظام والطاقة تعتمد
   على رومات Android وأوامر cmd المدعومة؛ لا نضمن انقطاع كل نظام لاسلكي
   على جميع الأجهزة. GPS/UWB والخدمات الخاصة بالشركات قد تختلف.
2. المكالمات العادية والرسائل والإشعارات الواردة لن تعمل أثناء تفعيل
   وضع الطيران. لا تستخدم الوضع عندما تتوقع اتصالًا عاجلًا أو تحتاج
   إمكانية تلقي تنبيهات طوارئ الشبكة.
3. إذا فشل قطع اتصال مطلوب، يحاول الموديول التراجع عن التغييرات.
4. استثناءات السلامة: محاولة استعادة الاتصالات عند فشل عملية الدخول،
   أو عند إلغاء تثبيت الموديول، أو بعد إعادة تشغيل الهاتف إذا اكتشف
   حالة نوم قديمة من إقلاع سابق / عملية استرجاع غير مكتملة.
   *الاستيقاظ العادي بتشغيل الشاشة لا يعيد الاتصال نهائيًا*.
5. قد يلزم تشغيل Hotspot يدويًا بعد إلغاء النوم؛ لأن استعادته ليست
   مضمونة على جميع رومات Android. NFC يتم التحكم فيه فقط عند دعم أوامره.
6. لا يمكن محاكاة أداء البطارية الحقيقي في الحاوية. اختبر على الجهاز
   نفسه، واحتفظ بنسخة ZIP من الإصدار القديم قبل التحديث.

التثبيت والتحديث:
- من KernelSU Next: الوحدات > التثبيت من التخزين > اختر ZIP > أعد التشغيل.
- معرّف الموديول ثابت، لذلك يحتفظ بالنسخة السابقة من إعدادات CPU والبروفايل
  في /data/adb/ay_lightning/، ويطبق خيارات Deep Sleep الجديدة.
- على التثبيت النظيف يبقى تغيير CPU متوقفًا لحين اختيار بروفايل، بينما
  النوم التلقائي بعد ساعة يكون مفعّلًا افتراضيًا.
- من المهم السماح لخدمة KernelSU الموديول بالعمل بعد إعادة التشغيل.

التحكم من Termux (Root):
  su
  sh /data/adb/modules/eng_ahmed_yasir_screen_gov/control.sh status
  sh /data/adb/modules/eng_ahmed_yasir_screen_gov/control.sh deep-now
  sh /data/adb/modules/eng_ahmed_yasir_screen_gov/control.sh deep-retry
  sh /data/adb/modules/eng_ahmed_yasir_screen_gov/control.sh deep-cancel
  sh /data/adb/modules/eng_ahmed_yasir_screen_gov/control.sh deep-auto 1
  sh /data/adb/modules/eng_ahmed_yasir_screen_gov/control.sh deep-auto 0
  sh /data/adb/modules/eng_ahmed_yasir_screen_gov/control.sh logs

عند فشل النوم على الهاتف، افتح Termux واطلب الصلاحية ثم شغّل:
  su
  sh /data/adb/modules/eng_ahmed_yasir_screen_gov/control.sh status
  sh /data/adb/modules/eng_ahmed_yasir_screen_gov/control.sh logs
سترى DEEP_WARNING و DEEP_ERROR وحالة MONITOR بدل الاكتفاء برسالة نجاح غير مؤكدة.

في حال تعطل واجهة الويب أو الرومات الخاصة بعد الدخول للنوم،
حاول أولًا تنفيذ deep-cancel بصلاحية Root (يحفظ الحالات السابقة).
حل طوارئ يدوي إذا تعذر عمل السكربت:
  su -c 'cmd connectivity airplane-mode disable'
ثم افتح إعدادات الهاتف لتشغيل Wi-Fi/Bluetooth يدويًا حسب الحاجة.

==================== ENGLISH ====================

Deep Sleep Ultra v6.0:
- Tap Activate Deep Sleep Now in KernelSU Next WebUI: the module snapshots
  current airplane, Wi-Fi, Bluetooth and supported NFC states, then disables
  the radios. Hotspot stop is best effort and may require manual restart.
- NO automatic reconnection on screen wake or after a timer.
- Manual cancellation in WebUI restores the saved radio configuration.
- Magisk users can use the module's Action button as a manual toggle:
  first tap activates offline mode; second tap cancels and restores radios.
- Unsupported commands yield PARTIAL status with diagnostic details and retry.
- Screen detection prefers dumpsys over an unreliable static fb0/blank node.
- Automatic sleep is ON by default after 60 continuous minutes screen OFF.
  If you wake the display before the 60-minute threshold, the timer resets.
  Automatic sleep also works if you have not selected a CPU profile.
- Manual Deep Sleep remains available while auto sleep is disabled.
- Exceptions: failed-operation rollback, uninstall, and cross-boot recovery.

CPU / Safety: five distinct profiles, per-policy governor validation,
opt-in clocks with stock restoration, battery/heat safeguards with
hysteresis, and an extreme-battery-heat reduction for performance mode.
Android thermal control and SELinux remain intact. The screen monitor prefers
an available sysfs panel blank state with dumpsys power fallback.

IMPORTANT: Deep Sleep blocks normal incoming cellular calls, SMS, Bluetooth,
Wi-Fi and network notifications. It is NOT the same as shutting down the
phone, and manufacturer-specific radios may not support every command.
Only enable it if losing incoming connectivity is acceptable.

This ZIP and shell behaviors were statically checked and exercised against
mocked Android radio services. They have NOT been validated on a physical
phone, and no battery-runtime or performance gain is claimed.

Emergency root recovery: run control.sh deep-cancel. If this is unavailable,
use 'cmd connectivity airplane-mode disable' and manually re-enable radios.

Designer: Eng/ Ahmed Yasir. Existing banner and icon files are unchanged.
