#!/system/bin/sh
# AY Lightning Pro v6 - one process for offline sleep and optional CPU profiles.
# Wake restores responsiveness, but NEVER restores airplane/Wi-Fi/Bluetooth.
MODDIR=${YASIR_MODDIR:-${0%/*}}
AY_DATA_DIR=${AY_DATA_DIR:-/data/adb/ay_lightning}
POLICY_ROOT=${YASIR_POLICY_ROOT:-/sys/devices/system/cpu/cpufreq}
DUMPSYS=${YASIR_DUMPSYS:-/system/bin/dumpsys}
GETPROP=${YASIR_GETPROP:-/system/bin/getprop}
. "$MODDIR/governor-lib.sh" || exit 1
. "$MODDIR/safety-lib.sh" || exit 1
. "$MODDIR/status-lib.sh" || exit 1
. "$MODDIR/freq-lib.sh" || exit 1
. "$MODDIR/deep-lib.sh" || exit 1
LOGFILE="$MODDIR/status.log"
PIDFILE="$MODDIR/monitor.pid"

MODE=off; ON_GOVERNOR=schedutil; OFF_GOVERNOR=powersave; POLL_SECONDS=3
load_settings() {
    MODE=off; ON_GOVERNOR=schedutil; OFF_GOVERNOR=powersave; POLL_SECONDS=3
    [ -r "$MODDIR/config.conf" ] && . "$MODDIR/config.conf"
    case "$MODE" in auto|performance|powersave|schedutil|off) : ;; *) MODE=off ;; esac
    case "$ON_GOVERNOR" in performance|powersave|schedutil|ondemand|conservative) : ;; *) ON_GOVERNOR=schedutil ;; esac
    case "$OFF_GOVERNOR" in performance|powersave|schedutil|ondemand|conservative) : ;; *) OFF_GOVERNOR=powersave ;; esac
    case "$POLL_SECONDS" in 2|3|5|10) : ;; *) POLL_SECONDS=3 ;; esac
    LOW_BATTERY=off; HIGH_TEMP=off
    [ -r "$MODDIR/safety.conf" ] && . "$MODDIR/safety.conf"
    SAFE_BATTERY=$LOW_BATTERY; SAFE_TEMP=$HIGH_TEMP
    case "$SAFE_BATTERY" in off|15|20|25|30) : ;; *) SAFE_BATTERY=off ;; esac
    case "$SAFE_TEMP" in off|40|42|45|48) : ;; *) SAFE_TEMP=off ;; esac
}
log_line() {
    if [ -f "$LOGFILE" ] && [ "$(wc -c < "$LOGFILE" 2>/dev/null)" -gt 60000 ]; then
        tail -n 90 "$LOGFILE" > "$LOGFILE.tmp" 2>/dev/null && mv -f "$LOGFILE.tmp" "$LOGFILE"
    fi
    printf '%s | %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOGFILE"
}
screen_state() {
    ds_screen_state
}
restore_governors() {
    for pol in "$POLICY_ROOT"/policy*; do
        [ -r "$pol/scaling_governor" ] || continue
        name=${pol##*/}
        original=$(gov_read "$MODDIR/original.$name" 2>/dev/null) || continue
        applied=$(gov_read "$MODDIR/applied.$name" 2>/dev/null) || continue
        current=$(gov_read "$pol/scaling_governor" 2>/dev/null) || continue
        [ "$current" = "$applied" ] || continue
        gov_supported "$pol" "$original" || continue
        if gov_write_verify "$pol" "$original"; then
            rm -f "$MODDIR/applied.$name"
        else
            log_line "RESTORE_FAIL $name reason=$GOV_WRITE_ERROR"
        fi
    done
}
on_exit() {
    # Restore ONLY CPU knobs. Radio disconnection survives screen wake, mode
    # pause, monitor restart and ordinary service termination.
    if [ "${CAPTURED:-0}" = 1 ]; then
        freq_restore_all || :
        restore_governors
    fi
    if [ -r "$PIDFILE" ] && [ "$(gov_read "$PIDFILE")" = "$$" ]; then rm -f "$PIDFILE"; fi
}
if [ -r "$PIDFILE" ]; then
    oldpid=$(gov_read "$PIDFILE")
    case "$oldpid" in
        ''|*[!0-9]*) : ;;
        *) if [ "$oldpid" != "$$" ] && kill -0 "$oldpid" 2>/dev/null && [ -r "/proc/$oldpid/cmdline" ]; then
            oldcmd=$(tr '\000' ' ' < "/proc/$oldpid/cmdline" 2>/dev/null)
            case "$oldcmd" in *"$MODDIR/monitor.sh"*) exit 0 ;; esac
        fi ;;
    esac
fi
printf '%s\n' "$$" > "$PIDFILE" || exit 1
CAPTURED=0
trap 'exit 0' HUP INT TERM
trap 'on_exit' 0

count=0
while [ "$($GETPROP sys.boot_completed 2>/dev/null)" != 1 ]; do
    [ -f "$MODDIR/disable" ] && exit 0
    [ -f "$MODDIR/remove" ] && exit 0
    count=$((count+1))
    [ "$count" -lt 90 ] || { log_line 'BOOT_TIMEOUT'; exit 1; }
    sleep 2
done
sleep 1
# Recover only interrupted transactions or a snapshot from a PRIOR reboot.
# Restarting the monitor during active Deep Sleep never restores the radios.
ds_recover_previous_boot || log_line "BOOT_DEEP_RECOVERY_ERROR:$DS_ERROR"
load_settings
if gov_capture_baseline; then
    CAPTURED=1
    freq_boot_prepare || log_line "FREQ_BASELINE_ERROR:${FREQ_ERROR:-unknown}"
else
    log_line 'CPU_POLICY_WARNING: sleep monitoring still available.'
fi
log_line "Service v6.0 started; mode=$MODE; cpu_policies=${captured:-0}; uid=$(id -u 2>/dev/null)"

last_mode=NONE; last_screen=UNKNOWN; last_wanted=NONE; last_reason=NONE
last_failure_details=; last_freq_error=; last_deep_state=off; last_deep_error=; unknown_reported=0
while :; do
    [ -f "$MODDIR/disable" ] && exit 0
    [ -f "$MODDIR/remove" ] && exit 0
    [ -r "$MODDIR/module.prop" ] || exit 0
    load_settings
    ds_auto_options
    before=$(ds_state)
    if [ "$MODE" = off ] && [ "$DS_AUTO" = 0 ] && [ "$before" = off ]; then
        log_line 'CPU profile paused and auto sleep disabled; stopping monitor.'
        exit 0
    fi
    physical_screen=$(screen_state) || physical_screen=UNKNOWN
    # The monotonic 60-minute timer, or a one-shot auto entry, runs independent
    # of CPU mode. In particular, MODE=off does NOT disable automatic sleep.
    if ! ds_tick "$physical_screen"; then tick_error=$DS_ERROR; else tick_error=; fi
    after=$(ds_state)
    if [ "$tick_error" != "$last_deep_error" ]; then
        [ -z "$tick_error" ] || log_line "DEEP_ERROR:$tick_error"
        last_deep_error=$tick_error
    fi
    if [ "$after" != "$last_deep_state" ]; then
        log_line "DEEP_STATE:$before->$after screen=$physical_screen; radios not restored on wake"
        last_deep_state=$after
    fi

    screen=MANUAL; wanted=none; reason=normal
    if [ "$MODE" = auto ]; then
        screen=$physical_screen
        case "$screen" in
            ON) wanted=$ON_GOVERNOR ;;
            OFF) wanted=$OFF_GOVERNOR ;;
            *) if [ "$unknown_reported" = 0 ]; then log_line 'SCREEN_UNKNOWN: CPU untouched'; unknown_reported=1; fi ;;
        esac
    elif [ "$MODE" != off ]; then
        wanted=$MODE
    fi
    if [ "$physical_screen" != UNKNOWN ]; then unknown_reported=0; fi
    if [ "$wanted" != none ]; then
        if [ "$MODE" = auto ]; then ay_guard "$wanted" "$screen"; else ay_guard "$wanted" ON; fi
        wanted=$AY_TARGET; reason=$AY_REASON
    fi
    if [ "$after" = active ] || [ "$after" = partial ] || [ "$after" = entering ]; then
        wanted=powersave; reason=deep_sleep
    fi

    checked=0; changed=0; failed=0; failure_details=
    if [ "$wanted" = none ] || [ "$CAPTURED" != 1 ]; then
        # The screen countdown still runs, even on unsupported kernels.
        [ "$CAPTURED" != 1 ] || restore_governors
    else
        for pol in "$POLICY_ROOT"/policy*; do
            [ -r "$pol/scaling_governor" ] || continue
            name=${pol##*/}
            checked=$((checked+1))
            if ! gov_supported "$pol" "$wanted"; then
                failed=$((failed+1))
                failure_details="$failure_details $name:unsupported"
                continue
            fi
            current=$(gov_read "$pol/scaling_governor")
            if [ "$current" != "$wanted" ]; then
                if gov_write_verify "$pol" "$wanted"; then
                    changed=$((changed+1))
                    [ "$(gov_read "$MODDIR/applied.$name" 2>/dev/null)" = "$wanted" ] || printf '%s\n' "$wanted" > "$MODDIR/applied.$name"
                else
                    failed=$((failed+1))
                    failure_details="$failure_details $name:$GOV_WRITE_ERROR"
                fi
            fi
        done
    fi
    # Per-policy frequency tuning is screen-ON, non-sleep, and opt-in only.
    freq_screen=OFF
    if [ "$MODE" = auto ] && [ "$screen" = ON ] && [ "$reason" = normal ]; then freq_screen=ON; fi
    freq_error=
    if [ "$CAPTURED" = 1 ] && ! freq_apply_screen "$freq_screen"; then freq_error=${FREQ_ERROR:-unknown}; fi
    if [ "$freq_error" != "$last_freq_error" ]; then
        [ -z "$freq_error" ] || log_line "FREQ_ERROR:$freq_error"
        last_freq_error=$freq_error
    fi
    if [ "$failure_details" != "$last_failure_details" ]; then
        [ -z "$failure_details" ] || log_line "GOVERNOR_ERROR:$failure_details"
        last_failure_details=$failure_details
    fi
    if [ "$MODE" != "$last_mode" ] || [ "$physical_screen" != "$last_screen" ] || [ "$wanted" != "$last_wanted" ] || [ "$reason" != "$last_reason" ] || [ "$before" != "$after" ]; then
        log_line "mode=$MODE screen=$physical_screen wanted=$wanted reason=$reason policies=$checked changed=$changed failed=$failed"
        printf '%s\n' "$physical_screen" > "$MODDIR/last_screen"
        last_mode=$MODE; last_screen=$physical_screen; last_wanted=$wanted; last_reason=$reason
        ay_update_description "$physical_screen" "$reason" "$wanted" || :
    fi
    # 3s when OFF avoids constant heavy dumpsys activity; wake returns CPU
    # policy on the next poll. Monotonic auto timer still starts from first OFF.
    if [ "$physical_screen" = OFF ]; then sleep 3; else sleep "$POLL_SECONDS"; fi
done
