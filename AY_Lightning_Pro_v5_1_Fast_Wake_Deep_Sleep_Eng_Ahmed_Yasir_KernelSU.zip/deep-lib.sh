#!/system/bin/sh
# AY Lightning Pro deep-sleep engine. No forcing Doze, no system-app force-stop.
# Sourced by control.sh and monitor.sh. All file content is enumerated/validated.
DS_DIR=${AY_DATA_DIR:-/data/adb/ay_lightning}/deep
DS_CMD=${YASIR_CMD:-/system/bin/cmd}
DS_SETTINGS=${YASIR_SETTINGS:-/system/bin/settings}
DS_AM=${YASIR_AM:-/system/bin/am}
DS_ERROR=

ds_state() {
    if [ ! -s "$DS_DIR/state" ]; then printf off; return; fi
    ds_value=$(cat "$DS_DIR/state" 2>/dev/null)
    case "$ds_value" in armed|entering|active|restoring) printf '%s' "$ds_value" ;; *) printf off ;; esac
}
ds_write_state() {
    mkdir -p "$DS_DIR" || return 1
    chmod 700 "$DS_DIR" 2>/dev/null || :
    (umask 077; printf '%s\n' "$1" > "$DS_DIR/.state.$$") || return 1
    mv -f "$DS_DIR/.state.$$" "$DS_DIR/state"
}
ds_options() {
    DS_AIR=1; DS_WIFI=1; DS_BT=0; DS_KILL=0; DS_TIMEOUT=480
    if [ -s "$DS_DIR/options" ]; then
        read -r DS_AIR DS_WIFI DS_BT DS_KILL DS_TIMEOUT < "$DS_DIR/options" || :
    fi
    for ds_bool in "$DS_AIR" "$DS_WIFI" "$DS_BT" "$DS_KILL"; do
        case "$ds_bool" in 0|1) : ;; *) DS_ERROR=invalid_sleep_options; return 1 ;; esac
    done
    case "$DS_TIMEOUT" in 60|240|480) : ;; *) DS_ERROR=invalid_sleep_timeout; return 1 ;; esac
}
ds_save_options() {
    DS_ERROR=
    case "${1:-}" in 0|1) : ;; *) DS_ERROR=invalid_airplane; return 1 ;; esac
    case "${2:-}" in 0|1) : ;; *) DS_ERROR=invalid_wifi; return 1 ;; esac
    case "${3:-}" in 0|1) : ;; *) DS_ERROR=invalid_bluetooth; return 1 ;; esac
    case "${4:-}" in 0|1) : ;; *) DS_ERROR=invalid_cached_apps; return 1 ;; esac
    case "${5:-}" in 60|240|480) : ;; *) DS_ERROR=invalid_timeout; return 1 ;; esac
    mkdir -p "$DS_DIR" || { DS_ERROR=cannot_create_storage; return 1; }
    chmod 700 "$DS_DIR" 2>/dev/null || :
    (umask 077; printf '%s %s %s %s %s\n' "$1" "$2" "$3" "$4" "$5" > "$DS_DIR/.opts.$$") || return 1
    mv -f "$DS_DIR/.opts.$$" "$DS_DIR/options" || return 1
    return 0
}
ds_read_air() {
    ds_read_air_value=$($DS_SETTINGS get global airplane_mode_on 2>/dev/null)
    case "$ds_read_air_value" in 0|1) printf '%s' "$ds_read_air_value" ;; *) return 1 ;; esac
}
ds_read_wifi() {
    # Reliable on Android 12+: the Wi-Fi service's actual state, not only a preference.
    ds_wifi_info=$($DS_CMD wifi status 2>/dev/null)
    case "$ds_wifi_info" in
        *'Wifi is enabled'*|*'Wi-Fi is enabled'*) printf 1; return 0 ;;
        *'Wifi is disabled'*|*'Wi-Fi is disabled'*) printf 0; return 0 ;;
    esac
    ds_wifi_value=$($DS_SETTINGS get global wifi_on 2>/dev/null)
    case "$ds_wifi_value" in 1|2) printf 1 ;; 0|3) printf 0 ;; *) return 1 ;; esac
}
ds_read_bt() {
    ds_bt_value=$($DS_SETTINGS get global bluetooth_on 2>/dev/null)
    case "$ds_bt_value" in 0|1) printf '%s' "$ds_bt_value" ;; *) return 1 ;; esac
}
ds_verify() {
    ds_which=$1; ds_expect=$2; ds_wait=0
    while [ "$ds_wait" -lt 4 ]; do
        case "$ds_which" in
            air) ds_got=$(ds_read_air 2>/dev/null) ;; wifi) ds_got=$(ds_read_wifi 2>/dev/null) ;; bt) ds_got=$(ds_read_bt 2>/dev/null) ;;
        esac
        [ "$ds_got" = "$ds_expect" ] && return 0
        ds_wait=$((ds_wait + 1))
        sleep 0.4
    done
    DS_ERROR="${ds_which}_verify_failed"
    return 1
}
ds_air_set() {
    if [ "$1" = 1 ]; then ds_arg=enable; else ds_arg=disable; fi
    "$DS_CMD" connectivity airplane-mode "$ds_arg" >/dev/null 2>&1 || { DS_ERROR=airplane_command_failed; return 1; }
    ds_verify air "$1"
}
ds_wifi_set() {
    if [ "$1" = 1 ]; then ds_arg=enabled; else ds_arg=disabled; fi
    "$DS_CMD" wifi set-wifi-enabled "$ds_arg" >/dev/null 2>&1 || { DS_ERROR=wifi_command_failed; return 1; }
    ds_verify wifi "$1"
}
ds_bt_set() {
    if [ "$1" = 1 ]; then ds_arg=enable; else ds_arg=disable; fi
    "$DS_CMD" bluetooth_manager "$ds_arg" >/dev/null 2>&1 || { DS_ERROR=bluetooth_command_failed; return 1; }
    ds_verify bt "$1"
}
ds_restore() {
    DS_ERROR=
    if [ ! -s "$DS_DIR/snapshot" ]; then
        DS_ERROR=missing_radio_snapshot
        return 1
    fi
    read -r ds_prev_air ds_prev_wifi ds_prev_bt < "$DS_DIR/snapshot" || return 1
    case "$ds_prev_air:$ds_prev_wifi:$ds_prev_bt" in
        *[!01x:]*) DS_ERROR=invalid_radio_snapshot; return 1 ;;
    esac
    ds_write_state restoring || return 1
    ds_restore_failed=0; ds_restore_reason=
    if [ "$ds_prev_air" != x ]; then
        ds_cur=$(ds_read_air 2>/dev/null) || ds_cur=x
        if [ "$ds_cur" != "$ds_prev_air" ]; then
            ds_air_set "$ds_prev_air" || { ds_restore_failed=1; ds_restore_reason="$ds_restore_reason $DS_ERROR"; }
        fi
    fi
    if [ "$ds_prev_wifi" != x ]; then
        ds_cur=$(ds_read_wifi 2>/dev/null) || ds_cur=x
        if [ "$ds_cur" != "$ds_prev_wifi" ]; then
            ds_wifi_set "$ds_prev_wifi" || { ds_restore_failed=1; ds_restore_reason="$ds_restore_reason $DS_ERROR"; }
        fi
    fi
    if [ "$ds_prev_bt" != x ]; then
        ds_cur=$(ds_read_bt 2>/dev/null) || ds_cur=x
        if [ "$ds_cur" != "$ds_prev_bt" ]; then
            ds_bt_set "$ds_prev_bt" || { ds_restore_failed=1; ds_restore_reason="$ds_restore_reason $DS_ERROR"; }
        fi
    fi
    if [ "$ds_restore_failed" -ne 0 ]; then
        DS_ERROR="restore_failed:$ds_restore_reason"
        return 1
    fi
    rm -f "$DS_DIR/snapshot" "$DS_DIR/activated" "$DS_DIR/state"
    DS_ERROR=
    return 0
}
ds_arm() {
    DS_ERROR=
    ds_current=$(ds_state)
    [ "$ds_current" = off ] || { DS_ERROR="already_$ds_current"; return 1; }
    ds_options || return 1
    # Fail closed: if state cannot be read, radio restoration cannot be guaranteed.
    ds_read_air >/dev/null 2>&1 || { DS_ERROR=airplane_state_unavailable; return 1; }
    ds_read_wifi >/dev/null 2>&1 || { DS_ERROR=wifi_state_unavailable; return 1; }
    if [ "$DS_BT" = 1 ]; then
        ds_read_bt >/dev/null 2>&1 || { DS_ERROR=bluetooth_state_unavailable; return 1; }
    fi
    ds_write_state armed || { DS_ERROR=cannot_arm; return 1; }
}
ds_enter() {
    DS_ERROR=
    ds_options || return 1
    ds_before_air=$(ds_read_air 2>/dev/null) || { DS_ERROR=airplane_snapshot_failed; return 1; }
    ds_before_wifi=$(ds_read_wifi 2>/dev/null) || { DS_ERROR=wifi_snapshot_failed; return 1; }
    ds_before_bt=$(ds_read_bt 2>/dev/null) || ds_before_bt=x
    if [ "$DS_BT" = 1 ] && [ "$ds_before_bt" = x ]; then
        DS_ERROR=bluetooth_snapshot_failed; return 1
    fi
    # Durable snapshot must exist BEFORE the first connectivity change.
    (umask 077; printf '%s %s %s\n' "$ds_before_air" "$ds_before_wifi" "$ds_before_bt" > "$DS_DIR/.snapshot.$$") || return 1
    mv -f "$DS_DIR/.snapshot.$$" "$DS_DIR/snapshot" || return 1
    ds_write_state entering || return 1
    if [ "$DS_AIR" = 1 ] && [ "$ds_before_air" = 0 ]; then
        if ! ds_air_set 1; then ds_failure=$DS_ERROR; ds_restore || :; DS_ERROR="enter_$ds_failure"; return 1; fi
    fi
    if [ "$DS_WIFI" = 1 ]; then
        ds_current_wifi=$(ds_read_wifi 2>/dev/null) || ds_current_wifi=x
        if [ "$ds_current_wifi" != 0 ]; then
            if ! ds_wifi_set 0; then ds_failure=$DS_ERROR; ds_restore || :; DS_ERROR="enter_$ds_failure"; return 1; fi
        fi
    fi
    if [ "$DS_BT" = 1 ]; then
        ds_current_bt=$(ds_read_bt 2>/dev/null) || ds_current_bt=x
        if [ "$ds_current_bt" != 0 ]; then
            if ! ds_bt_set 0; then ds_failure=$DS_ERROR; ds_restore || :; DS_ERROR="enter_$ds_failure"; return 1; fi
        fi
    fi
    # Only kill cached processes that Android considers safe to kill.
    # No force-stop of system/user apps, no deletion of application data.
    if [ "$DS_KILL" = 1 ]; then
        "$DS_AM" kill-all >/dev/null 2>&1 || :
    fi
    date +%s > "$DS_DIR/activated"
    ds_write_state active || return 1
    DS_ERROR=
    return 0
}
ds_cancel() {
    DS_ERROR=
    ds_current=$(ds_state)
    case "$ds_current" in
        off) return 0 ;;
        armed) rm -f "$DS_DIR/state"; return 0 ;;
        entering|active|restoring) ds_restore ;;
    esac
}
ds_tick() {
    # Caller must detect screen ON/OFF; UNKNOWN never arms or wakes the radio.
    ds_physical_screen=$1
    ds_current=$(ds_state)
    case "$ds_current" in
        armed)
            [ "$ds_physical_screen" = OFF ] || return 0
            ds_enter ;;
        entering|active|restoring)
            if [ "$ds_physical_screen" = ON ]; then ds_restore; return; fi
            if [ "$ds_current" = restoring ]; then ds_restore; return; fi
            ds_options || return 1
            ds_when=$(cat "$DS_DIR/activated" 2>/dev/null)
            case "$ds_when" in ''|*[!0-9]*) return 0 ;; esac
            ds_now=$(date +%s)
            if [ "$ds_now" -ge $((ds_when + DS_TIMEOUT * 60)) ]; then ds_restore; fi
            ;;
    esac
    return 0
}
# Invoked at reboot to repair a sleep state that could otherwise persist.
if [ "${1:-}" = '--boot-recover' ]; then
    ds_round=0
    while [ "$(${YASIR_GETPROP:-/system/bin/getprop} sys.boot_completed 2>/dev/null)" != 1 ] && [ "$ds_round" -lt 120 ]; do
        sleep 2
        ds_round=$((ds_round + 1))
    done
    if [ "$(ds_state)" != off ]; then
        ds_cancel || printf '%s | BOOT_RADIO_RESTORE_FAIL %s\n' "$(date)" "$DS_ERROR" >> "$MODDIR/status.log"
    fi
fi
