AY LIGHTNING PRO v5.1 — FAST WAKE + OPTIONAL DEEP SLEEP
Developed & Designed by Eng/ Ahmed Yasir / المهندس أحمد ياسر
For KernelSU Next / Android 14 (tested in mocks, not on actual Realme 7 Pro)

==================== عربي ====================
ما الجديد؟
- 5 بروفايلات بدون تكرار غير مفيد:
  1. الأداء الأقصى: performance أثناء التشغيل / powersave عند الإطفاء.
  2. المتوازن: schedutil أثناء التشغيل / powersave عند الإطفاء.
  3. الثبات: schedutil مع حماية إضافية عند نسبة بطارية 25% وحرارة بطارية 40°C، وpowersave أثناء الإطفاء.
  4. الاقتصادي: conservative أثناء التشغيل / powersave عند الإطفاء.
  5. التوفير الشديد: powersave طوال الوقت.
- إزالة Gaming/Charging/Smart/Adaptive لأن بعضها كان يكرر بروفايلات أخرى تقريبًا.
- سرعة استجابة محسّنة عند إضاءة الشاشة: فحص كل ثانية تقريبًا أثناء الإطفاء، بدل 8 ثوانٍ لوضع الثبات.
  المدة الفعلية تعتمد على ROM ووقت تنفيذ dumpsys وPower HAL.
- خط تصميم جديد لاسم المطور بالعربي والإنجليزي في WebUI، مع دعم اللغة والمظهر الفاتح/الداكن.
- تبويب «النوم» اختياري لتقليل الاتصالات اللاسلكية عند إطفاء الشاشة فقط.

كيف تعمل ميزة النوم العميق؟
1. افتح WebUI، واختر بروفايلًا نشطًا.
2. افتح تبويب «النوم»، واختر خياراتك (الافتراضي: وضع الطيران + إيقاف Wi-Fi).
3. اختَر وقت الاستعادة الاحتياطي: 1 أو 4 أو 8 ساعات.
4. اضغط «تجهيز النوم» واقرأ التحذير، ثم اقفل الشاشة.
5. عند إطفاء الشاشة: حفظ الحالات السابقة ثم تنفيذ الأوامر والتحقق من نجاحها.
6. عند إضاءة الشاشة أو نهاية المهلة: استعادة حالة وضع الطيران/Wi-Fi/Bluetooth السابقة.
7. يمكنك إلغاء النوم من WebUI/Termux؛ التفعيل لا يتكرر من نفسه بعد الاستيقاظ.

تحذير أساسي:
- وضع الطيران يقطع اتصال الشريحة: المكالمات، SMS، إنترنت الهاتف والتنبيهات المعتمدة على الشبكة.
- لا تستخدمه لو كنت تنتظر مكالمة أو تنبيه طوارئ. هذا ليس إغلاقًا حقيقيًا للهاتف.
- البلوتوث اختياري. إغلاق تطبيقات الخلفية اختيار منفصل (افتراضيًا مغلق)، يستخدم am kill-all
  للتطبيقات التي يعتبرها Android قابلة للإغلاق؛ لا يجمد خدمات النظام ولا يضمن إغلاق جميع التطبيقات.
  ربما تضيع حالة عمل غير محفوظة في التطبيقات المؤقتة.
- لا يعطل الحماية الحرارية أو SELinux ولا يعدّل الفولتية أو يفرض Deep Doze.
- لا تترك DeepDoze Enforcer أو أدوات أخرى تتحكم بالـCPU/الشبكات بطريقة متعارضة.
- الاسترجاع بعد الإيقاظ يعتمد على أن خدمة الموديول تعمل. على الرومات المعدلة قد تختلف أوامر الاتصال.
- حفظ الإعدادات السابقة لا يعني إمكانية استعادتها إذا تعطّل النظام بالكامل أو أُزيل الموديول أثناء النوم.

التحكم من Termux:
 su
 sh /data/adb/modules/eng_ahmed_yasir_screen_gov/control.sh status
 sh /data/adb/modules/eng_ahmed_yasir_screen_gov/control.sh deep-cancel
 sh /data/adb/modules/eng_ahmed_yasir_screen_gov/control.sh logs

إذا ظل وضع الطيران فعالًا بسبب تعطل الخدمة أو حذف الموديول، افتح Termux مع Root ونفّذ:
 su -c 'cmd connectivity airplane-mode disable'
ثم شغّل Wi-Fi يدويًا من الإعدادات عند الحاجة. الأمر السابق يلغي وضع الطيران عمدًا، حتى لو كان مفعّلًا قبل النوم.
إذا لم يُفلح الأمر، استخدم إعدادات Android السريعة لإيقاف وضع الطيران.

التحديث: ثبّت ZIP من KernelSU Next فوق v5.0 ثم أعد التشغيل. المعرف لم يتغير.
الإعدادات السابقة تحفظ في /data/adb/ay_lightning/، وقد تظهر البروفايلات القديمة المحذوفة
على أنها «مخصص» حتى تختار أحد الأوضاع الخمسة الجديدة. احتفظ بملف v5.0 للرجوع إليه.

==================== ENGLISH ====================
Profiles: Maximum (performance), Balanced (schedutil), Stability (schedutil + 25%/40C
battery safeguards), Economy (conservative), Ultra Saver (powersave). All auto profiles
use powersave with screen OFF. Duplicate Gaming/Charging/Smart/Adaptive presets removed.

FAST WAKE: When the screen is off, the governor monitor checks display state about
once per second instead of eight seconds. The actual response can vary by ROM/kernel;
faster polling has a small battery cost.

OPTIONAL DEEP SLEEP (one-shot): Arm it in WebUI, then switch the display off. When
screen OFF is detected, the module snapshots the state of airplane mode, Wi-Fi and
Bluetooth, enables airplane mode, turns Wi-Fi off and optionally Bluetooth off.
Android's 'am kill-all' (cached/safe-to-kill apps only) is a separate OFF-by-default
choice. The previous radios are restored after wake or after an optional safety
period of 1/4/8 hours. If a command fails, the module attempts rollback.

WARNING: Airplane mode prevents normal incoming calls, SMS, mobile data and network
notifications; it is unsuitable when expecting urgent contacts. Android continues
running essential services. This is NOT the same as powering a phone completely off.
The module does not disable thermal limits or SELinux; it does not force full Doze.

Manual emergency recovery (with root):
  su -c 'cmd connectivity airplane-mode disable'
Then reconnect Wi-Fi from Android settings if required.

Only the first five profiles above are offered as presets. Existing custom setups
and legacy backups remain readable; selecting a new preset resets its own guards.

For support, use WebUI > Tools > Diagnostics / Logs or control.sh status.
This package was validated with mocked Android services; it has NOT been tested
on the actual ShadowClaseX kernel before the user installs it.
