#!/system/bin/sh
# KernelSU Next / Magisk module customization.
# ASCII installation intro is printed within the manager's installer console.
ui_print "##############################################"
ui_print "#                                            #"
ui_print "#        A Y   L I G H T N I N G         #"
ui_print "#                                            #"
ui_print "#         DEVELOPED  &  DESIGNED  BY         #"
ui_print "#                                            #"
ui_print "#        ###  #   # #   # ##### ####         #"
ui_print "#       #   # #   # ## ## #     #   #        #"
ui_print "#       #   # #   # # # # #     #   #        #"
ui_print "#       ##### ##### # # # ####  #   #        #"
ui_print "#       #   # #   # #   # #     #   #        #"
ui_print "#       #   # #   # #   # #     #   #        #"
ui_print "#       #   # #   # #   # ##### ####         #"
ui_print "#                                            #"
ui_print "#       #   #  ###   #### ##### ####         #"
ui_print "#       #   # #   # #       #   #   #        #"
ui_print "#        # #  #   # #       #   #   #        #"
ui_print "#         #   #####  ###    #   ####         #"
ui_print "#         #   #   #     #   #   # #          #"
ui_print "#         #   #   #     #   #   #  #         #"
ui_print "#         #   #   # ####  ##### #   #        #"
ui_print "#                                            #"
ui_print "#              Eng/ Ahmed Yasir              #"
ui_print "#                                            #"
ui_print "##############################################"
ui_print ""
ui_print "AY LIGHTNING PRO v5.1 - DUAL LANGUAGE EDITION"
ui_print "[1/5] Checking for competing screen governor module..."
OLD=/data/adb/modules/screen_governor_switch
if [ -d "$OLD" ] && [ ! -e "$OLD/disable" ] && [ ! -e "$OLD/remove" ]; then
  ui_print "! Old screen_governor_switch is STILL enabled."
  ui_print "! Disable/remove it in KernelSU Next, REBOOT, retry."
  abort "! Stopping to prevent competing CPU governor services."
fi
ui_print "[OK] No active conflicting old screen governor module."
ui_print "[2/5] Checking kernel CPU governor support..."
COUNT=0
INSTALL_POLICY_ROOT=${YASIR_INSTALL_POLICY_ROOT:-/sys/devices/system/cpu/cpufreq}
for P in "$INSTALL_POLICY_ROOT"/policy*; do
  [ -r "$P/scaling_available_governors" ] || continue
  COUNT=$((COUNT + 1))
  AVAL="$(cat "$P/scaling_available_governors" 2>/dev/null)"
  case " $AVAL " in *" performance "*) : ;; *) abort "! ${P##*/} has no performance governor." ;; esac
  case " $AVAL " in *" powersave "*) : ;; *) abort "! ${P##*/} has no powersave governor." ;; esac
  ui_print "[OK] ${P##*/}: performance + powersave available."
done
[ "$COUNT" -gt 0 ] || abort "! No CPU frequency policies detected."
ui_print "[3/5] Checking device battery telemetry (read-only)..."
if [ -r /sys/class/power_supply/battery/capacity ]; then
  ui_print "[OK] Battery monitoring available."
else
  ui_print "[!] Battery telemetry unavailable; smart safeguards stay inactive."
fi
ui_print "[4/5] Preparing profiles and preserving current setup..."
# v4 persists config independently from the module folder, so updates retain it.
# Back up v3 config from Termux BEFORE upgrade (instructions in README).
PERSIST=${AY_DATA_DIR:-/data/adb/ay_lightning}
mkdir -p "$PERSIST" || abort "! Cannot create persistent settings directory."
chmod 700 "$PERSIST" 2>/dev/null || :
OLD_AY=/data/adb/modules/eng_ahmed_yasir_screen_gov
if [ -s "$PERSIST/config.conf" ]; then
  cp -f "$PERSIST/config.conf" "$MODPATH/config.conf" || abort "! Cannot import saved config."
  ui_print "[OK] Saved profile restored from persistent storage."
elif [ "$OLD_AY" != "$MODPATH" ] && [ -s "$OLD_AY/config.conf" ]; then
  cp -f "$OLD_AY/config.conf" "$MODPATH/config.conf" || abort "! Cannot import previous config."
  ui_print "[OK] v3 profile imported."
else
  ui_print "[OK] Fresh install: governor remains stock until you select a profile."
fi
if [ -s "$PERSIST/safety.conf" ]; then
  cp -f "$PERSIST/safety.conf" "$MODPATH/safety.conf" || abort "! Cannot import saved safeguards."
fi
cp -f "$MODPATH/config.conf" "$PERSIST/config.conf" 2>/dev/null || :
cp -f "$MODPATH/safety.conf" "$PERSIST/safety.conf" 2>/dev/null || :
ui_print "[OK] 5 DISTINCT profiles: EXTREME / BALANCED / STABILITY / QUIET / ULTRA."
ui_print "[OK] Deep Sleep is OPT-IN: wake restores saved Wi-Fi and airplane state."
ui_print "[OK] Original CPU values restored on pause; never bypass thermals."
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/monitor.sh" 0 0 0755
set_perm "$MODPATH/governor-lib.sh" 0 0 0644
set_perm "$MODPATH/safety-lib.sh" 0 0 0644
set_perm "$MODPATH/status-lib.sh" 0 0 0644
set_perm "$MODPATH/freq-lib.sh" 0 0 0644
set_perm "$MODPATH/backup-lib.sh" 0 0 0644
set_perm "$MODPATH/deep-lib.sh" 0 0 0644
set_perm "$MODPATH/control.sh" 0 0 0755
set_perm "$MODPATH/check.sh" 0 0 0755
set_perm "$MODPATH/action.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
ui_print "[OK] Runtime scripts marked executable."
ui_print "[5/5] Verifying banner and interactive WebUI assets..."
[ -f "$MODPATH/banner.png" ] || abort "! Branding banner missing from ZIP."
[ -f "$MODPATH/webroot/index.html" ] || abort "! WebUI files missing from ZIP."
[ -f "$MODPATH/control.sh" ] || abort "! Control backend missing from ZIP."
[ -f "$MODPATH/governor-lib.sh" ] || abort "! Governor helper missing from ZIP."
[ -f "$MODPATH/safety-lib.sh" ] || abort "! Safeguard helper missing from ZIP."
[ -f "$MODPATH/status-lib.sh" ] || abort "! Live module description helper missing from ZIP."
[ -f "$MODPATH/freq-lib.sh" ] || abort "! Frequency management helper missing from ZIP."
[ -f "$MODPATH/backup-lib.sh" ] || abort "! Backup manager missing from ZIP."
[ -f "$MODPATH/deep-lib.sh" ] || abort "! Deep Sleep recovery helper missing from ZIP."
ui_print "[OK] Live profile name will appear in KernelSU Next module description."
ui_print "[OK] Arabic/English WebUI + Dark/Light appearance installed."
ui_print "[OK] Optional CPU frequencies; stock limits retained by default."
if [ -d /data/adb/modules/deepdoze_enforcer ] && [ ! -f /data/adb/modules/deepdoze_enforcer/disable ]; then
  ui_print "[!] deepdoze_enforcer detected; review its CPU settings."
fi
ui_print ""
ui_print "##############################################"
ui_print "#  INSTALL COMPLETE - REBOOT REQUIRED        #"
ui_print "#  WebUI: PROFILES / CPU / SAFETY / TOOLS   #"
ui_print "#  Designed by Eng/ Ahmed Yasir              #"
ui_print "##############################################"
ui_print ""
