#!/system/bin/sh
# Eng/ Ahmed Yasir - Root CPU governor monitor (v5.1).
# CPU governors + optional validated screen-on CPU freq bounds. Thermals untouched.
MODDIR=${YASIR_MODDIR:-${0%/*}}
AY_DATA_DIR=${AY_DATA_DIR:-/data/adb/ay_lightning}
POLICY_ROOT=${YASIR_POLICY_ROOT:-/sys/devices/system/cpu/cpufreq}
DUMPSYS=${YASIR_DUMPSYS:-/system/bin/dumpsys}
GETPROP=${YASIR_GETPROP:-/system/bin/getprop}
. "$MODDIR/governor-lib.sh" || exit 1
. "$MODDIR/safety-lib.sh" || exit 1
. "$MODDIR/status-lib.sh" || exit 1
. "$MODDIR/freq-lib.sh" || exit 1
. "$MODDIR/deep-lib.sh" || exit 1
LOGFILE="$MODDIR/status.log"
PIDFILE="$MODDIR/monitor.pid"

MODE=off
ON_GOVERNOR=schedutil
OFF_GOVERNOR=powersave
POLL_SECONDS=3
load_settings() {
    MODE=off; ON_GOVERNOR=schedutil; OFF_GOVERNOR=powersave; POLL_SECONDS=3
    [ -r "$MODDIR/config.conf" ] && . "$MODDIR/config.conf"
    case "$MODE" in auto|performance|powersave|schedutil|off) : ;; *) MODE=auto ;; esac
    case "$ON_GOVERNOR" in performance|powersave|schedutil|ondemand|conservative) : ;; *) ON_GOVERNOR=performance ;; esac
    case "$OFF_GOVERNOR" in performance|powersave|schedutil|ondemand|conservative) : ;; *) OFF_GOVERNOR=powersave ;; esac
    case "$POLL_SECONDS" in 2|3|5|10) : ;; *) POLL_SECONDS=3 ;; esac
    LOW_BATTERY=off; HIGH_TEMP=off
    [ -r "$MODDIR/safety.conf" ] && . "$MODDIR/safety.conf"
    SAFE_BATTERY=$LOW_BATTERY; SAFE_TEMP=$HIGH_TEMP
    case "$SAFE_BATTERY" in off|15|20|25|30) : ;; *) SAFE_BATTERY=off ;; esac
    case "$SAFE_TEMP" in off|40|42|45|48) : ;; *) SAFE_TEMP=off ;; esac
}
log_line() {
    if [ -f "$LOGFILE" ] && [ "$(wc -c < "$LOGFILE" 2>/dev/null)" -gt 60000 ]; then
        tail -n 90 "$LOGFILE" > "$LOGFILE.tmp" 2>/dev/null && mv -f "$LOGFILE.tmp" "$LOGFILE"
    fi
    printf '%s | %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOGFILE"
}
screen_state() {
    power=$($DUMPSYS power 2>/dev/null) || return 1
    case "$power" in
        *'Display Power: state=OFF'*|*'Display Power: state=DOZE'*) printf OFF; return 0 ;;
        *'Display Power: state=ON'*) printf ON; return 0 ;;
    esac
    case "$power" in
        *'mWakefulness=Asleep'*|*'mWakefulness=Dozing'*) printf OFF; return 0 ;;
        *'mWakefulness=Awake'*|*'mWakefulness=Dreaming'*) printf ON; return 0 ;;
    esac
    return 1
}
restore_governors() {
    for pol in "$POLICY_ROOT"/policy*; do
        [ -r "$pol/scaling_governor" ] || continue
        name=${pol##*/}
        original=$(gov_read "$MODDIR/original.$name" 2>/dev/null) || continue
        applied=$(gov_read "$MODDIR/applied.$name" 2>/dev/null) || continue
        current=$(gov_read "$pol/scaling_governor" 2>/dev/null) || continue
        # Do not override an unrelated governor that another tool changed.
        [ "$current" = "$applied" ] || continue
        gov_supported "$pol" "$original" || continue
        if gov_write_verify "$pol" "$original"; then
            rm -f "$MODDIR/applied.$name"
        else
            log_line "RESTORE_FAIL $name reason=$GOV_WRITE_ERROR"
        fi
    done
}
on_exit() {
    ds_cancel || log_line "DEEP_RESTORE_ERROR:on_exit:$DS_ERROR"
    if [ "${CAPTURED:-0}" = 1 ]; then
        freq_restore_all || :
        restore_governors
    fi
    if [ -f "$MODDIR/disable" ] && [ ! -f "$MODDIR/remove" ]; then
        MODE=off
        ay_update_description MANUAL normal unknown || :
    fi
    if [ -r "$PIDFILE" ] && [ "$(gov_read "$PIDFILE")" = "$$" ]; then
        rm -f "$PIDFILE"
    fi
}
# Avoid duplicated processes when started by the manager and WebUI simultaneously.
if [ -r "$PIDFILE" ]; then
    oldpid=$(gov_read "$PIDFILE")
    case "$oldpid" in
        ''|*[!0-9]*) : ;;
        *) if [ "$oldpid" != "$$" ] && kill -0 "$oldpid" 2>/dev/null && [ -r "/proc/$oldpid/cmdline" ]; then
             oldcmd=$(tr '\000' ' ' < "/proc/$oldpid/cmdline" 2>/dev/null)
             case "$oldcmd" in *"$MODDIR/monitor.sh"*) exit 0 ;; esac
           fi ;;
    esac
fi
printf '%s\n' "$$" > "$PIDFILE" || exit 1
CAPTURED=0
trap 'exit 0' HUP INT TERM
trap 'on_exit' 0

count=0
while [ "$($GETPROP sys.boot_completed 2>/dev/null)" != 1 ]; do
    [ -f "$MODDIR/disable" ] && exit 0
    [ -f "$MODDIR/remove" ] && exit 0
    count=$((count + 1))
    if [ "$count" -ge 90 ]; then
        log_line 'ERROR: Boot not completed in 3 minutes.'
        exit 1
    fi
    sleep 2
done
sleep 1
# On a fresh boot (or service restart), fail-safe restore any saved radio state
# before normal CPU monitoring begins. Armed-only state is kept intact.
case "$(ds_state)" in
    entering|active|restoring)
        ds_restore || log_line "BOOT_DEEP_RESTORE_ERROR:$DS_ERROR" ;;
esac
load_settings
[ "$MODE" != off ] || exit 0
if ! gov_capture_baseline; then
    log_line 'ERROR: Could not capture original CPU governor values.'
    exit 1
fi
CAPTURED=1
freq_boot_prepare || log_line "WARNING: CPU frequency baseline not captured: ${FREQ_ERROR:-unknown}"
log_line "Service started v5.1; policies=$captured; mode=$MODE; interval=${POLL_SECONDS}s; uid=$(id -u 2>/dev/null); context=$(id -Z 2>/dev/null)"

last_mode=NONE
last_screen=UNKNOWN
last_wanted=NONE
last_reason=NONE
last_failure_details=
last_freq_error=
last_deep_state=off
last_deep_error=
unknown_reported=0
while :; do
    [ -f "$MODDIR/disable" ] && { log_line 'Module disabled. Restoring originals.'; exit 0; }
    [ -f "$MODDIR/remove" ] && { log_line 'Module removed. Restoring originals.'; exit 0; }
    [ -r "$MODDIR/module.prop" ] || { log_line 'Module removed. Restoring originals.'; exit 0; }
    load_settings
    [ "$MODE" != off ] || { log_line 'WebUI: Monitoring paused. Restoring originals.'; exit 0; }
    physical_screen=$(screen_state) || physical_screen=UNKNOWN
    screen=MANUAL
    if [ "$MODE" = auto ]; then
        screen=$physical_screen
        case "$screen" in
            ON) wanted=$ON_GOVERNOR ;;
            OFF) wanted=$OFF_GOVERNOR ;;
            *)
                if [ "$unknown_reported" -eq 0 ]; then
                    log_line 'WARNING: Cannot detect screen state via dumpsys power; no CPU change.'
                    unknown_reported=1
                fi
                sleep "$POLL_SECONDS"
                continue ;;
        esac
    else
        wanted=$MODE
    fi
    unknown_reported=0
    if [ "$MODE" = auto ]; then
        ay_guard "$wanted" "$screen"
    else
        ay_guard "$wanted" ON
    fi
    wanted=$AY_TARGET
    reason=$AY_REASON
    ds_before=$(ds_state)
    if [ "$physical_screen" = OFF ]; then
        case "$ds_before" in
            armed|entering|active|restoring) wanted=powersave; reason=deep_sleep ;;
        esac
    fi
    changed=0; failed=0; checked=0; failure_details=
    for pol in "$POLICY_ROOT"/policy*; do
        [ -r "$pol/scaling_governor" ] || continue
        name=${pol##*/}
        checked=$((checked+1))
        if ! gov_supported "$pol" "$wanted"; then
            failed=$((failed+1))
            failure_details="$failure_details $name:unsupported(avail=$GOVERNOR_AVAILABLE)"
            continue
        fi
        current=$(gov_read "$pol/scaling_governor")
        if [ "$current" != "$wanted" ]; then
            if gov_write_verify "$pol" "$wanted"; then
                changed=$((changed+1))
                [ "$(gov_read "$MODDIR/applied.$name" 2>/dev/null)" = "$wanted" ] || printf '%s\n' "$wanted" > "$MODDIR/applied.$name"
            else
                failed=$((failed+1))
                failure_details="$failure_details $name:$GOV_WRITE_ERROR"
            fi
        fi
    done
    # CPU bounds only while screen ON, in auto mode, without a safety override.
    freq_screen=$screen
    [ "$MODE" = auto ] && [ "$reason" = normal ] || freq_screen=OFF
    freq_error=
    if ! freq_apply_screen "$freq_screen"; then
        freq_error=${FREQ_ERROR:-unknown}
    fi
    if [ "$freq_error" != "$last_freq_error" ]; then
        if [ -n "$freq_error" ]; then
            log_line "FREQ_ERROR:$freq_error"
        elif [ -n "$last_freq_error" ]; then
            log_line 'CPU frequency limits recovered.'
        fi
        last_freq_error=$freq_error
    fi
    # Preserve wake responsiveness: apply governor BEFORE slow radio restoration.
    # Deep sleep radios activate only after display goes OFF, auto-restore on wake/timeout.
    if ! ds_tick "$physical_screen"; then
        ds_tick_error=$DS_ERROR
    else
        ds_tick_error=
    fi
    if [ "$ds_tick_error" != "$last_deep_error" ]; then
        [ -z "$ds_tick_error" ] || log_line "DEEP_ERROR:$ds_tick_error"
        last_deep_error=$ds_tick_error
    fi
    ds_after=$(ds_state)
    ay_desc_refresh=0
    if [ "$ds_after" != "$last_deep_state" ]; then
        log_line "DEEP_STATE:$ds_before->$ds_after screen=$physical_screen"
        last_deep_state=$ds_after
        ay_desc_refresh=1
    fi
    if [ "$MODE" != "$last_mode" ] || [ "$screen" != "$last_screen" ] || [ "$wanted" != "$last_wanted" ] || [ "$reason" != "$last_reason" ]; then
        log_line "mode=$MODE screen=$screen wanted=$wanted reason=$reason policies=$checked changed=$changed failed=$failed"
        printf '%s\n' "$screen" > "$MODDIR/last_screen"
        last_mode=$MODE; last_screen=$screen; last_wanted=$wanted; last_reason=$reason
        ay_desc_refresh=1
    fi
    if [ "$failure_details" != "$last_failure_details" ]; then
        if [ -n "$failure_details" ]; then
            log_line "ERROR governor write: wanted=$wanted$failure_details"
        elif [ -n "$last_failure_details" ]; then
            log_line 'Recovered: governor writes successful.'
        fi
        last_failure_details=$failure_details
        ay_desc_refresh=1
    fi
    # No extra polling process and no metadata writes on unchanged monitor ticks.
    if [ "$ay_desc_refresh" -eq 1 ]; then
        ay_update_description "$screen" "$reason" "$wanted" || :
    fi
    # All presets, including Stability, sample power state once per second in
    # screen-off mode, so performance can return quickly after a wake event.
    # This increases off-screen polling relative to the former 8s interval.
    if [ "$physical_screen" = OFF ]; then
        sleep 1
    else
        sleep "$POLL_SECONDS"
    fi
done
