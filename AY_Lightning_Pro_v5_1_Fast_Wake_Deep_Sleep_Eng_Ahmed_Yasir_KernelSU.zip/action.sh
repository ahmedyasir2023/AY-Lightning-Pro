#!/system/bin/sh
MODDIR=${YASIR_MODDIR:-${0%/*}}
/system/bin/sh "$MODDIR/check.sh"
