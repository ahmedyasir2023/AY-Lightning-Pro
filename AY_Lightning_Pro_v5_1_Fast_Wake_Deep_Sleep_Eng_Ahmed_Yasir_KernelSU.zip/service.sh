#!/system/bin/sh
# Late-start service, starts the single lightweight monitor.
MODDIR=${YASIR_MODDIR:-${0%/*}}
AY_DATA_DIR=${AY_DATA_DIR:-/data/adb/ay_lightning}
# If the CPU service is paused, still repair any previously active airplane mode.
# When running, monitor.sh handles recovery itself to avoid two concurrent restores.
[ -f "$MODDIR/disable" ] && exit 0
[ -f "$MODDIR/remove" ] && exit 0
if [ -r "$MODDIR/config.conf" ] && grep -q '^MODE=off$' "$MODDIR/config.conf"; then
    case "$(cat "$AY_DATA_DIR/deep/state" 2>/dev/null)" in
        armed|entering|active|restoring)
            ${YASIR_SHELL:-/system/bin/sh} "$MODDIR/deep-lib.sh" --boot-recover >/dev/null 2>&1 & ;;
    esac
    exit 0
fi
if [ -r "$MODDIR/monitor.pid" ]; then
    OLD_PID=$(cat "$MODDIR/monitor.pid" 2>/dev/null)
    case "$OLD_PID" in
        ''|*[!0-9]*) : ;;
        *) if kill -0 "$OLD_PID" 2>/dev/null && [ -r "/proc/$OLD_PID/cmdline" ]; then
            CMD=$(tr '\000' ' ' < "/proc/$OLD_PID/cmdline" 2>/dev/null)
            case "$CMD" in *"$MODDIR/monitor.sh"*) exit 0 ;; esac
        fi ;;
    esac
fi
${YASIR_SHELL:-/system/bin/sh} "$MODDIR/monitor.sh" >/dev/null 2>&1 &
exit 0
