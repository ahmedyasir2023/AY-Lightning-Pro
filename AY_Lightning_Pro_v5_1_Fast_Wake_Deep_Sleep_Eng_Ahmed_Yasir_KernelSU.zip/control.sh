#!/system/bin/sh
# AY Lightning Pro v5.1 - validated, privileged KernelSU Next WebUI backend.
# Usage: control.sh status|logs|set-profile ID|set-mode MODE|set-auto ON OFF INTERVAL|start|apply-now
MODDIR=${YASIR_MODDIR:-${0%/*}}
AY_DATA_DIR=${AY_DATA_DIR:-/data/adb/ay_lightning}
AY_MODULES_DIR=${AY_MODULES_DIR:-/data/adb/modules}
POLICY_ROOT=${YASIR_POLICY_ROOT:-/sys/devices/system/cpu/cpufreq}
DUMPSYS=${YASIR_DUMPSYS:-/system/bin/dumpsys}
CONFIG="$MODDIR/config.conf"
. "$MODDIR/governor-lib.sh" || exit 1
. "$MODDIR/safety-lib.sh" || exit 1
. "$MODDIR/status-lib.sh" || exit 1
. "$MODDIR/freq-lib.sh" || exit 1
. "$MODDIR/backup-lib.sh" || exit 1
. "$MODDIR/deep-lib.sh" || exit 1

MODE=off
ON_GOVERNOR=schedutil
OFF_GOVERNOR=powersave
POLL_SECONDS=3
[ -r "$CONFIG" ] && . "$CONFIG"
LOW_BATTERY=off
HIGH_TEMP=off
[ -r "$MODDIR/safety.conf" ] && . "$MODDIR/safety.conf"
SAFE_BATTERY=$LOW_BATTERY
SAFE_TEMP=$HIGH_TEMP
case "$SAFE_BATTERY" in off|15|20|25|30) : ;; *) SAFE_BATTERY=off ;; esac
case "$SAFE_TEMP" in off|40|42|45|48) : ;; *) SAFE_TEMP=off ;; esac

allowed_gov() {
    case "$1" in performance|powersave|schedutil|ondemand|conservative) return 0 ;; esac
    return 1
}
allowed_mode() {
    case "$1" in auto|performance|powersave|schedutil|off) return 0 ;; esac
    return 1
}
valid_interval() {
    case "$1" in 2|3|5|10) return 0 ;; esac
    return 1
}
# Five behaviourally distinct presets; removed duplicates from v5.0.
# Stability differs from balanced through real battery/thermal guard thresholds.
profile_governor() {
    case "$1" in
        extreme) printf performance ;;
        normal|stability) printf schedutil ;;
        quiet) printf conservative ;;
        ultra) printf powersave ;;
        *) return 1 ;;
    esac
}
active_profile() {
    [ "$MODE" = auto ] || { printf manual; return; }
    [ "$OFF_GOVERNOR" = powersave ] || { printf custom; return; }
    selected=$(gov_read "$AY_DATA_DIR/profile.id" 2>/dev/null)
    case "$selected" in
        extreme|normal|quiet|ultra)
            selected_on=$(profile_governor "$selected")
            [ "$ON_GOVERNOR" = "$selected_on" ] && [ "$SAFE_BATTERY" = off ] && [ "$SAFE_TEMP" = off ] && { printf '%s' "$selected"; return; } ;;
        stability)
            [ "$ON_GOVERNOR" = schedutil ] && [ "$SAFE_BATTERY" = 25 ] && [ "$SAFE_TEMP" = 40 ] && { printf stability; return; } ;;
    esac
    # Display the previous release's removed presets as Custom without altering them.
    [ "$SAFE_BATTERY" = off ] && [ "$SAFE_TEMP" = off ] || { printf custom; return; }
    case "$ON_GOVERNOR" in
        performance) printf extreme ;; schedutil) printf normal ;;
        conservative) printf quiet ;; powersave) printf ultra ;; *) printf custom ;;
    esac
}
check_governor() {
    wanted=$1
    found=0
    for pol in "$POLICY_ROOT"/policy*; do
        [ -r "$pol/scaling_available_governors" ] || continue
        found=$((found+1))
        if ! gov_supported "$pol" "$wanted"; then
            printf 'ERROR|Governor %s unsupported on %s (available: %s)\n' "$wanted" "${pol##*/}" "$GOVERNOR_AVAILABLE"
            return 1
        fi
    done
    [ "$found" -gt 0 ] || { printf 'ERROR|No CPU policies found\n'; return 1; }
}
monitor_pid() {
    [ -r "$MODDIR/monitor.pid" ] || return 1
    PID=$(gov_read "$MODDIR/monitor.pid")
    case "$PID" in ''|*[!0-9]*) return 1 ;; esac
    kill -0 "$PID" 2>/dev/null || return 1
    [ -r "/proc/$PID/cmdline" ] || return 1
    CMD=$(tr '\000' ' ' < "/proc/$PID/cmdline" 2>/dev/null)
    case "$CMD" in *"$MODDIR/monitor.sh"*) printf '%s' "$PID"; return 0 ;; esac
    return 1
}
log_control() {
    printf '%s | WebUI %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$MODDIR/status.log"
}
save_config() {
    # Only enumerated and validated values reach this function.
    tmppath="$MODDIR/.config.tmp.$$"
    (umask 077; printf 'MODE=%s\nON_GOVERNOR=%s\nOFF_GOVERNOR=%s\nPOLL_SECONDS=%s\n' "$1" "$2" "$3" "$4" > "$tmppath") || return 1
    mv -f "$tmppath" "$CONFIG" || { rm -f "$tmppath"; return 1; }
    mkdir -p "$AY_DATA_DIR" 2>/dev/null && chmod 700 "$AY_DATA_DIR" 2>/dev/null
    cp -f "$CONFIG" "$AY_DATA_DIR/config.conf" 2>/dev/null || :
}
save_safety() {
    case "$1" in off|15|20|25|30) : ;; *) return 1 ;; esac
    case "$2" in off|40|42|45|48) : ;; *) return 1 ;; esac
    stmp="$MODDIR/.safety.tmp.$$"
    (umask 077; printf 'LOW_BATTERY=%s\nHIGH_TEMP=%s\n' "$1" "$2" > "$stmp") || return 1
    mv -f "$stmp" "$MODDIR/safety.conf" || return 1
    SAFE_BATTERY=$1; SAFE_TEMP=$2
    mkdir -p "$AY_DATA_DIR" 2>/dev/null && chmod 700 "$AY_DATA_DIR" 2>/dev/null
    cp -f "$MODDIR/safety.conf" "$AY_DATA_DIR/safety.conf" 2>/dev/null || :
}

clear_profile_choice() {
    rm -f "$AY_DATA_DIR/profile.id" 2>/dev/null || :
}
save_profile_choice() {
    case "$1" in extreme|normal|quiet|ultra|stability) : ;; *) return 1 ;; esac
    mkdir -p "$AY_DATA_DIR" || return 1
    chmod 700 "$AY_DATA_DIR" 2>/dev/null || :
    (umask 077; printf '%s\n' "$1" > "$AY_DATA_DIR/.profile.tmp.$$") || return 1
    mv -f "$AY_DATA_DIR/.profile.tmp.$$" "$AY_DATA_DIR/profile.id"
}
ui_read() {
    AY_LANG=ar; AY_THEME=dark
    if [ -r "$AY_DATA_DIR/ui.conf" ]; then
        l=$(sed -n 's/^LANG=//p' "$AY_DATA_DIR/ui.conf" | head -n1)
        t=$(sed -n 's/^THEME=//p' "$AY_DATA_DIR/ui.conf" | head -n1)
        case "$l" in ar|en) AY_LANG=$l ;; esac
        case "$t" in dark|light) AY_THEME=$t ;; esac
    fi
}
start_monitor() {
    [ -f "$MODDIR/disable" ] && { printf 'ERROR|Module disabled in KernelSU Next\n'; return 1; }
    [ -f "$MODDIR/remove" ] && { printf 'ERROR|Module pending removal\n'; return 1; }
    [ -r "$CONFIG" ] && grep -q '^MODE=off$' "$CONFIG" && return 0
    monitor_pid >/dev/null && return 0
    if [ -x /system/bin/sh ]; then
        /system/bin/sh "$MODDIR/service.sh"
    else
        sh "$MODDIR/service.sh"
    fi
}
stop_monitor() {
    if pid=$(monitor_pid); then
        kill "$pid" 2>/dev/null || :
        wait_n=0
        while monitor_pid >/dev/null && [ "$wait_n" -lt 10 ]; do
            sleep 1
            wait_n=$((wait_n + 1))
        done
    fi
}
screen_state() {
    POWER="$($DUMPSYS power 2>/dev/null)" || { printf UNKNOWN; return; }
    case "$POWER" in
        *'Display Power: state=OFF'*|*'Display Power: state=DOZE'*) printf OFF; return ;;
        *'Display Power: state=ON'*) printf ON; return ;;
    esac
    case "$POWER" in
        *'mWakefulness=Asleep'*|*'mWakefulness=Dozing'*) printf OFF; return ;;
        *'mWakefulness=Awake'*|*'mWakefulness=Dreaming'*) printf ON; return ;;
    esac
    printf UNKNOWN
}
restore_after_pause() {
    # Also works when monitoring service did not start, but direct WebUI apply did.
    pause_fail=0; pause_detail=
    for pol in "$POLICY_ROOT"/policy*; do
        [ -r "$pol/scaling_governor" ] || continue
        name=${pol##*/}
        original=$(gov_read "$MODDIR/original.$name" 2>/dev/null) || continue
        applied=$(gov_read "$MODDIR/applied.$name" 2>/dev/null) || continue
        current=$(gov_read "$pol/scaling_governor" 2>/dev/null) || continue
        [ "$current" = "$applied" ] || continue
        gov_supported "$pol" "$original" || continue
        if gov_write_verify "$pol" "$original"; then
            rm -f "$MODDIR/applied.$name"
        else
            pause_fail=$((pause_fail + 1))
            pause_detail="$pause_detail $name:$GOV_WRITE_ERROR"
        fi
    done
    if [ "$pause_fail" -gt 0 ]; then
        log_control "RESTORE_FAIL:$pause_detail"
        printf 'ERROR|Paused but could not restore governor:%s\n' "$pause_detail"
        return 1
    fi
    return 0
}
apply_now() {
    # This runs in the same root execution context as the WebUI action.
    # Captures originals before changing anything, even if monitor has not started.
    current_mode=$1
    current_screen=MANUAL
    [ "$current_mode" != off ] || { printf 'ERROR|Monitoring paused: choose a mode first\n'; return 1; }
    case "$current_mode" in
        auto)
            current_screen=$(screen_state)
            case "$current_screen" in
                ON) target=$ON_GOVERNOR ;;
                OFF) target=$OFF_GOVERNOR ;;
                *) printf 'OK|Automatic mode saved; screen state UNKNOWN, CPU unchanged\n'; return 0 ;;
            esac ;;
        *) target=$current_mode ;;
    esac
    if [ "$current_mode" = auto ]; then
        ay_guard "$target" "$current_screen"
    else
        ay_guard "$target" ON
    fi
    target=$AY_TARGET
    ds_live=$(ds_state)
    if [ "$current_screen" = OFF ]; then
        case "$ds_live" in armed|entering|active|restoring) target=powersave ;; esac
    fi
    check_governor "$target" || return 1
    if ! gov_capture_baseline; then
        printf 'ERROR|Cannot save original governor values for restoration\n'
        return 1
    fi
    changed=0; failed=0; checked=0; fail_detail=
    for pol in "$POLICY_ROOT"/policy*; do
        [ -r "$pol/scaling_governor" ] || continue
        name=${pol##*/}
        checked=$((checked + 1))
        current=$(gov_read "$pol/scaling_governor")
        if [ "$current" != "$target" ]; then
            if gov_write_verify "$pol" "$target"; then
                changed=$((changed + 1))
                printf '%s\n' "$target" > "$MODDIR/applied.$name"
            else
                failed=$((failed + 1))
                fail_detail="$fail_detail $name:$GOV_WRITE_ERROR"
            fi
        fi
    done
    if [ "$failed" -gt 0 ] || [ "$checked" -eq 0 ]; then
        log_control "DIRECT_FAIL wanted=$target changed=$changed failed=$failed:$fail_detail; uid=$(id -u 2>/dev/null); context=$(id -Z 2>/dev/null)"
        ay_update_description "${current_screen:-MANUAL}" "${AY_REASON:-normal}" "$target" || :
        printf 'ERROR|Direct apply failed for %s of %s policies:%s\n' "$failed" "$checked" "$fail_detail"
        return 1
    fi
    # CPU frequency limits are opt-in and active only when the display is ON.
    # Safety override or manual modes restore original min/max limits.
    freq_screen=$current_screen
    [ "$current_mode" = auto ] && [ "${AY_REASON:-normal}" = normal ] || freq_screen=OFF
    if ! freq_apply_screen "$freq_screen"; then
        log_control "FREQ_ERROR ${FREQ_ERROR:-unknown}"
        printf 'ERROR|Governor applied, but CPU frequency tuning failed: %s\n' "${FREQ_ERROR:-unknown}"
        return 1
    fi
    log_control "DIRECT_OK wanted=$target guard=${AY_REASON:-normal} policies=$checked changed=$changed"
    ay_update_description "${current_screen:-MANUAL}" "${AY_REASON:-normal}" "$target" || :
    printf 'OK|Governor %s confirmed on %s policies (safety=%s)\n' "$target" "$checked" "${AY_REASON:-normal}"
    return 0
}

case "${1:-}" in
    status)
        printf 'OK|status\n'
        printf 'MODE|%s\nON|%s\nOFF|%s\nPOLL|%s\n' "$MODE" "$ON_GOVERNOR" "$OFF_GOVERNOR" "$POLL_SECONDS"
        printf 'PROFILE|%s\n' "$(active_profile)"
        printf 'DEEP|%s\n' "$(ds_state)"
        ds_options || :
        printf 'DEEP_OPTIONS|%s|%s|%s|%s|%s\n' "$DS_AIR" "$DS_WIFI" "$DS_BT" "$DS_KILL" "$DS_TIMEOUT"
        ui_read
        printf 'UI|%s|%s\n' "$AY_LANG" "$AY_THEME"
        printf 'MODULE_DESCRIPTION|%s\n' "$(sed -n 's/^description=//p' "$MODDIR/module.prop" | head -n 1)"
        printf 'GUARD|%s|%s\n' "$SAFE_BATTERY" "$SAFE_TEMP"
        ay_bat_read
        printf 'BATTERY|%s|%s|%s\n' "$AY_BAT_PCT" "$AY_BAT_TEMP" "$AY_BAT_CHARGE"
        memtot=$(awk '/^MemTotal:/{print $2;exit}' /proc/meminfo 2>/dev/null)
        memfree=$(awk '/^MemAvailable:/{print $2;exit}' /proc/meminfo 2>/dev/null)
        printf 'RAM|%s|%s\n' "${memtot:-0}" "${memfree:-0}"
        printf 'LOAD|%s\n' "$(cut -d' ' -f1-3 /proc/loadavg 2>/dev/null)"
        if [ -r /sys/class/kgsl/kgsl-3d0/gpuclk ]; then
            gpuclk=$(gov_read /sys/class/kgsl/kgsl-3d0/gpuclk)
            printf 'GPU|%s\n' "$gpuclk"
        else
            printf 'GPU|unknown\n'
        fi
        if [ -r /sys/block/zram0/disksize ]; then
            printf 'ZRAM|%s\n' "$(gov_read /sys/block/zram0/disksize)"
        else
            printf 'ZRAM|unknown\n'
        fi
        # Storage schedulers are informational only; never write them.
        io_count=0
        for disk in /sys/block/sd* /sys/block/mmcblk* /sys/block/dm-*; do
            [ -r "$disk/queue/scheduler" ] || continue
            scheduler=$(cat "$disk/queue/scheduler" 2>/dev/null | sed -n 's/.*\[\([^]]*\)\].*/\1/p')
            [ -n "$scheduler" ] || scheduler=unknown
            printf 'IO|%s|%s\n' "${disk##*/}" "$scheduler"
            io_count=$((io_count + 1))
            [ "$io_count" -ge 4 ] && break
        done
        model=$(getprop ro.product.model 2>/dev/null | tr '|\n' '  ')
        android=$(getprop ro.build.version.release 2>/dev/null | tr '|\n' '  ')
        printf 'DEVICE|%s|%s|%s\n' "${model:-unknown}" "${android:-unknown}" "$(uname -r)"
        for other in "$AY_MODULES_DIR"/*; do
            [ -d "$other" ] || continue
            [ "${other##*/}" = 'eng_ahmed_yasir_screen_gov' ] && continue
            [ -f "$other/disable" ] && continue
            [ -f "$other/remove" ] && continue
            case "${other##*/}" in
                *[Dd]eep[Dd]oze*|*[Tt]hermal*|*[Kk]ernel*|*[Pp]erf*|*[Cc]pu*|*[Gg]overnor*|*[Tt]un[ei]*|*screen_gov*)
                    printf 'CONFLICT|%s\n' "${other##*/}" ;;
            esac
        done
        if [ -f "$MODDIR/disable" ]; then
            printf 'SERVICE|disabled\n'
        elif [ "$MODE" = off ]; then
            printf 'SERVICE|paused\n'
        elif monitor_pid >/dev/null; then
            printf 'SERVICE|running\n'
        else
            printf 'SERVICE|stopped\n'
        fi
        reading_screen=$(screen_state)
        printf 'SCREEN|%s\n' "$reading_screen"
        target=unknown
        reason=normal
        if [ "$MODE" = auto ]; then
            case "$reading_screen" in ON) target=$ON_GOVERNOR ;; OFF) target=$OFF_GOVERNOR ;; esac
            if [ "$target" != unknown ]; then
                ay_guard "$target" "$reading_screen"
                target=$AY_TARGET
                reason=$AY_REASON
            fi
        elif [ "$MODE" != off ]; then
            ay_guard "$MODE" ON
            target=$AY_TARGET
            reason=$AY_REASON
        fi
        printf 'EFFECTIVE|%s|%s\n' "$target" "$reason"
        supported_list=
        for g in performance powersave schedutil ondemand conservative; do
            if check_governor "$g" >/dev/null 2>&1; then
                supported_list="${supported_list}${supported_list:+,}$g"
            fi
        done
        printf 'AVAILABLE|%s\n' "$supported_list"
        found=0
        for pol in "$POLICY_ROOT"/policy*; do
            [ -r "$pol/scaling_governor" ] || continue
            found=$((found+1))
            polname=${pol##*/}
            original=$(gov_read "$MODDIR/original.$polname" 2>/dev/null) || original=unknown
            printf 'POLICY|%s|%s|%s|%s|%s|%s\n' "$polname" "$(gov_read "$pol/scaling_governor")" "$(gov_read "$pol/scaling_cur_freq")" "$(gov_read "$pol/cpuinfo_min_freq")" "$(gov_read "$pol/cpuinfo_max_freq")" "$original"
        done
        [ "$found" -gt 0 ] || printf 'WARNING|No CPU policy available\n'
        freq_status
        backup_list
        ;;
    logs)
        if [ -r "$MODDIR/status.log" ]; then
            tail -n 22 "$MODDIR/status.log"
        else
            printf '%s\n' 'No log yet. Reboot or press Start.'
        fi
        ;;
    set-profile)
        NEWPROFILE=${2:-}
        NEWON=$(profile_governor "$NEWPROFILE") || { printf 'ERROR|Unknown profile ID\n'; exit 2; }
        check_governor "$NEWON" || exit 3
        check_governor powersave || exit 3
        # Preserve previous state so unsupported tuning or failed writes can be rolled back.
        PREV_CONF=$(cat "$MODDIR/config.conf" 2>/dev/null)
        PREV_SAFE=$(cat "$MODDIR/safety.conf" 2>/dev/null)
        PREV_PROF=$(gov_read "$AY_DATA_DIR/profile.id" 2>/dev/null)
        save_config auto "$NEWON" powersave "$POLL_SECONDS" || { printf 'ERROR|Cannot save preset\n'; exit 4; }
        case "$NEWPROFILE" in
            stability) save_safety 25 40 || exit 4 ;;
            *) save_safety off off || exit 4 ;;
        esac
        MODE=auto; ON_GOVERNOR=$NEWON; OFF_GOVERNOR=powersave
        save_profile_choice "$NEWPROFILE" || { printf 'ERROR|Cannot save selected profile\n'; exit 4; }
        log_control "PROFILE $NEWPROFILE on=$NEWON off=powersave"
        if ! apply_now auto; then
            printf '%s\n' "$PREV_CONF" > "$MODDIR/config.conf"
            printf '%s\n' "$PREV_SAFE" > "$MODDIR/safety.conf"
            cp -f "$MODDIR/config.conf" "$AY_DATA_DIR/config.conf" 2>/dev/null || :
            cp -f "$MODDIR/safety.conf" "$AY_DATA_DIR/safety.conf" 2>/dev/null || :
            if [ -n "$PREV_PROF" ]; then printf '%s\n' "$PREV_PROF" > "$AY_DATA_DIR/profile.id"; else clear_profile_choice; fi
            printf 'ERROR|Applying profile failed; previous settings restored\n'
            exit 6
        fi
        start_monitor || exit 5
        ay_update_description "$(screen_state)" normal "$NEWON" || :
        ;;
    set-mode)
        NEWMODE=${2:-}
        allowed_mode "$NEWMODE" || { printf 'ERROR|Invalid mode\n'; exit 2; }
        if [ "$NEWMODE" != auto ] && [ "$NEWMODE" != off ]; then
            check_governor "$NEWMODE" || exit 3
        fi
        save_config "$NEWMODE" "$ON_GOVERNOR" "$OFF_GOVERNOR" "$POLL_SECONDS" || { printf 'ERROR|Cannot save config\n'; exit 4; }
        MODE=$NEWMODE
        clear_profile_choice
        if [ "$NEWMODE" = off ]; then
            stop_monitor
            ds_cancel || { printf 'ERROR|Failed to restore radios: %s\n' "$DS_ERROR"; exit 6; }
            freq_restore_all || { printf 'ERROR|Could not restore CPU frequency limits: %s\n' "${FREQ_ERROR:-unknown}"; exit 6; }
            restore_after_pause || { ay_update_description MANUAL normal unknown || :; exit 6; }
            ay_update_description MANUAL normal unknown || :
            log_control 'Monitoring paused; originals restored if still controlled by AY.'
            printf 'OK|Monitoring paused, originals restored when applicable\n'
        else
            # WebUI root applies immediately, and monitor maintains it afterwards.
            apply_now "$NEWMODE" || exit 6
            start_monitor || exit 5
        fi
        ;;
    set-auto)
        NEWON=${2:-}; NEWOFF=${3:-}; NEWPOLL=${4:-}
        allowed_gov "$NEWON" && allowed_gov "$NEWOFF" && valid_interval "$NEWPOLL" || { printf 'ERROR|Invalid automatic settings\n'; exit 2; }
        check_governor "$NEWON" || exit 3
        check_governor "$NEWOFF" || exit 3
        save_config auto "$NEWON" "$NEWOFF" "$NEWPOLL" || { printf 'ERROR|Cannot save config\n'; exit 4; }
        MODE=auto; ON_GOVERNOR=$NEWON; OFF_GOVERNOR=$NEWOFF; POLL_SECONDS=$NEWPOLL
        clear_profile_choice
        apply_now auto || exit 6
        start_monitor || exit 5
        ;;
    set-guard)
        save_safety "${2:-}" "${3:-}" || { printf 'ERROR|Invalid safeguard thresholds\n'; exit 2; }
        clear_profile_choice
        log_control "SAFETY battery=$SAFE_BATTERY temp=$SAFE_TEMP"
        [ "$MODE" = off ] && { ay_update_description MANUAL normal unknown || :; printf 'OK|Safeguards saved while paused\n'; exit 0; }
        apply_now "$MODE" || exit 6
        ;;
    set-ui)
        NEWLANG=${2:-}; NEWTHEME=${3:-}
        case "$NEWLANG" in ar|en) : ;; *) printf 'ERROR|Invalid language\n'; exit 2 ;; esac
        case "$NEWTHEME" in dark|light) : ;; *) printf 'ERROR|Invalid appearance\n'; exit 2 ;; esac
        mkdir -p "$AY_DATA_DIR" || exit 4
        chmod 700 "$AY_DATA_DIR" 2>/dev/null || :
        (umask 077; printf 'LANG=%s\nTHEME=%s\n' "$NEWLANG" "$NEWTHEME" > "$AY_DATA_DIR/.ui.tmp.$$") || exit 4
        mv -f "$AY_DATA_DIR/.ui.tmp.$$" "$AY_DATA_DIR/ui.conf" || exit 4
        printf 'OK|Appearance and language saved\n'
        ;;
    set-freq)
        PNAME=${2:-}; PMIN=${3:-}; PMAX=${4:-}
        # Validate the target before creating or changing a config file.
        freq_boot_prepare || { printf 'ERROR|Cannot snapshot CPU frequency baseline\n'; exit 3; }
        freq_validate_pair "$PNAME" "$PMIN" "$PMAX" || { printf 'ERROR|Invalid CPU limits: %s\n' "$FREQ_ERROR"; exit 3; }
        PREV="$AY_DATA_DIR/freq.$PNAME"
        if [ -s "$PREV" ]; then
            cp -f "$PREV" "$AY_DATA_DIR/.freq.previous.$$" || exit 4
            WAS=1
        else
            WAS=0
        fi
        freq_set "$PNAME" "$PMIN" "$PMAX" || { printf 'ERROR|Cannot save CPU frequency limits: %s\n' "$FREQ_ERROR"; exit 4; }
        if [ "$MODE" != off ]; then
            if ! apply_now "$MODE"; then
                [ "$WAS" = 1 ] && mv -f "$AY_DATA_DIR/.freq.previous.$$" "$PREV" || rm -f "$PREV"
                apply_now "$MODE" >/dev/null 2>&1 || :
                printf 'ERROR|CPU frequency tuning rejected; previous settings restored\n'
                exit 6
            fi
        fi
        rm -f "$AY_DATA_DIR/.freq.previous.$$"
        printf 'OK|CPU frequency limits saved for %s; applies only while screen ON\n' "$PNAME"
        ;;
    reset-freq)
        PNAME=${2:-}
        case "$PNAME" in
            all) rm -f "$AY_DATA_DIR"/freq.policy* ;;
            *) freq_valid_policy "$PNAME" || { printf 'ERROR|Invalid policy\n'; exit 2; }
               rm -f "$AY_DATA_DIR/freq.$PNAME" ;;
        esac
        freq_restore_all || { printf 'ERROR|CPU frequency restore failed: %s\n' "${FREQ_ERROR:-unknown}"; exit 6; }
        printf 'OK|CPU frequency limits reset to original\n'
        ;;
    backup-save)
        SLOT=${2:-}
        backup_save "$SLOT" || { printf 'ERROR|Could not save backup\n'; exit 3; }
        printf 'OK|Backup saved to slot %s\n' "$SLOT"
        ;;
    backup-delete)
        SLOT=${2:-}
        backup_slot_valid "$SLOT" || { printf 'ERROR|Invalid backup slot\n'; exit 2; }
        rm -rf "$(backup_root)/slot$SLOT"
        printf 'OK|Backup slot %s cleared\n' "$SLOT"
        ;;
    backup-restore)
        SLOT=${2:-}
        freq_boot_prepare || { printf 'ERROR|Cannot inspect kernel clock limits\n'; exit 3; }
        backup_validate "$SLOT" || { printf 'ERROR|Backup incompatible: %s\n' "$BACKUP_ERROR"; exit 3; }
        ROLLBACK="$AY_DATA_DIR/.rollback.$$"
        mkdir -m 700 "$ROLLBACK" || exit 4
        cp -f "$MODDIR/config.conf" "$ROLLBACK/config.conf" || exit 4
        cp -f "$MODDIR/safety.conf" "$ROLLBACK/safety.conf" || exit 4
        [ ! -s "$AY_DATA_DIR/profile.id" ] || cp -f "$AY_DATA_DIR/profile.id" "$ROLLBACK/profile.id"
        for OLD_F in "$AY_DATA_DIR"/freq.policy*; do
            [ -s "$OLD_F" ] && cp -f "$OLD_F" "$ROLLBACK/" || :
        done
        stop_monitor
        if backup_import "$SLOT"; then
            MODE=off; . "$MODDIR/config.conf"
            LOW_BATTERY=off; HIGH_TEMP=off; . "$MODDIR/safety.conf"
            SAFE_BATTERY=$LOW_BATTERY; SAFE_TEMP=$HIGH_TEMP
            if [ "$MODE" = off ]; then
                freq_restore_all && restore_after_pause
                result=$?
            else
                apply_now "$MODE"
                result=$?
                [ "$result" -ne 0 ] || start_monitor
            fi
        else
            result=1
        fi
        if [ "$result" -ne 0 ]; then
            cp -f "$ROLLBACK/config.conf" "$MODDIR/config.conf"
            cp -f "$ROLLBACK/safety.conf" "$MODDIR/safety.conf"
            cp -f "$ROLLBACK/config.conf" "$AY_DATA_DIR/config.conf"
            cp -f "$ROLLBACK/safety.conf" "$AY_DATA_DIR/safety.conf"
            rm -f "$AY_DATA_DIR"/freq.policy* "$AY_DATA_DIR/profile.id"
            for OLD_F in "$ROLLBACK"/freq.policy* "$ROLLBACK"/profile.id; do
                [ -s "$OLD_F" ] && cp -f "$OLD_F" "$AY_DATA_DIR/" || :
            done
            . "$MODDIR/config.conf"
            apply_now "$MODE" >/dev/null 2>&1 || :
            start_monitor >/dev/null 2>&1 || :
            rm -rf "$ROLLBACK"
            printf 'ERROR|Backup could not be applied; previous configuration restored\n'
            exit 6
        fi
        rm -rf "$ROLLBACK"
        log_control "BACKUP_RESTORE slot=$SLOT"
        printf 'OK|Backup slot %s restored\n' "$SLOT"
        ;;
    deep-options)
        ds_current=$(ds_state)
        [ "$ds_current" = off ] || { printf 'ERROR|Cancel deep sleep before changing options\n'; exit 2; }
        ds_save_options "${2:-}" "${3:-}" "${4:-}" "${5:-}" "${6:-}" || { printf 'ERROR|Deep sleep options: %s\n' "$DS_ERROR"; exit 2; }
        printf 'OK|Deep sleep preferences saved\n'
        ;;
    deep-arm)
        [ "$MODE" != off ] || { printf 'ERROR|Select an active CPU mode first\n'; exit 2; }
        start_monitor || exit 5
        ds_wait=0
        until monitor_pid >/dev/null; do
            [ "$ds_wait" -lt 4 ] || { printf 'ERROR|Screen-monitor service did not start; sleep was not armed\n'; exit 5; }
            sleep 1
            ds_wait=$((ds_wait + 1))
        done
        ds_arm || { printf 'ERROR|Cannot arm deep sleep: %s\n' "$DS_ERROR"; exit 6; }
        log_control 'DEEP armed: radios will disconnect after screen OFF'
        printf 'OK|Deep sleep armed; lock the display to disconnect radios\n'
        ;;
    deep-cancel)
        ds_cancel || { printf 'ERROR|Could not restore connectivity: %s\n' "$DS_ERROR"; exit 6; }
        log_control 'DEEP cancelled or radios restored'
        printf 'OK|Deep sleep cancelled; previous radio settings restored\n'
        ;;
    apply-now)
        apply_now "$MODE" || exit 6
        ;;
    start)
        [ "$MODE" != off ] || { printf 'ERROR|Set a running mode first\n'; exit 2; }
        apply_now "$MODE" || exit 6
        start_monitor || exit 5
        ;;
    *)
        printf 'ERROR|Unknown command; whitelist: status/logs/set-profile/set-mode/set-auto/set-guard/set-ui/set-freq/reset-freq/backup-*/apply-now/start/deep-options/deep-arm/deep-cancel\n'
        exit 2
        ;;
esac
