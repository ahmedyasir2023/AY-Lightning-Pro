#!/system/bin/sh
# AY Lightning Pro - optional battery safeguards; read-only telemetry.
# Caller provides SAFE_BATTERY, SAFE_TEMP and MODDIR. Does not touch thermals.
AY_BATTERY_DIR=${AY_BATTERY_DIR:-/sys/class/power_supply/battery}
ay_bat_read() {
    AY_BAT_PCT=unknown
    AY_BAT_TEMP=unknown
    AY_BAT_CHARGE=unknown
    if [ -r "$AY_BATTERY_DIR/capacity" ]; then
        v=$(cat "$AY_BATTERY_DIR/capacity" 2>/dev/null)
        case "$v" in ''|*[!0-9]*) : ;; *) [ "$v" -le 100 ] && AY_BAT_PCT=$v ;; esac
    fi
    if [ -r "$AY_BATTERY_DIR/temp" ]; then
        v=$(cat "$AY_BATTERY_DIR/temp" 2>/dev/null)
        case "$v" in
            ''|*[!0-9]*) : ;;
            *)
                # Battery temperatures usually use deci-Celsius; also accept full C.
                if [ "$v" -le 90 ]; then v=$((v * 10)); fi
                [ "$v" -ge 0 ] && [ "$v" -le 900 ] && AY_BAT_TEMP=$v
                ;;
        esac
    fi
    if [ -r "$AY_BATTERY_DIR/status" ]; then
        v=$(cat "$AY_BATTERY_DIR/status" 2>/dev/null)
        case "$v" in Charging|Full|Discharging|'Not charging') AY_BAT_CHARGE=$v ;; esac
    fi
}
ay_guard() {
    # usage: ay_guard governor SCREEN ; outputs AY_TARGET, AY_REASON
    AY_TARGET=$1
    AY_REASON=normal
    [ "$2" = ON ] || return 0
    [ "${SAFE_BATTERY:-off}" != off ] || [ "${SAFE_TEMP:-off}" != off ] || return 0
    ay_bat_read
    if [ "${SAFE_BATTERY:-off}" != off ] && [ "$AY_BAT_PCT" != unknown ]; then
        case "$SAFE_BATTERY" in 15|20|25|30)
            if [ "$AY_BAT_PCT" -le "$SAFE_BATTERY" ] && [ "$AY_BAT_CHARGE" != Charging ] && [ "$AY_BAT_CHARGE" != Full ]; then
                AY_TARGET=powersave; AY_REASON=low_battery
                return 0
            fi
        ;; esac
    fi
    if [ "${SAFE_TEMP:-off}" != off ] && [ "$AY_BAT_TEMP" != unknown ]; then
        case "$SAFE_TEMP" in 40|42|45|48)
            if [ "$AY_BAT_TEMP" -ge $((SAFE_TEMP * 10)) ]; then
                AY_TARGET=schedutil; AY_REASON=high_battery_temp
            fi
        ;; esac
    fi
}
