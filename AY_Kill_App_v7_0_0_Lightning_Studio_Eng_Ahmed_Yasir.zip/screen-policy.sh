#!/system/bin/sh
# AY v7 | Independent ordinary standby CPU delay (not radio Deep Sleep).
# Monotonic uptime eliminates clock-change errors. Reboot ID invalidates old timers.
AY_SCREEN_DIR=${AY_DATA_DIR:-/data/adb/ay_lightning}/screen
AY_SCREEN_UPTIME=${YASIR_UPTIME:-/proc/uptime}
AY_SCREEN_BOOT=${YASIR_BOOT_ID:-/proc/sys/kernel/random/boot_id}
ay_screen_delay() {
    AY_SAVE_DELAY=60
    [ -r "$AY_SCREEN_DIR/delay" ] && AY_SAVE_DELAY=$(cat "$AY_SCREEN_DIR/delay" 2>/dev/null)
    case "$AY_SAVE_DELAY" in off|0|15|30|60|120|180|300|600|900|1800) : ;; *) AY_SAVE_DELAY=60 ;; esac
}
ay_screen_set_delay() {
    case "$1" in off|0|15|30|60|120|180|300|600|900|1800) : ;; *) return 1 ;; esac
    mkdir -p "$AY_SCREEN_DIR" || return 1
    chmod 700 "$AY_SCREEN_DIR" 2>/dev/null || :
    printf '%s\n' "$1" > "$AY_SCREEN_DIR/.delay.$$" || return 1
    mv -f "$AY_SCREEN_DIR/.delay.$$" "$AY_SCREEN_DIR/delay"
}
ay_screen_uptime() {
    [ -r "$AY_SCREEN_UPTIME" ] || return 1
    read -r _sec _other < "$AY_SCREEN_UPTIME" || return 1
    _sec=${_sec%%.*}
    case "$_sec" in ''|*[!0-9]*) return 1 ;; esac
    printf '%s' "$_sec"
}
ay_screen_tick() {
    AY_STANDBY=0; AY_SCREEN_ELAPSED=0
    ay_screen_delay
    case "$1" in
        ON)
            rm -f "$AY_SCREEN_DIR/off_since" "$AY_SCREEN_DIR/off_boot"
            return 0 ;;
        OFF)
            [ "$AY_SAVE_DELAY" != off ] || return 0
            _now=$(ay_screen_uptime) || return 1
            _boot=$(cat "$AY_SCREEN_BOOT" 2>/dev/null)
            _previous=$(cat "$AY_SCREEN_DIR/off_since" 2>/dev/null)
            _prevboot=$(cat "$AY_SCREEN_DIR/off_boot" 2>/dev/null)
            case "$_previous" in ''|*[!0-9]*) _previous=invalid ;; esac
            if [ "$_previous" = invalid ] || [ "$_prevboot" != "$_boot" ] || [ "$_previous" -gt "$_now" ]; then
                mkdir -p "$AY_SCREEN_DIR" || return 1
                printf '%s\n' "$_now" > "$AY_SCREEN_DIR/off_since" || return 1
                printf '%s\n' "$_boot" > "$AY_SCREEN_DIR/off_boot" || return 1
                _previous=$_now
            fi
            AY_SCREEN_ELAPSED=$((_now - _previous))
            [ "$AY_SCREEN_ELAPSED" -ge "$AY_SAVE_DELAY" ] && AY_STANDBY=1
            return 0 ;;
        *) return 0 ;;
    esac
}
