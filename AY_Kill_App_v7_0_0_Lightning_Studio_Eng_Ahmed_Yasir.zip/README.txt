AY KILL APP v7.0.0 - Eng. Ahmed Yasir - Installation / Safety

INSTALL
Install the ZIP in KernelSU / KernelSU Next (or supported Magisk manager), reboot.
The module ID eng_ahmed_yasir_screen_gov remains the same to support upgrades; the root module name is AY KILL APP | Lightning Pro.
The official banner is the uploaded AY7.0.0 JPG; the icon is retained from v6.

NORMAL USE
Choose one of the 5 performance profiles from WebUI. When you lock the screen,
the existing performance governor is retained for the standby delay (default: 60s),
then the CPU governor switches to power saver on supported kernel policies.
Unlock returns to the selected performance governor on the next screen check
(OFF polling ~1s, subject to Android service response). Change delay in
WebUI > Screen-off Intelligence. 'Off' disables this ordinary CPU saving timer.

DEEP SLEEP ULTRA
WebUI uses a queued deep request for reliable UI feedback. Action is an immediate
toggle. During Deep Sleep, the module attempts airplane, Wi-Fi, Bluetooth, NFC
(where available), SoftAP shutdown, and optional force-stop of USER applications;
Android system services, root managers, launcher, IME, dialer and foreground
controller are excluded. It attempts to drop CPU to powersave immediately.
After a genuine OFF->ON transition, the selected CPU profile returns but radios
STAY DISCONNECTED. To restore connections, press CANCEL inside WebUI or Action.
WARNING: calls/SMS/data can be unavailable during this time. On reboot a safety
recovery attempts to restore the previous network state; manual restore may be
required on unsupported ROMs. AUTO Deep Sleep still activates after 60 uninterrupted
minutes of OFF time (independent of the ordinary CPU power saver).

KERNEL STUDIO
GPU, VM, I/O, selected scheduler, touch and Android settings are exposed only
when writable/readable capabilities exist. Every Studio write is checked by
readback, and original boot values are stored in /data/adb/ay_lightning/studio.
Original values can be restored with the specific RESET button or RESET ALL.
Kernel settings reapply after reboot if desired, validated against that boot.
ZRAM algorithm and MGLRU are informational; reconfiguring active zram risks
crashing the device. Unsafe HyperPerf overrides are intentionally excluded.
The 'Supported' badge denotes node availability only, NOT guaranteed performance
or battery improvement.

IMPORTANT
Different Android 11-16 variants and OEM kernels expose incompatible nodes.
Do not run two CPU/GPU/kernel tuning modules simultaneously.
Do not treat browser preview as real root execution. If WebUI shows PREVIEW,
open the module UI inside a compatible root manager.
Check WebUI > Diagnostics > Logs for failures/partial disconnections.
No thermal, SELinux, kernel watchdog or charging voltage/current bypass.


COMMANDS (Termux after su)
  sh /data/adb/modules/eng_ahmed_yasir_screen_gov/control.sh status
  sh /data/adb/modules/eng_ahmed_yasir_screen_gov/control.sh deep-request
  sh /data/adb/modules/eng_ahmed_yasir_screen_gov/control.sh deep-now
  sh /data/adb/modules/eng_ahmed_yasir_screen_gov/control.sh deep-cancel
  sh /data/adb/modules/eng_ahmed_yasir_screen_gov/control.sh screen-delay 120
  sh /data/adb/modules/eng_ahmed_yasir_screen_gov/control.sh studio list
  sh /data/adb/modules/eng_ahmed_yasir_screen_gov/control.sh studio reset-all
  sh /data/adb/modules/eng_ahmed_yasir_screen_gov/control.sh logs

WEBUI CONTROLS
  5 CPU profiles, direct Action Deep Sleep, queued WebUI Deep Sleep,
  after-60-minute deep auto (separate timer), adjustable ordinary standby,
  GPU Studio, RAM Lab, I/O Studio, Kernel Studio, per-app standby buckets,
  Android animation settings, BLE background scanning preferences,
  games list, Auto Gaming, ANGLE renderer preferences, DNS-over-TLS,
  battery/charging limits where OEM allows reduction, conservative underclock,
  optional CPU core parking, TCP controls, resolution options, FSTRIM,
  cache cleanup, module conflict detection, thermal readouts and diagnostics.

RECOVERY
  Screen ON restores CPU governor, NOT the previously disconnected radios.
  Open WebUI and press RESTORE CONNECTIONS, or use the module Action again.
  If the root bridge fails, use a root shell and execute deep-cancel.
  A prior-boot snapshot may be restored for safety at boot time.
  The user-provided banner.jpg is byte-identical; banner.png is a lossless
  pixel-identical conversion to support managers that require PNG artwork.

LIMITATIONS & TESTS
  Force-stopping apps can discard unsaved work. Root managers, Android
  system services, launcher, active input method, phone and current foreground
  UI are exempt so recovery remains possible. Some apps restart automatically.
  Kernel and Android versions determine which Studio controls exist.
  Do not use this module alongside another CPU/GPU governor service.
  Many HyperPerf controls are hardware-specific; unsafe overrides intentionally
  excluded. This version has passed shell mocks and browser bridge integration,
  not real-device, battery-drain or thermal endurance testing. No promise that
  all settings work on all Xiaomi/MIUI, HyperOS or AOSP ROMs.
