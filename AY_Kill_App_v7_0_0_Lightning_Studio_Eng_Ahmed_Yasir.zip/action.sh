#!/system/bin/sh
# Magisk / KernelSU manager action: explicit offline toggle without WebUI.
MODDIR=${YASIR_MODDIR:-${0%/*}}
if [ "$(id -u 2>/dev/null)" != 0 ]; then
    echo 'AY v7: action requires root access.'
    exit 1
fi
. "$MODDIR/deep-lib.sh" || exit 1
case "$(ds_state)" in
    active|partial|entering|restoring)
        echo 'AY v7: manually restoring radios to their pre-sleep states...'
        "${YASIR_SHELL:-/system/bin/sh}" "$MODDIR/control.sh" deep-cancel
        ;;
    *)
        echo 'AY v7: cutting radios now. Incoming calls and SMS will be unavailable.'
        echo 'Screen wake restores selected CPU profile ONLY, not radios. Press Action again to cancel.'
        "${YASIR_SHELL:-/system/bin/sh}" "$MODDIR/control.sh" deep-now
        ;;
esac
