#!/system/bin/sh
# KernelSU late-start service. AY v7 auto Deep Sleep also works with CPU mode paused.
MODDIR=${YASIR_MODDIR:-${0%/*}}
AY_DATA_DIR=${AY_DATA_DIR:-/data/adb/ay_lightning}
[ -f "$MODDIR/disable" ] && exit 0
[ -f "$MODDIR/remove" ] && exit 0
if [ -r "$MODDIR/monitor.pid" ]; then
    OLD_PID=$(cat "$MODDIR/monitor.pid" 2>/dev/null)
    case "$OLD_PID" in
        ''|*[!0-9]*) : ;;
        *) if kill -0 "$OLD_PID" 2>/dev/null && [ -r "/proc/$OLD_PID/cmdline" ]; then
            CMD=$(tr '\000' ' ' < "/proc/$OLD_PID/cmdline" 2>/dev/null)
            case "$CMD" in *"$MODDIR/monitor.sh"*) exit 0 ;; esac
        fi ;;
    esac
fi
# The lightweight monitor decides if it can stop (auto OFF, CPU mode OFF,
# and no current Deep Sleep). Default auto=ON after a fresh v6 install.
${YASIR_SHELL:-/system/bin/sh} "$MODDIR/monitor.sh" >/dev/null 2>&1 &
exit 0
