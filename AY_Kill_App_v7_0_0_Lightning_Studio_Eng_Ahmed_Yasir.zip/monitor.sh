#!/system/bin/sh
# AY KILL APP v7 - one process for offline sleep and optional CPU profiles.
# Wake restores responsiveness, but NEVER restores airplane/Wi-Fi/Bluetooth.
MODDIR=${YASIR_MODDIR:-${0%/*}}
AY_DATA_DIR=${AY_DATA_DIR:-/data/adb/ay_lightning}
POLICY_ROOT=${YASIR_POLICY_ROOT:-/sys/devices/system/cpu/cpufreq}
DUMPSYS=${YASIR_DUMPSYS:-/system/bin/dumpsys}
GETPROP=${YASIR_GETPROP:-/system/bin/getprop}
. "$MODDIR/governor-lib.sh" || exit 1
. "$MODDIR/safety-lib.sh" || exit 1
. "$MODDIR/status-lib.sh" || exit 1
. "$MODDIR/freq-lib.sh" || exit 1
. "$MODDIR/deep-lib.sh" || exit 1
. "$MODDIR/screen-policy.sh" || exit 1
LOGFILE="$MODDIR/status.log"
PIDFILE="$MODDIR/monitor.pid"

MODE=off; ON_GOVERNOR=schedutil; OFF_GOVERNOR=powersave; POLL_SECONDS=3
load_settings() {
    MODE=off; ON_GOVERNOR=schedutil; OFF_GOVERNOR=powersave; POLL_SECONDS=3
    [ -r "$MODDIR/config.conf" ] && . "$MODDIR/config.conf"
    case "$MODE" in auto|performance|powersave|schedutil|off) : ;; *) MODE=off ;; esac
    case "$ON_GOVERNOR" in performance|powersave|schedutil|ondemand|conservative) : ;; *) ON_GOVERNOR=schedutil ;; esac
    case "$OFF_GOVERNOR" in performance|powersave|schedutil|ondemand|conservative) : ;; *) OFF_GOVERNOR=powersave ;; esac
    case "$POLL_SECONDS" in 2|3|5|10) : ;; *) POLL_SECONDS=3 ;; esac
    LOW_BATTERY=off; HIGH_TEMP=off
    [ -r "$MODDIR/safety.conf" ] && . "$MODDIR/safety.conf"
    SAFE_BATTERY=$LOW_BATTERY; SAFE_TEMP=$HIGH_TEMP
    case "$SAFE_BATTERY" in off|15|20|25|30) : ;; *) SAFE_BATTERY=off ;; esac
    case "$SAFE_TEMP" in off|40|42|45|48) : ;; *) SAFE_TEMP=off ;; esac
}
log_line() {
    if [ -f "$LOGFILE" ] && [ "$(wc -c < "$LOGFILE" 2>/dev/null)" -gt 60000 ]; then
        tail -n 90 "$LOGFILE" > "$LOGFILE.tmp" 2>/dev/null && mv -f "$LOGFILE.tmp" "$LOGFILE"
    fi
    printf '%s | %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOGFILE"
}
screen_state() {
    ds_screen_state
}
restore_governors() {
    for pol in "$POLICY_ROOT"/policy*; do
        [ -r "$pol/scaling_governor" ] || continue
        name=${pol##*/}
        original=$(gov_read "$MODDIR/original.$name" 2>/dev/null) || continue
        applied=$(gov_read "$MODDIR/applied.$name" 2>/dev/null) || continue
        current=$(gov_read "$pol/scaling_governor" 2>/dev/null) || continue
        [ "$current" = "$applied" ] || continue
        gov_supported "$pol" "$original" || continue
        if gov_write_verify "$pol" "$original"; then
            rm -f "$MODDIR/applied.$name"
        else
            log_line "RESTORE_FAIL $name reason=$GOV_WRITE_ERROR"
        fi
    done
}
on_exit() {
    # Restore ONLY CPU knobs. Radio disconnection survives screen wake, mode
    # pause, monitor restart and ordinary service termination.
    if [ "${CAPTURED:-0}" = 1 ]; then
        freq_restore_all || :
        restore_governors
    fi
    if [ -r "$PIDFILE" ] && [ "$(gov_read "$PIDFILE")" = "$$" ]; then rm -f "$PIDFILE"; fi
}
if [ -r "$PIDFILE" ]; then
    oldpid=$(gov_read "$PIDFILE")
    case "$oldpid" in
        ''|*[!0-9]*) : ;;
        *) if [ "$oldpid" != "$$" ] && kill -0 "$oldpid" 2>/dev/null && [ -r "/proc/$oldpid/cmdline" ]; then
            oldcmd=$(tr '\000' ' ' < "/proc/$oldpid/cmdline" 2>/dev/null)
            case "$oldcmd" in *"$MODDIR/monitor.sh"*) exit 0 ;; esac
        fi ;;
    esac
fi
printf '%s\n' "$$" > "$PIDFILE" || exit 1
CAPTURED=0
trap 'exit 0' HUP INT TERM
trap 'on_exit' 0

count=0
while [ "$($GETPROP sys.boot_completed 2>/dev/null)" != 1 ]; do
    [ -f "$MODDIR/disable" ] && exit 0
    [ -f "$MODDIR/remove" ] && exit 0
    count=$((count+1))
    [ "$count" -lt 90 ] || { log_line 'BOOT_TIMEOUT'; exit 1; }
    sleep 2
done
sleep 1
# Recover only interrupted transactions or a snapshot from a PRIOR reboot.
# Restarting the monitor during active Deep Sleep never restores the radios.
ds_recover_previous_boot || log_line "BOOT_DEEP_RECOVERY_ERROR:$DS_ERROR"
load_settings
# Reapply only user-opted-in reversible network/charging caps once after boot.
"${YASIR_SHELL:-/system/bin/sh}" "$MODDIR/fusion.sh" onboot >/dev/null 2>&1 || :
"${YASIR_SHELL:-/system/bin/sh}" "$MODDIR/studio.sh" boot >/dev/null 2>&1 || :
if gov_capture_baseline; then
    CAPTURED=1
    freq_boot_prepare || log_line "FREQ_BASELINE_ERROR:${FREQ_ERROR:-unknown}"
else
    log_line 'CPU_POLICY_WARNING: sleep monitoring still available.'
fi
log_line "Service v7.0.0 started; mode=$MODE; cpu_policies=${captured:-0}; uid=$(id -u 2>/dev/null)"

count_game_scan=0; game_active=; last_mode=NONE; last_screen=UNKNOWN; last_wanted=NONE; last_reason=NONE
last_failure_details=; last_freq_error=; last_deep_state=off; last_deep_error=; unknown_reported=0
last_standby=0
while :; do
    [ -f "$MODDIR/disable" ] && exit 0
    [ -f "$MODDIR/remove" ] && exit 0
    [ -r "$MODDIR/module.prop" ] || exit 0
    load_settings
    ds_auto_options
    before=$(ds_state)
    if [ "$MODE" = off ] && [ "$DS_AUTO" = 0 ] && [ "$before" = off ] && [ ! -e "$DS_DIR/request" ]; then
        log_line 'CPU profile paused and auto sleep disabled; stopping monitor.'
        exit 0
    fi
    physical_screen=$(screen_state) || physical_screen=UNKNOWN
    ay_screen_tick "$physical_screen" || log_line 'SCREEN_DELAY_TIMER_READ_ERROR'
    if [ "$AY_STANDBY" != "$last_standby" ]; then
        log_line "STANDBY_ACTIVE=$AY_STANDBY delay=$AY_SAVE_DELAY elapsed=$AY_SCREEN_ELAPSED screen=$physical_screen"
        last_standby=$AY_STANDBY
    fi
    # WebUI explicitly queues a long running operation so the manager stays
    # alive and can show progress before its own app is potentially affected.
    if [ -r "$DS_DIR/request" ] && [ "$(ds_state)" = off ]; then
        queued_boot=$(cat "$DS_DIR/request" 2>/dev/null)
        current_boot=$(cat "${YASIR_BOOT_ID:-/proc/sys/kernel/random/boot_id}" 2>/dev/null)
        rm -f "$DS_DIR/request"
        if [ "$queued_boot" = "$current_boot" ]; then
            log_line 'DEEP_REQUEST_BEGIN from WebUI'
            # CPU must drop immediately, even before slower radio verification.
            for immediate_pol in "$POLICY_ROOT"/policy*; do
                [ -r "$immediate_pol/scaling_governor" ] || continue
                if gov_supported "$immediate_pol" powersave; then
                    gov_write_verify "$immediate_pol" powersave >/dev/null 2>&1 || :
                fi
            done
            if ! ds_enter manual; then log_line "DEEP_REQUEST_FAILED:$DS_ERROR"; fi
            log_line "DEEP_REQUEST_COMPLETE state=$(ds_state)"
        else
            log_line 'DEEP_REQUEST_REJECTED_OLD_BOOT'
        fi
    fi
    # The monotonic 60-minute timer, or a one-shot auto entry, runs independent
    # of CPU mode. In particular, MODE=off does NOT disable automatic sleep.
    if ! ds_tick "$physical_screen"; then tick_error=$DS_ERROR; else tick_error=; fi
    after=$(ds_state)
    if [ "$after" = active ] || [ "$after" = partial ]; then
        # The wake latch is written ONLY after the screen has actually been OFF.
        # The transition needs to be durable across monitor restarts.
        if [ "$physical_screen" = OFF ]; then
            : > "$DS_DIR/seen_screen_off" 2>/dev/null || :
        elif [ "$physical_screen" = ON ] && [ -f "$DS_DIR/seen_screen_off" ]; then
            : > "$DS_DIR/woke_since_sleep" 2>/dev/null || :
        fi
    fi
    if [ "$tick_error" != "$last_deep_error" ]; then
        [ -z "$tick_error" ] || log_line "DEEP_ERROR:$tick_error"
        last_deep_error=$tick_error
    fi
    if [ "$after" != "$last_deep_state" ]; then
        log_line "DEEP_STATE:$before->$after screen=$physical_screen; radios not restored on wake"
        last_deep_state=$after
    fi

    screen=MANUAL; wanted=none; reason=normal
    if [ "$MODE" = auto ]; then
        screen=$physical_screen
        case "$screen" in
            ON) wanted=$ON_GOVERNOR ;;
            OFF) if [ "$AY_STANDBY" = 1 ]; then wanted=$OFF_GOVERNOR; reason=standby; else wanted=$ON_GOVERNOR; reason=standby_delay; fi ;;
            *) if [ "$unknown_reported" = 0 ]; then log_line 'SCREEN_UNKNOWN: CPU untouched'; unknown_reported=1; fi ;;
        esac
    elif [ "$MODE" != off ]; then
        wanted=$MODE
        if [ "$physical_screen" = OFF ]; then
            if [ "$AY_STANDBY" = 1 ]; then wanted=$OFF_GOVERNOR; reason=standby; else reason=standby_delay; fi
        fi
    fi
    if [ "$physical_screen" != UNKNOWN ]; then unknown_reported=0; fi
    if [ "$wanted" != none ] && [ "$physical_screen" = ON ] && [ "$after" = off ] && [ "$(cat "$AY_DATA_DIR/features/auto_game" 2>/dev/null)" = 1 ]; then
        if [ $((count_game_scan + 0)) -le 0 ]; then
            game_active=$("${YASIR_SHELL:-/system/bin/sh}" "$MODDIR/fusion.sh" game-foreground 2>/dev/null)
            count_game_scan=3
        else
            count_game_scan=$((count_game_scan-1))
        fi
        if [ -n "$game_active" ]; then wanted=performance; reason=gaming; fi
    else
        game_active=
    fi
    if [ "$wanted" != none ]; then
        if [ "$MODE" = auto ]; then ay_guard "$wanted" "$screen"; else ay_guard "$wanted" ON; fi
        wanted=$AY_TARGET
        # If a safeguard overrides a gaming boost, report the real guard.
        if [ "$AY_REASON" != normal ]; then reason=$AY_REASON; fi
    fi
    # An OFF->ON transition ends the CPU-saving phase only: it never touches
    # Wi-Fi, Bluetooth, NFC or airplane mode. The selected profile is retained.
    # When entering Deep Sleep with screen ON, a one-time immediate powersave
    # was already applied by control.sh, and is maintained until OFF->ON wake.
    if [ "$after" = active ] || [ "$after" = partial ] || [ "$after" = entering ]; then
        if [ "$physical_screen" = OFF ] || [ "$physical_screen" = UNKNOWN ]; then
            wanted=powersave; reason=deep_sleep
        elif [ ! -f "$DS_DIR/woke_since_sleep" ]; then
            wanted=powersave; reason=deep_manual_pending_screen_cycle
        else
            reason=profile_restored_radios_off
        fi
    fi

    checked=0; changed=0; failed=0; failure_details=
    if [ "$wanted" = none ] || [ "$CAPTURED" != 1 ]; then
        # The screen countdown still runs, even on unsupported kernels.
        [ "$CAPTURED" != 1 ] || restore_governors
    else
        for pol in "$POLICY_ROOT"/policy*; do
            [ -r "$pol/scaling_governor" ] || continue
            name=${pol##*/}
            checked=$((checked+1))
            if ! gov_supported "$pol" "$wanted"; then
                failed=$((failed+1))
                failure_details="$failure_details $name:unsupported"
                continue
            fi
            current=$(gov_read "$pol/scaling_governor")
            if [ "$current" != "$wanted" ]; then
                if gov_write_verify "$pol" "$wanted"; then
                    changed=$((changed+1))
                    [ "$(gov_read "$MODDIR/applied.$name" 2>/dev/null)" = "$wanted" ] || printf '%s\n' "$wanted" > "$MODDIR/applied.$name"
                else
                    failed=$((failed+1))
                    failure_details="$failure_details $name:$GOV_WRITE_ERROR"
                fi
            fi
        done
    fi
    # Core parking is opt-in, affects only an optional highest-index CPU, and
    # is undone at wake even if user keeps radios offline.
    if [ "$physical_screen" = OFF ] && [ "$(cat "$AY_DATA_DIR/features/core_saver" 2>/dev/null)" = 1 ]; then
        [ -f "$AY_DATA_DIR/features/parked_core" ] || "${YASIR_SHELL:-/system/bin/sh}" "$MODDIR/fusion.sh" core-apply >/dev/null 2>&1 || :
    elif [ -f "$AY_DATA_DIR/features/parked_core" ]; then
        "${YASIR_SHELL:-/system/bin/sh}" "$MODDIR/fusion.sh" core-restore >/dev/null 2>&1 || :
    fi
    # Per-policy frequency tuning is screen-ON, non-sleep, and opt-in only.
    freq_screen=OFF
    # Deep Sleep is a radio latch, not a CPU lock. On wake, restore both
    # the selected governor AND optional user-set clock policy.
    if [ "$MODE" = auto ] && [ "$physical_screen" = ON ] && { [ "$reason" = normal ] || [ "$reason" = profile_restored_radios_off ]; }; then freq_screen=ON; fi
    freq_error=
    if [ "$CAPTURED" = 1 ] && ! freq_apply_screen "$freq_screen"; then freq_error=${FREQ_ERROR:-unknown}; fi
    if [ "$freq_error" != "$last_freq_error" ]; then
        [ -z "$freq_error" ] || log_line "FREQ_ERROR:$freq_error"
        last_freq_error=$freq_error
    fi
    if [ "$failure_details" != "$last_failure_details" ]; then
        [ -z "$failure_details" ] || log_line "GOVERNOR_ERROR:$failure_details"
        last_failure_details=$failure_details
    fi
    if [ "$MODE" != "$last_mode" ] || [ "$physical_screen" != "$last_screen" ] || [ "$wanted" != "$last_wanted" ] || [ "$reason" != "$last_reason" ] || [ "$before" != "$after" ]; then
        log_line "mode=$MODE screen=$physical_screen wanted=$wanted reason=$reason policies=$checked changed=$changed failed=$failed"
        printf '%s\n' "$physical_screen" > "$MODDIR/last_screen"
        last_mode=$MODE; last_screen=$physical_screen; last_wanted=$wanted; last_reason=$reason
        ay_update_description "$physical_screen" "$reason" "$wanted" || :
    fi
    # 3s when OFF avoids constant heavy dumpsys activity; wake returns CPU
    # policy on the next poll. Monotonic auto timer still starts from first OFF.
    # The OFF -> ON CPU restore is checked every second (subject to Android
    # display service latency). Deep Sleep radio state is never undone here.
    if [ "$physical_screen" = OFF ]; then sleep 1; else sleep "$POLL_SECONDS"; fi
done
