#!/system/bin/sh
# AY KILL APP v7 - sensor-only guards with release hysteresis.
# Never disables Android's hardware/OEM thermal protection.
AY_BATTERY_DIR=${AY_BATTERY_DIR:-/sys/class/power_supply/battery}
ay_bat_read() {
    AY_BAT_PCT=unknown; AY_BAT_TEMP=unknown; AY_BAT_CHARGE=unknown
    if [ -r "$AY_BATTERY_DIR/capacity" ]; then
        v=$(cat "$AY_BATTERY_DIR/capacity" 2>/dev/null)
        case "$v" in ''|*[!0-9]*) : ;; *) [ "$v" -le 100 ] && AY_BAT_PCT=$v ;; esac
    fi
    if [ -r "$AY_BATTERY_DIR/temp" ]; then
        v=$(cat "$AY_BATTERY_DIR/temp" 2>/dev/null)
        case "$v" in
            ''|*[!0-9]*) : ;;
            *) if [ "$v" -le 90 ]; then v=$((v * 10)); fi
               [ "$v" -ge 0 ] && [ "$v" -le 900 ] && AY_BAT_TEMP=$v ;;
        esac
    fi
    if [ -r "$AY_BATTERY_DIR/status" ]; then
        v=$(cat "$AY_BATTERY_DIR/status" 2>/dev/null)
        case "$v" in Charging|Full|Discharging|'Not charging') AY_BAT_CHARGE=$v ;; esac
    fi
}
ay_guard_store() {
    [ -n "${AY_DATA_DIR:-}" ] || return 0
    mkdir -p "$AY_DATA_DIR" 2>/dev/null || return 0
    [ "$(cat "$AY_DATA_DIR/guard.state" 2>/dev/null)" != "$1" ] || return 0
    (umask 077; printf '%s\n' "$1" > "$AY_DATA_DIR/.guard.$$" && mv -f "$AY_DATA_DIR/.guard.$$" "$AY_DATA_DIR/guard.state") 2>/dev/null || :
}
ay_guard() {
    # Input: governor, screen. Output: AY_TARGET and AY_REASON.
    AY_TARGET=$1; AY_REASON=normal
    [ "$2" = ON ] || return 0
    ay_bat_read
    ay_prev=$(cat "${AY_DATA_DIR:-/data/adb/ay_lightning}/guard.state" 2>/dev/null)
    # Battery guard recovers 3 percentage points ABOVE the trip threshold.
    if [ "${SAFE_BATTERY:-off}" != off ] && [ "$AY_BAT_PCT" != unknown ] && [ "$AY_BAT_CHARGE" != Charging ] && [ "$AY_BAT_CHARGE" != Full ]; then
        case "$SAFE_BATTERY" in 15|20|25|30)
            ay_trip=$SAFE_BATTERY
            [ "$ay_prev" = low_battery ] && ay_trip=$((SAFE_BATTERY + 2))
            if [ "$AY_BAT_PCT" -le "$ay_trip" ]; then
                AY_TARGET=powersave; AY_REASON=low_battery
                ay_guard_store "$AY_REASON"
                return 0
            fi
        ;; esac
    fi
    # Temperature guard recovers 2 C BELOW its trip threshold.
    if [ "${SAFE_TEMP:-off}" != off ] && [ "$AY_BAT_TEMP" != unknown ]; then
        case "$SAFE_TEMP" in 40|42|45|48)
            ay_trip=$((SAFE_TEMP * 10))
            [ "$ay_prev" = high_battery_temp ] && ay_trip=$((ay_trip - 20))
            if [ "$AY_BAT_TEMP" -ge "$ay_trip" ]; then
                if [ "$1" = powersave ]; then
                    AY_TARGET=powersave
                else
                    ay_supported=1
                    for ay_pol in "$POLICY_ROOT"/policy*; do
                        [ -r "$ay_pol/scaling_governor" ] || continue
                        gov_supported "$ay_pol" schedutil || { ay_supported=0; break; }
                    done
                    if [ "$ay_supported" = 1 ]; then AY_TARGET=schedutil; else AY_TARGET=powersave; fi
                fi
                AY_REASON=high_battery_temp
                ay_guard_store "$AY_REASON"
                return 0
            fi
        ;; esac
    fi
    # Optional safeguards may be disabled, but never insist on the maximum
    # profile if battery temperature reaches an extreme (>=48 C, resume <46).
    if [ "$1" = performance ] && [ "$AY_BAT_TEMP" != unknown ]; then
        ay_trip=480
        [ "$ay_prev" = extreme_heat ] && ay_trip=460
        if [ "$AY_BAT_TEMP" -ge "$ay_trip" ]; then
            ay_has_schedutil=1
            for ay_pol in "$POLICY_ROOT"/policy*; do
                [ -r "$ay_pol/scaling_governor" ] || continue
                if ! gov_supported "$ay_pol" schedutil; then ay_has_schedutil=0; break; fi
            done
            if [ "$ay_has_schedutil" = 1 ]; then AY_TARGET=schedutil; else AY_TARGET=powersave; fi
            AY_REASON=extreme_heat
            ay_guard_store "$AY_REASON"
            return 0
        fi
    fi
    ay_guard_store normal
}
