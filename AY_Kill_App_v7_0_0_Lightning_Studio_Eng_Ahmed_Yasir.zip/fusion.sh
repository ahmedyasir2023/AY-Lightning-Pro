#!/system/bin/sh
# AY KILL APP v7 Fusion: strictly whitelisted optional tool actions.
# OEM thermal protection is NEVER bypassed. Android and root managers are NEVER stopped.
MODDIR=${YASIR_MODDIR:-${0%/*}}
AY_DATA_DIR=${AY_DATA_DIR:-/data/adb/ay_lightning}
POLICY_ROOT=${YASIR_POLICY_ROOT:-/sys/devices/system/cpu/cpufreq}
FX="$AY_DATA_DIR/features"
mkdir -p "$FX" 2>/dev/null || :
chmod 700 "$AY_DATA_DIR" "$FX" 2>/dev/null || :
PATH="/system/bin:/system/xbin:/vendor/bin:$PATH"
export PATH
. "$MODDIR/governor-lib.sh" 2>/dev/null || :
. "$MODDIR/freq-lib.sh" 2>/dev/null || :
fx_fail() { printf 'ERROR|%s\n' "$1"; exit 1; }
fx_ok() { printf 'OK|%s\n' "$1"; exit 0; }
fx_num() { case "$1" in ''|*[!0-9]*) return 1;; *) return 0;; esac; }
fx_pkg() { case "$1" in *.*) case "$1" in ''|.*|*[!a-zA-Z0-9._]*) return 1;; *) return 0;; esac ;; *) return 1;; esac; }
fx_save() { case "$1" in auto_game|core_saver|net_tune|charge_limit) :;; *) return 1;; esac; (umask 077; echo "$2" > "$FX/.${1}.$$" && mv -f "$FX/.${1}.$$" "$FX/$1"); }
fx_get() { v=$(cat "$FX/$1" 2>/dev/null); case "$v" in 1) printf 1;; *) printf 0;; esac; }
fx_say() { printf 'F|%s|%s\n' "$1" "$2"; }
fx_log() { printf '%s | FUSION %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$MODDIR/status.log" 2>/dev/null || :; }
fx_user_pkgs() { pm list packages -3 2>/dev/null | sed -n 's/^package://p' | sort -u; }
fx_saved_game() { [ -s "$FX/games" ] && grep -Fx "$1" "$FX/games" >/dev/null 2>&1; }
fx_full_status() {
    for item in auto_game core_saver net_tune charge_limit; do fx_say "$item" "$(fx_get "$item")"; done
    fx_say games "$(wc -l < "$FX/games" 2>/dev/null | tr -d ' ' || printf 0)"
    fx_say dns_mode "$(settings get global private_dns_mode 2>/dev/null | tr -d '\r\n')"
    fx_say dns_host "$(settings get global private_dns_specifier 2>/dev/null | tr -d '\r\n')"
    fx_say renderer_count "$(wc -l < "$FX/render_apps" 2>/dev/null | tr -d ' ' || printf 0)"
    fx_say underclock "$(cat "$FX/underclock" 2>/dev/null || printf stock)"
    fx_say charge_ma "$(cat "$FX/charge_ma" 2>/dev/null || printf off)"
    fx_say resolution "$(wm size 2>/dev/null | sed -n 's/^Override size: //p' | head -n 1)"
    fx_say gpu "$(cat /sys/class/kgsl/kgsl-3d0/gpuclk 2>/dev/null || printf unknown)"
    fx_say thermal 'OEM_protection_enabled_no_bypass'
    fx_say tcp "$(cat /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null || printf unknown)"
    fx_say driver 'Android_ANGLE_options'
    fx_say spoof "$(cat "$FX/spoof" 2>/dev/null || printf off)"
    fx_say data_note 'System_and_root_managers_excluded_from_force_stop'
    fx_say ui_version 'fusion7'
}
fx_is_game() {
    fx_fg=$(dumpsys activity activities 2>/dev/null | grep -m1 -E 'topResumedActivity|mResumedActivity' | sed -n 's/.* \([a-zA-Z0-9_.]*\)\/[a-zA-Z0-9_.]*.*/\1/p')
    [ -n "$fx_fg" ] || fx_fg=$(dumpsys window 2>/dev/null | grep -m1 'mCurrentFocus' | sed -n 's/.* \([a-zA-Z0-9_.]*\)\/[a-zA-Z0-9_.]*.*/\1/p')
    [ -n "$fx_fg" ] && fx_saved_game "$fx_fg" && printf '%s\n' "$fx_fg"
    return 0
}
fx_core_restore() {
    [ -f "$FX/parked_core" ] || return 0
    read -r cp old < "$FX/parked_core" || return 1
    case "$cp" in cpu[1-9]* ) : ;; *) rm -f "$FX/parked_core"; return 1 ;; esac
    cp_id=${cp#cpu}; fx_num "$cp_id" || return 1
    p="/sys/devices/system/cpu/$cp/online"
    if [ -w "$p" ] && [ "$(cat "$p" 2>/dev/null)" = 0 ]; then printf '1\n' > "$p" 2>/dev/null || return 1; fi
    rm -f "$FX/parked_core"
}
fx_core_apply() {
    [ -f "$FX/parked_core" ] && return 0
    [ "$(fx_get core_saver)" = 1 ] || return 0
    count=0; chosen=
    for p in /sys/devices/system/cpu/cpu[0-9]*; do
        [ -d "$p" ] || continue
        count=$((count+1))
        [ -w "$p/online" ] && [ "$(cat "$p/online" 2>/dev/null)" = 1 ] && chosen=$p
    done
    # At least four CPUs, never park cpu0, and at most ONE optional core.
    [ "$count" -ge 4 ] && [ -n "$chosen" ] && [ "${chosen##*/}" != cpu0 ] || return 0
    printf '0\n' > "$chosen/online" 2>/dev/null || return 0
    [ "$(cat "$chosen/online" 2>/dev/null)" = 0 ] || return 0
    printf '%s 1\n' "${chosen##*/}" > "$FX/parked_core"
    fx_log "CORE_PARK ${chosen##*/}"
}
fx_net_apply() {
    sys=/proc/sys/net/ipv4/tcp_congestion_control
    [ -r "$sys" ] && [ -w "$sys" ] || return 1
    if [ ! -s "$FX/tcp_original" ]; then cat "$sys" > "$FX/tcp_original"; fi
    av=$(cat /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null)
    case " $av " in *' bbr '*) choose=bbr;; *' cubic '*) choose=cubic;; *) return 1;; esac
    printf '%s\n' "$choose" > "$sys" 2>/dev/null && [ "$(cat "$sys" 2>/dev/null)" = "$choose" ]
}
fx_net_restore() {
    sys=/proc/sys/net/ipv4/tcp_congestion_control
    if [ -s "$FX/tcp_original" ] && [ -w "$sys" ]; then
        read -r original < "$FX/tcp_original"
        case "$original" in *[!a-zA-Z0-9_-]*|'') :;; *) printf '%s\n' "$original" > "$sys" 2>/dev/null || :;; esac
    fi
    rm -f "$FX/tcp_original"
}
fx_charge_apply() {
    val=$1; fx_num "$val" || return 1
    [ "$val" -ge 500 ] && [ "$val" -le 2000 ] || return 1
    ua=$((val*1000)); success=0
    for path in /sys/class/power_supply/usb/input_current_limit /sys/class/power_supply/battery/input_current_limit; do
        [ -r "$path" ] && [ -w "$path" ] || continue
        orig=$(cat "$path" 2>/dev/null)
        fx_num "$orig" || continue
        [ "$orig" -ge 500000 ] || continue
        # NEVER increase a device's charging current beyond its pre-change value.
        if [ -f "$FX/charge_original" ]; then
            base=$(sed -n "s|^$path | |p" "$FX/charge_original" | tr -d ' ' | head -n1)
            fx_num "$base" || base=$orig
        else base=$orig; fi
        [ "$ua" -le "$base" ] || continue
        if [ "$ua" -le "$orig" ] || [ "$orig" -lt "$base" ]; then
            if [ ! -s "$FX/charge_original" ]; then printf '%s %s\n' "$path" "$orig" > "$FX/charge_original"; fi
            printf '%s\n' "$ua" > "$path" 2>/dev/null || continue
            if [ "$(cat "$path" 2>/dev/null)" = "$ua" ]; then success=1; break; fi
        fi
    done
    [ "$success" -gt 0 ]
}
fx_charge_restore() {
    [ -f "$FX/charge_original" ] || return 0
    while read -r path val; do
        case "$path" in /sys/class/power_supply/usb/input_current_limit|/sys/class/power_supply/battery/input_current_limit) :;; *) continue;; esac
        fx_num "$val" || continue
        [ -w "$path" ] && printf '%s\n' "$val" > "$path" 2>/dev/null || :
    done < "$FX/charge_original"
    rm -f "$FX/charge_original"
}
fx_underclock_reset() {
    # Do not discard custom frequency policies configured before a temporary cap.
    if [ -f "$FX/underclock_saved/.saved" ]; then
        rm -f "$AY_DATA_DIR"/freq.policy*
        for saved in "$FX"/underclock_saved/freq.policy*; do
            [ -f "$saved" ] && cp -f "$saved" "$AY_DATA_DIR/" || :
        done
        rm -rf "$FX/underclock_saved"
    fi
    echo stock > "$FX/underclock"
    freq_restore_all >/dev/null 2>&1 || :
}
fx_underclock() {
    level=$1
    case "$level" in
        stock) fx_underclock_reset;fx_ok 'CPU frequency settings saved before Underclock were restored' ;;
        80|60|40) : ;;
        *) fx_fail 'Underclock level must be stock/80/60/40' ;;
    esac
    freq_boot_prepare || fx_fail 'Cannot capture original CPU frequency limits'
    if [ ! -f "$FX/underclock_saved/.saved" ]; then
        mkdir -p "$FX/underclock_saved" || fx_fail 'Cannot save existing frequency settings'
        for old in "$AY_DATA_DIR"/freq.policy*; do
            [ -f "$old" ] && cp -f "$old" "$FX/underclock_saved/" || :
        done
        : > "$FX/underclock_saved/.saved" || fx_fail 'Cannot save original frequency snapshot'
    fi
    results=0; failures=0
    for p in "$POLICY_ROOT"/policy*; do
        [ -r "$p/cpuinfo_min_freq" ] && [ -r "$p/cpuinfo_max_freq" ] || continue
        min=$(cat "$p/cpuinfo_min_freq" 2>/dev/null); max=$(cat "$p/cpuinfo_max_freq" 2>/dev/null)
        fx_num "$min" && fx_num "$max" || continue
        goal=$((min+(max-min)*level/100))
        avail=$(cat "$p/scaling_available_frequencies" 2>/dev/null)
        if [ -n "$avail" ]; then
            chosen=
            for n in $avail; do
                fx_num "$n" || continue
                [ "$n" -le "$goal" ] && { if [ -z "$chosen" ] || [ "$n" -gt "$chosen" ]; then chosen=$n; fi; }
            done
        else
            # Without a declared step list, guessing a random kHz is unsafe.
            chosen=
        fi
        [ -n "$chosen" ] || { failures=$((failures+1)); continue; }
        freq_set "${p##*/}" stock "$chosen" && results=$((results+1)) || failures=$((failures+1))
    done
    [ "$results" -gt 0 ] || fx_fail 'No supported CPU policy frequency table; no changes applied'
    echo "$level" > "$FX/underclock"
    fx_log "UNDERCLOCK $level policies=$results failures=$failures"
    printf 'OK|Underclock %s%% stored for %s policies. Applied when screen ON in auto mode; skipped %s unsupported policies.\n' "$level" "$results" "$failures"
}
fx_resolution() {
    mode=$1
    if [ ! -f "$FX/res_original" ]; then
        wm size 2>/dev/null | sed -n 's/^Override size: //p' | head -n 1 > "$FX/res_original"
    fi
    case "$mode" in
        reset) wm size reset >/dev/null 2>&1 || fx_fail 'Window Manager rejected reset'; fx_ok 'Display resolution reset' ;;
        720|540) :;; *) fx_fail 'Resolution must be reset/720/540' ;;
    esac
    phys=$(wm size 2>/dev/null | sed -n 's/^Physical size: //p' | head -n 1)
    case "$phys" in *x*) :;; *) fx_fail 'Cannot read physical display dimensions';; esac
    w=${phys%x*};h=${phys#*x}; fx_num "$w" && fx_num "$h" || fx_fail 'Invalid display dimensions'
    [ "$w" -gt 0 ] && [ "$h" -gt 0 ] || fx_fail 'Invalid physical size'
    if [ "$w" -lt "$h" ]; then short=$w;long=$h;flip=0;else short=$h;long=$w;flip=1;fi
    target=$mode; [ "$target" -le "$short" ] || target=$short
    [ "$target" -ge 360 ] || fx_fail 'Device native display too small'
    length=$((long*target/short)); length=$((length/2*2))
    [ "$flip" = 1 ] && dims="${length}x${target}" || dims="${target}x${length}"
    wm size "$dims" >/dev/null 2>&1 || fx_fail 'Window Manager rejected resolution'
    fx_log "RESOLUTION $dims"
    fx_ok "Resolution applied: $dims (reset available)"
}
fx_dns() {
    host=$1
    if [ ! -f "$FX/dns_original" ]; then
        old_mode=$(settings get global private_dns_mode 2>/dev/null)
        old_host=$(settings get global private_dns_specifier 2>/dev/null)
        printf '%s|%s\n' "$old_mode" "$old_host" > "$FX/dns_original"
    fi
    case "$host" in
        auto) settings put global private_dns_mode opportunistic >/dev/null 2>&1 || fx_fail 'Settings refused DNS'; settings delete global private_dns_specifier >/dev/null 2>&1 || :;;
        off) settings put global private_dns_mode off >/dev/null 2>&1 || fx_fail 'Settings refused DNS'; settings delete global private_dns_specifier >/dev/null 2>&1 || :;;
        *) case "$host" in ''|*[!a-zA-Z0-9.-]*|.*|*..*|*.) fx_fail 'Invalid DNS hostname';; esac
           # Android 9+ official system Private DNS; no iptables or packet interception.
           settings put global private_dns_specifier "$host" >/dev/null 2>&1 || fx_fail 'Cannot set hostname'
           settings put global private_dns_mode hostname >/dev/null 2>&1 || fx_fail 'Cannot set Private DNS mode';;
    esac
    fx_log "PRIVATE_DNS $host"
    fx_ok "Private DNS set to $host (availability depends on network)"
}
fx_render_save() {
    pkg=$1;eng=$2
    if [ ! -f "$FX/angle_original" ]; then
        printf '%s|%s\n' "$(settings get global angle_gl_driver_selection_pkgs 2>/dev/null)" "$(settings get global angle_gl_driver_selection_values 2>/dev/null)" > "$FX/angle_original"
    fi
    fx_pkg "$pkg" || fx_fail 'Invalid app package'
    case "$eng" in native|angle|default) :;; *) fx_fail 'Unsupported per-app renderer option';; esac
    tmp="$FX/.render.$$"
    if [ -s "$FX/render_apps" ]; then grep -v -F "$pkg=" "$FX/render_apps" > "$tmp" || :;else : > "$tmp";fi
    [ "$eng" = default ] || printf '%s=%s\n' "$pkg" "$eng" >> "$tmp"
    mv -f "$tmp" "$FX/render_apps" || fx_fail 'Cannot persist render profile'
    pkgs=;vals=
    while IFS='=' read -r app driver; do
        fx_pkg "$app" || continue
        case "$driver" in angle) pkgs="${pkgs}${pkgs:+,}$app";vals="${vals}${vals:+,}angle";; esac
    done < "$FX/render_apps"
    settings put global angle_gl_driver_selection_pkgs "$pkgs" >/dev/null 2>&1 || fx_fail 'Android rejected ANGLE app selection'
    settings put global angle_gl_driver_selection_values "$vals" >/dev/null 2>&1 || fx_fail 'Android rejected ANGLE values'
    fx_log "RENDER $pkg $eng"
    fx_ok "Renderer saved; ANGLE only effective if installed/supported by Android"
}
fx_spoof() {
    # Spoofing build identity at boot can break OEM services/OTA/integrity checks.
    # Only temporary, opt-in model cosmetics; reboot reverts system properties.
    mode=$1
    case "$mode" in
        off) [ -s "$FX/spoof_original" ] || { echo off > "$FX/spoof";fx_ok 'Device identity is already original'; }; old=$(cat "$FX/spoof_original");;
        mi14u) old=24030PN60G ;;
        rog8) old=ASUS_AI2401_A ;;
        s24u) old=SM-S928B ;;
        rm9) old=NX769J ;;
        *) fx_fail 'Unknown optional model identity preset';;
    esac
    command -v resetprop >/dev/null 2>&1 || fx_fail 'resetprop not installed; device spoof unsupported'
    if [ "$mode" != off ] && [ ! -s "$FX/spoof_original" ]; then getprop ro.product.model > "$FX/spoof_original"; fi
    resetprop ro.product.model "$old" >/dev/null 2>&1 || fx_fail 'resetprop refused model change'
    if [ "$mode" = off ]; then rm -f "$FX/spoof_original";fi
    echo "$mode" > "$FX/spoof"
    fx_log "TEMP_MODEL $mode"
    fx_ok 'Temporary model override; resets after reboot (OEM identity properties unchanged)'
}
fx_restore_system() {
    fx_underclock_reset || :
    fx_core_restore || :
    fx_net_restore || :
    fx_charge_restore || :
    if [ -f "$FX/dns_original" ]; then
        IFS='|' read -r old_mode old_host < "$FX/dns_original" || :
        case "$old_mode" in null|'') settings delete global private_dns_mode >/dev/null 2>&1 || :;; hostname|off|opportunistic) settings put global private_dns_mode "$old_mode" >/dev/null 2>&1 || :;; esac
        case "$old_host" in null|'') settings delete global private_dns_specifier >/dev/null 2>&1 || :;; *[!a-zA-Z0-9.-]*) :;; *) settings put global private_dns_specifier "$old_host" >/dev/null 2>&1 || :;; esac
        rm -f "$FX/dns_original"
    fi
    if [ -f "$FX/res_original" ]; then
        oldres=$(cat "$FX/res_original")
        case "$oldres" in *x*) wm size "$oldres" >/dev/null 2>&1 || :;; *) wm size reset >/dev/null 2>&1 || :;; esac
        rm -f "$FX/res_original"
    fi
    if [ -f "$FX/angle_original" ]; then
        IFS='|' read -r old_p old_v < "$FX/angle_original" || :
        if [ "$old_p" = null ] || [ -z "$old_p" ]; then settings delete global angle_gl_driver_selection_pkgs >/dev/null 2>&1 || :; else settings put global angle_gl_driver_selection_pkgs "$old_p" >/dev/null 2>&1 || :;fi
        if [ "$old_v" = null ] || [ -z "$old_v" ]; then settings delete global angle_gl_driver_selection_values >/dev/null 2>&1 || :; else settings put global angle_gl_driver_selection_values "$old_v" >/dev/null 2>&1 || :;fi
        rm -f "$FX/angle_original"
    fi
    [ "$(cat "$FX/spoof" 2>/dev/null)" = off ] || { command -v resetprop >/dev/null 2>&1 && [ -s "$FX/spoof_original" ] && resetprop ro.product.model "$(cat "$FX/spoof_original")" >/dev/null 2>&1 || :; }
    rm -f "$FX/spoof_original" "$FX/spoof"
}
case "${1:-}" in
    status) fx_full_status ;;
    apps) fx_user_pkgs | head -n 400 | while read -r app; do printf 'APP|%s\n' "$app"; done ;;
    games) [ -s "$FX/games" ] && while read -r app;do printf 'GAME|%s\n' "$app";done < "$FX/games" ;;
    render-list) [ -s "$FX/render_apps" ] && while read -r app; do printf 'RENDER|%s\n' "$app"; done < "$FX/render_apps" ;;
    game-foreground) fx_is_game ;;
    game-scan)
        # Read-only Android game-category discovery, never guess from app name.
        command -v dumpsys >/dev/null 2>&1 || fx_fail 'Android dumpsys unavailable'
        total=0; found=0
        tmp="$FX/.gamescan.$$"
        if [ -s "$FX/games" ]; then cp -f "$FX/games" "$tmp" || fx_fail 'Game list is not writable';else : > "$tmp" || fx_fail 'Game list is not writable';fi
        for app in $(fx_user_pkgs | head -n 150); do
            fx_pkg "$app" || continue
            total=$((total+1))
            # Not all OEM package dumps expose category; scanning is best effort.
            if dumpsys package "$app" 2>/dev/null | grep -i -m1 -E 'category=GAME|appCategory=0|android.intent.category.GAME' >/dev/null 2>&1;then
                if ! grep -Fx "$app" "$tmp" >/dev/null 2>&1;then
                    printf '%s\n' "$app" >> "$tmp"
                    found=$((found+1))
                fi
            fi
        done
        mv -f "$tmp" "$FX/games" || fx_fail 'Could not save detected games'
        fx_log "GAME_SCAN scanned=$total added=$found"
        fx_ok "Scanned $total apps, added $found games identified by Android (OEM categories may be missing)" ;;
    dns-ping)
        ip=${2:-}
        case "$ip" in ''|*[!0-9.]*) fx_fail 'An IPv4 address is required' ;; esac
        prev_ifs=$IFS;IFS=.;set -- $ip;IFS=$prev_ifs
        [ "$#" -eq 4 ] || fx_fail 'Invalid IPv4 address'
        for part in "$@";do fx_num "$part" && [ "$part" -le 255 ] || fx_fail 'Invalid IPv4 address';done
        . "$MODDIR/deep-lib.sh" || fx_fail 'Deep Sleep state unavailable'
        [ "$(ds_state)" = off ] || fx_fail 'DNS test is unavailable while radios are disconnected'
        command -v ping >/dev/null 2>&1 || fx_fail 'Ping utility unavailable'
        result=$(ping -n -c 1 -w 3 "$ip" 2>&1) || fx_fail 'No ping reply; ICMP may be blocked by your provider'
        time_ms=$(printf '%s\n' "$result" | sed -n 's/.*time[=<]\([0-9.]*\).*/\1/p' | head -n 1)
        [ -n "$time_ms" ] || fx_fail 'No ICMP latency reported'
        fx_ok "Ping to $ip: $time_ms ms (ICMP only, not DNS-over-TLS latency)" ;;
    game-add|game-remove)
        fx_pkg "${2:-}" || fx_fail 'Invalid game package'
        [ "$1" = game-remove ] || pm path "$2" >/dev/null 2>&1 || fx_fail 'App package is not installed'
        tmp="$FX/.games.$$"
        if [ -s "$FX/games" ]; then grep -v -Fx "$2" "$FX/games" > "$tmp" || :;else : > "$tmp";fi
        [ "$1" = game-remove ] || printf '%s\n' "$2" >> "$tmp"
        mv -f "$tmp" "$FX/games" || fx_fail 'Could not save game list'
        fx_log "$1 $2";fx_ok 'Game list updated' ;;
    feature)
        name=${2:-}; flag=${3:-}
        case "$name" in auto_game|core_saver) :;; *) fx_fail 'Feature key not in toggle whitelist';; esac
        case "$flag" in 0|1) :;; *) fx_fail 'Toggle value must be 0 or 1';; esac
        fx_save "$name" "$flag" || fx_fail 'Cannot save feature toggle'
        [ "$name" != core_saver ] || [ "$flag" != 0 ] || fx_core_restore
        fx_log "FEATURE $name=$flag"
        fx_ok "Feature $name set to $flag" ;;
    onboot)
        [ "$(fx_get net_tune)" = 1 ] && fx_net_apply >/dev/null 2>&1 || :
        if [ "$(fx_get charge_limit)" = 1 ]; then
            lim=$(cat "$FX/charge_ma" 2>/dev/null)
            case "$lim" in 500|1000|1500|2000) fx_charge_apply "$lim" >/dev/null 2>&1 || :;; esac
        fi
        exit 0 ;;
    core-apply) fx_core_apply ;;
    core-restore) fx_core_restore ;;
    underclock) fx_underclock "${2:-}" ;;
    resolution) fx_resolution "${2:-}" ;;
    render-set) fx_render_save "${2:-}" "${3:-}" ;;
    dns) fx_dns "${2:-}" ;;
    spoof) fx_spoof "${2:-}" ;;
    net-tune)
        case "${2:-}" in
            1) fx_net_apply || fx_fail 'Kernel rejects supported congestion-control tuning';fx_save net_tune 1;;
            0) fx_net_restore;fx_save net_tune 0;;
            *) fx_fail 'Network mode must be 0 or 1';;
        esac
        fx_log "NET_TUNE $2";fx_ok "Network tuning set to $2" ;;
    net-refresh)
        # Never bring radios online behind Deep Sleep user's back.
        . "$MODDIR/deep-lib.sh" || fx_fail 'Deep state unavailable'
        case "$(ds_state)" in off) :;; *) fx_fail 'Disable Deep Sleep manually before network refresh';; esac
        prev=$(ds_read_air 2>/dev/null || printf x)
        [ "$prev" = 0 ] || fx_fail 'Cannot safely refresh while airplane mode active'
        "${YASIR_CMD:-/system/bin/cmd}" connectivity airplane-mode enable >/dev/null 2>&1 || fx_fail 'Radio toggle unavailable'
        sleep 2
        "${YASIR_CMD:-/system/bin/cmd}" connectivity airplane-mode disable >/dev/null 2>&1 || fx_fail 'Radio restore failed; switch airplane mode off manually'
        fx_log NET_REFRESH;fx_ok 'Cellular network re-registered; previous airplane-mode state restored' ;;
    charge)
        case "${2:-}" in
            off) fx_charge_restore;fx_save charge_limit 0;echo off > "$FX/charge_ma";fx_ok 'Charging input current restored when supported' ;;
            500|1000|1500|2000) fx_charge_apply "$2" || fx_fail 'No compatible verified charge-limit sysfs node; nothing changed';fx_save charge_limit 1;echo "$2" > "$FX/charge_ma";fx_ok "Input charging current capped at $2 mA where supported (never increased)" ;;
            *) fx_fail 'Charging limit must be off/500/1000/1500/2000';;
        esac ;;
    flush)
        before=$(awk '/^MemAvailable:/{print int($2/1024);exit}' /proc/meminfo)
        am kill-all >/dev/null 2>&1 || :
        sync
        # No kill -9 of arbitrary processes and no global drop_caches trick.
        after=$(awk '/^MemAvailable:/{print int($2/1024);exit}' /proc/meminfo)
        fx_log "FLUSH before=$before after=$after"
        fx_ok "Cached background trim requested. Available RAM: ${before:-?} MB to ${after:-?} MB; not guaranteed to increase" ;;
    trim)
        command -v fstrim >/dev/null 2>&1 || fx_fail 'fstrim utility unavailable'
        fstrim /data >/dev/null 2>&1 || fx_fail 'fstrim not supported or denied on /data'
        fx_log FSTRIM;fx_ok 'Filesystem TRIM completed' ;;
    modules)
        for path in /data/adb/modules/*;do [ -f "$path/module.prop" ] || continue
            id=${path##*/}; [ "$id" = eng_ahmed_yasir_screen_gov ] && continue
            if [ -f "$path/disable" ];then enabled=0;else enabled=1;fi
            modname=$(sed -n 's/^name=//p' "$path/module.prop" | head -n 1 | tr '\n|' '  ')
            case "$id $modname" in *[Tt]hermal*|*[Pp]erf*|*[Zz]ram*|*[Cc]pu*|*[Dd]oze*|*[Gg]overnor*|*[Tt]weak*)risk=possible;; *)risk=unknown;; esac
            printf 'MODULE|%s|%s|%s|%s\n' "$id" "$risk" "$enabled" "$modname"
        done ;;
    module-toggle)
        id=${2:-}; desired=${3:-}
        case "$id" in ''|*[!a-zA-Z0-9._-]*|eng_ahmed_yasir_screen_gov|*magisk*|*kernelsu*|*ksu*|*apatch*|*root*|*zygisk*|*lsposed*) fx_fail 'Cannot modify a root or essential module' ;; esac
        path="/data/adb/modules/$id"
        [ -f "$path/module.prop" ] || fx_fail 'Module does not exist'
        case "$desired" in
            0) : > "$path/disable" || fx_fail 'Cannot disable this module' ;;
            1) [ -f "$path/disable" ] || fx_fail 'Module already enabled'; rm -f "$path/disable" || fx_fail 'Cannot enable module' ;;
            *) fx_fail 'Module desired status must be 0 or 1' ;;
        esac
        fx_log "MODULE_TOGGLE $id $desired"
        fx_ok 'Module status changed; reboot required before the change takes effect' ;;
    thermal) # Read-only: OEM trip limits and throttling remain untouched.
        for z in /sys/class/thermal/thermal_zone*;do [ -r "$z/temp" ] || continue
            tp=$(cat "$z/type" 2>/dev/null);val=$(cat "$z/temp" 2>/dev/null)
            case "$tp" in *cpu*|*soc*|*gpu*|*battery*|*skin*) printf 'THERMAL|%s|%s\n' "$tp" "$val";; esac
        done | head -n 20 ;;
    restart)
        "${YASIR_SHELL:-/system/bin/sh}" "$MODDIR/service.sh" || fx_fail 'Monitor start failed'
        fx_ok 'Monitor start requested' ;;
    reset-fusion)
        fx_restore_system
        rm -f "$FX"/auto_game "$FX"/core_saver "$FX"/net_tune "$FX"/charge_limit "$FX"/games "$FX"/render_apps "$FX"/underclock "$FX"/charge_ma
        fx_log RESET_FUSION;fx_ok 'Fusion settings reset; selected AY CPU profile retained' ;;
    restore-system) fx_restore_system;fx_ok 'Optional system settings restored' ;;
    *) fx_fail 'Unknown Fusion feature; no command executed' ;;
esac
