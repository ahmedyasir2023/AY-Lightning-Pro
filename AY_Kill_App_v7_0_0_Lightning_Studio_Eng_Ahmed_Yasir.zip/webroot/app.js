(()=>{'use strict';
const BASE='/system/bin/sh /data/adb/modules/eng_ahmed_yasir_screen_gov/control.sh ';
const $=id=>document.getElementById(id), $in=(id,root=document)=>root.querySelector('#'+id);
const root=document.documentElement;
const hasBridge=()=>!!((window.ksu&&typeof window.ksu.exec==='function')||(window.mmrl&&typeof window.mmrl.exec==='function'));
let sleepPolling=false, studioState={knobs:[],metrics:[]};
let language='ar',theme='dark',busy=false,active='',current={policies:[],clocks:[],backups:[],available:[],features:{},render:[],games:[],apps:[]},lastPage='all',toastTimeout=null,refreshing=false;
const ORIGINALS=new WeakMap();
let nativeApps={};
function appName(pkg){return nativeApps[pkg]||pkg;}
function appIcon(pkg){if(!nativeApps[pkg]||!/^([a-zA-Z0-9_]+\.)+[a-zA-Z0-9_]+$/.test(pkg))return null;
 const img=document.createElement('img');img.className='native-app-icon';img.alt='';img.loading='lazy';img.src='ksu://icon/'+pkg;img.onerror=()=>img.remove();return img;}
function resolveNativeApps(packages){
 if(!window.ksu||typeof window.ksu.getPackagesInfo!=='function')return;
 try{const response=window.ksu.getPackagesInfo(JSON.stringify(packages.slice(0,250)));
 const infos=typeof response==='string'?JSON.parse(response):response;
 if(Array.isArray(infos))for(const x of infos){if(x&&x.packageName&&x.appLabel&&!x.error)nativeApps[x.packageName]=x.appLabel;}
 }catch(_){/* Support older WebUI bridges without native package metadata. */}
}

const EN={sleepEngine:'INTELLIGENT SLEEP ENGINE',sleepHeroDesc:'Disconnect radios, stop third-party apps, then recover your chosen CPU profile on screen wake — without reconnecting.',sleepNow:'ENTER DEEP SLEEP ↗',restoreRadio:'Restore connections',loading:'Loading…',wakePromise:'Wake restores your CPU profile, not your radios',selectedProfile:'Selected profile',cpuActual:'Actual CPU governor',battery:'Battery',daemon:'Monitoring daemon',controlCenter:'CONTROL CENTER',everything:'Everything in your control.',all:'All',categoryPower:'Power & CPU',categoryNetwork:'Connectivity',categorySystem:'System',performance:'Performance profiles',profilesSub:'5 CPU modes · Adaptive',deepManager:'Deep Sleep manager',sleepCardSub:'60-min auto trigger · Offline',batteryCtrl:'Battery & Charging',signalTools:'Signal tools',displayTools:'Display & Identity',memoryTools:'Cached memory · FSTRIM',conflictTools:'Module conflicts',diagnosticTools:'Diagnostics & backups',thermalDisclaimer:'OEM thermal protection remains enabled · Capability varies by device',profileHint:'Select the real CPU profile to restore after screen wake, even while the radios remain offline.',customGov:'Manual governors',manualHint:'Manual mode does not follow screen changes, except during Deep Sleep.',sleepState:'Sleep state',sleepRetry:'Retry offline',sleepCaveat:'Calls, SMS and internet notifications will not arrive in Deep Sleep. Screen wake restores CPU performance only.',sleepOptions:'Deep Sleep options',afterHour:'Enter Deep Sleep after 60 minutes screen OFF',timerDescription:'Timer resets each time the screen turns ON',stopApps:'Force-stop third-party apps',stopAppsNote:'Root managers, Android services, home, keyboard and dialer are excluded',saveOptions:'Save sleep options',screenOffElapsed:'Screen OFF duration',appStoppedCount:'Apps stopped on last entry',radioStatus:'Radios',profileHint:'Choose your actual CPU profile, restored at wake.',gamesHint:'Select installed games. The service can use Performance governor while they are foreground, then returns to the chosen profile.',autoGameText:'Boost only when a registered game is foreground',gameList:'Registered games',add:'Add',installedApps:'Installed app',renderHint:'Configure per-app ANGLE preference only where Android supports it. No global renderer overrides.',rendererChoice:'Graphics engine',apply:'Apply',customApps:'Per-app render policies',batteryHint:'No increase of charging current or bypass of device thermal protection.',chargingLimit:'Charging input current cap',chargeNote:'Reductions only. Requires a supported kernel sysfs node. Original values are never exceeded.',thermalGuard:'Battery & thermal safeguards',save:'Save',coreSaver:'Park one optional CPU core while screen OFF',coreNote:'Only on supported multi-core devices; restored on wake.',netHint:'Conservative network tuning; actual latency and speed depend on your modem, ROM and carrier.',tcpDescription:'Prefer BBR or Cubic when kernel supports it',signalRefresh:'Cellular signal refresh',signalWarn:'Temporarily disconnects cellular radios for a few seconds. Not available in Deep Sleep.',refreshSignal:'Refresh network now',dnsHint:'Choose a DNS-over-TLS resolver; Android 9+ and network support required.',chooseDns:'DNS provider',customHost:'Custom DoT hostname',customApply:'Apply custom host',dnsMode:'Active mode',dnsHost:'Current host',displayHint:'Optional changes can be reset; screen dimensions may affect application layout.',resolution:'Display resolution',modelSpoof:'Temporary device model',modelWarning:'Only temporarily changes reported model when resetprop exists. It does not unlock FPS and resets after reboot; may affect some OEM apps.',flushDescription:'Request cached-process cleanup without killing system services or pretending that RAM increased.',trimDescription:'Request filesystem TRIM if supported.',moduleHint:'Check root modules for potential performance conflicts. No module will be deleted automatically.',scanNow:'Scan modules',cpuHint:'Read actual kernel policy and clock values. OEM thermals remain untouched.',advancedMode:'Custom auto-mode',backups:'Three backup slots',toolActions:'Service controls',applyNow:'Apply CPU',restart:'Restart monitor',pauseCpu:'Pause CPU manager',resetExtras:'Reset optional feature settings',logs:'Logs',diagnostics:'Diagnostics',thermalRead:'Thermal sensors',chooseGame:'Select an app',saveThresholds:'Save safeguards',scanGames:'Auto-detect installed games (experimental)',pingDns:'Test selected provider ping (ICMP only)'};
const arTitle={standby:'توفير الطاقة الذكي',gpu:'استوديو GPU',ramlab:'مختبر الذاكرة',iostudio:'إدارة التخزين',kernel:'مختبر النواة',process:'إدارة الخلفية والنظام',compat:'توافق الجهاز',profiles:'بروفايلات الأداء',sleep:'Deep Sleep Ultra',gaming:'Auto Gaming',renderer:'Render Engine',battery:'الطاقة والشحن',network:'Signal Boost',dns:'Private DNS',display:'الشاشة والهوية',memory:'Smart Flush',modules:'Module Detector',cpu:'CPU Studio',tools:'التشخيص والأدوات'};
const enTitle={standby:'Screen-off Intelligence',gpu:'GPU Studio',ramlab:'RAM Lab',iostudio:'I/O Studio',kernel:'Kernel Lab',process:'Process Manager',compat:'Device Compatibility',profiles:'Performance Profiles',sleep:'Deep Sleep Ultra',gaming:'Auto Gaming',renderer:'Graphics Engine',battery:'Battery & Charging',network:'Signal Boost',dns:'Private DNS',display:'Display & Identity',memory:'Smart Flush',modules:'Module Detector',cpu:'CPU Studio',tools:'Diagnostics & Tools'};
const profiles=[['extreme','⚡','الأقصى','Extreme'],['normal','⚖','المتوازن','Balanced'],['stability','◇','الثبات','Stability'],['quiet','☁','الاقتصادي','Quiet'],['ultra','☾','التوفير الشديد','Ultra Save']];
const txt=(ar,en)=>language==='ar'?ar:en;
function translate(area=document){area.querySelectorAll('[data-i]').forEach(el=>{if(!ORIGINALS.has(el))ORIGINALS.set(el,el.textContent);let key=el.dataset.i;el.textContent=language==='ar'?ORIGINALS.get(el):(EN[key]||ORIGINALS.get(el));});root.lang=language;root.dir=language==='ar'?'rtl':'ltr';$('langBtn').textContent=language==='ar'?'EN':'عربي';}
function toast(msg,error=false){const t=$('toast');t.textContent=msg;t.classList.toggle('error',error);t.classList.add('visible');clearTimeout(toastTimeout);toastTimeout=setTimeout(()=>t.classList.remove('visible'),5800);}
function call(command,timeout=40000){if(!hasBridge())return Promise.reject(new Error(txt('الواجهة غير متصلة بمدير Root. افتحها من KernelSU Next / Magisk.','Open this WebUI from KernelSU Next / Magisk.')));
 if(!/^[a-zA-Z0-9._ -]+$/.test(command))return Promise.reject(new Error('Invalid command characters'));
 return new Promise((resolve,reject)=>{const cb='AY7_'+Date.now()+'_'+Math.floor(Math.random()*100000);let ended=false;const timer=setTimeout(()=>done(new Error('Command timed out')),timeout);
 function done(err,result){if(ended)return;ended=true;clearTimeout(timer);delete window[cb];if(err)reject(err);else resolve(String(result||''));}
 window[cb]=(code,out,err)=>{const raw=String(out||'');if(Number(code)!==0||raw.startsWith('ERROR|'))done(new Error(raw.replace(/^ERROR\|/,'').trim()||err||'Root command rejected'));else done(null,raw);};
 try{
   const bridge=(window.ksu&&typeof window.ksu.exec==='function')?window.ksu:window.mmrl;
   const returned=bridge.exec(BASE+command,cb);
   // A few managers expose a Promise variant rather than a callback bridge.
   if(returned&&typeof returned.then==='function')returned.then(x=>{
     if(ended)return;
     if(typeof x==='string')done(null,x);
     else if(x&&typeof x==='object'&&(x.stdout!==undefined||x.out!==undefined)){
       const rc=Number(x.exitCode??x.code??0);
       const output=String(x.stdout??x.out??'');
       if(rc!==0||output.startsWith('ERROR|'))done(new Error(output||x.stderr||'Root action failed'));
       else done(null,output);
     }
   }).catch(e=>done(e));
 }catch(e){done(e);}
 });}
function parseStatus(raw){const o={policies:[],clocks:[],backups:[],available:[],features:{},logs:'',profile:'manual',deep:'off',mode:'off',screen:'UNKNOWN',monitor:'stopped',deepRadios:[],guard:[],deepAuto:['1','3600','0'],deepOptions:['1','1','1','1']};
 raw.split(/\r?\n/).forEach(line=>{const [key,...v]=line.split('|');switch(key){case 'PROFILE':o.profile=v[0];break;case 'DEEP':o.deep=v[0];break;case 'DEEP_QUEUE':o.deepQueue=v[0];break;case 'SCREEN_SAVE':o.screenSave=v;break;case 'DEEP_ERROR':o.deepError=v.join('|');break;case 'DEEP_WARNING':o.deepWarning=v.join('|');break;case 'DEEP_RADIOS':o.deepRadios=v;break;case 'DEEP_APPS':o.deepApps=v[0];break;case 'DEEP_SOURCE':o.deepSource=v[0];break;case 'DEEP_AUTO':o.deepAuto=v;break;case 'DEEP_OPTIONS':o.deepOptions=v;break;case 'MODE':o.mode=v[0];break;case 'MONITOR':o.monitor=v[0];break;case 'SCREEN':o.screen=v[0];break;case 'BATTERY':o.battery=v;break;case 'RAM':o.ram=v;break;case 'DEVICE':o.device=v;break;case 'AVAILABLE':o.available=(v[0]||'').split(',').filter(Boolean);break;case 'POLICY':o.policies.push(v);break;case 'CLOCK':o.clocks.push(v);break;case 'GUARD':o.guard=v;break;case 'ON':o.on=v[0];break;case 'OFF':o.off=v[0];break;case 'POLL':o.poll=v[0];break;case 'BACKUP':o.backups.push(v);break;case 'UI':o.ui=v;break;case 'EFFECTIVE':o.effective=v;break;case 'CONFLICT':o.conflicts=(o.conflicts||[]).concat(v);break;case 'SERVICE':o.service=v[0];break;case 'MODULE_DESCRIPTION':o.description=v.join('|');break;}});return o;}
function parseFeatures(raw){for(const line of raw.split(/\r?\n/)){const [k,name,...value]=line.split('|');if(k==='F')current.features[name]=value.join('|');}}
function formatSleep(s){const m={off:['غير مفعل','Inactive'],entering:['جاري الفصل','Disconnecting'],active:['الاتصالات مفصولة','Radios offline'],partial:['فصل جزئي','Partially offline'],restoring:['جاري الاستعادة','Restoring'],armed:['مجدول','Armed']};return txt(...(m[s]||[s||'—',s||'—']));}
function showOverview(){const k=current;const label=(profiles.find(p=>p[0]===k.profile)||[]);$('dashProfile').textContent=k.profile==='manual'?txt('يدوي / إيقاف','Manual / Paused'):txt(label[2]||k.profile,label[3]||k.profile);
 const observed=(k.policies||[]).map(p=>p[1]).filter(Boolean);$('dashGovernor').textContent=observed.length?([...new Set(observed)].join(' / ')):'—';$('dashBattery').textContent=k.battery&&k.battery[0]!=='unknown'?k.battery[0]+'%':'—';$('dashMonitor').textContent=k.monitor==='running'?txt('نشطة','Running'):txt('متوقفة','Stopped');
 const queued=k.deepQueue==='pending';const isOff=k.deep==='off';$('deepStateBadge').classList.toggle('active',!isOff);$('deepStateBadge').textContent=(queued?'◌ ':isOff?'● ':'☾ ')+(queued?txt('الطلب قيد الانتظار','Sleep requested'):formatSleep(k.deep));
 $('enterSleep').disabled=busy||queued||(!isOff&&k.deep!=='partial');$('enterSleep').textContent=isOff?txt('تفعيل النوم الآن ↗','ENTER DEEP SLEEP ↗'):txt('إعادة محاولة الفصل','Retry offline');$('leaveSleep').disabled=busy||(isOff&&!queued);
 $('deviceLine').textContent=k.device? k.device[0]+' · Android '+k.device[1]:'Eng / Ahmed Yasir';$('profileTileSub').textContent=(k.profile||'AUTO')+' · CPU';$('gameTileSub').textContent=(k.features.games||'0')+' '+txt('ألعاب','games');
 const sv=k.screenSave||['60','0','0'];
 const delayLabel=sv[0]==='off'?txt('التوفير معطل','Disabled'):sv[0]+'s';
 const timing=k.screen==='ON'?txt('الشاشة مفتوحة · بروفايلك نشط','Screen ON · profile active'):k.screen==='OFF'?(sv[2]==='1'?txt('توفير الطاقة نشط','Power saving active'):txt('الانتظار قبل التوفير','Waiting for power saving')):txt('حالة الشاشة غير مؤكدة','Screen state unknown');
 $('standbyLive').textContent=timing+' · '+delayLabel;
 if($('standbyTileSub'))$('standbyTileSub').textContent=delayLabel+' · '+txt('استعادة البروفايل عند الفتح','instant CPU restore');
}
async function refresh(silent=true){if(refreshing||busy)return;refreshing=true;try{const raw=await call('status');if(!raw.startsWith('OK|'))throw Error('Unexpected status');const oldFeatures=current.features||{};current=parseStatus(raw);current.features=oldFeatures;
 try{const features=await call('fusion-status');parseFeatures(features);}catch(e){if(!silent)toast(e.message,true);}
 if(current.ui&&current.ui[0]==='en'&&language!=='en'&&!window.AY_USER_SWITCH){language='en';translate();}if(current.ui&&current.ui[1]==='light'&&theme!=='light'&&!window.AY_USER_SWITCH){theme='light';root.dataset.theme=theme;}
 showOverview();if(active)hydrateSheet();if(!silent)toast(txt('تم تحديث البيانات الفعلية','Actual device state refreshed'));
 }catch(e){if(!silent)toast(e.message,true);$('dashMonitor').textContent=txt('غير متصل','Unavailable');}finally{refreshing=false;}}
async function action(command,success,confirmText,timeout){if(busy)return;if(confirmText&&!window.confirm(confirmText))return;busy=true;lockButtons(true);toast(txt('جارٍ تنفيذ الأمر على الهاتف…','Executing root command on device…'));
 try{const output=await call(command,timeout||(/deep-(now|retry|cancel)/.test(command)?180000:55000));if(!output.startsWith('OK|'))throw Error(output.trim()||'Invalid root response');toast(success||output.split('|').slice(1).join('|'));}
 catch(e){toast(txt('فشل التنفيذ: ','Action failed: ')+e.message,true);}
 finally{busy=false;lockButtons(false);await refresh(true);if(active){await loadLists(active);hydrateSheet();if(['gpu','ramlab','iostudio','kernel','compat'].includes(active))await loadStudio();if(active==='process')await loadProcess();}}
}
function lockButtons(v){document.querySelectorAll('button,select,input').forEach(el=>{if(el.id==='closeSheet'||el.id==='langBtn'||el.id==='themeBtn')return;el.disabled=v;});}
function openSheet(name){active=name;$('overlay').hidden=false;$('sheet').hidden=false;document.body.classList.add('sheet-open');$('sheetCategory').textContent='AY / LIGHTNING STUDIO 7';$('sheetTitle').textContent=language==='ar'?(arTitle[name]||name):(enTitle[name]||name);
 const source=$('tmpl-'+name);if(!source){toast('Unsupported panel',true);return;}
 $('sheetContent').replaceChildren(source.content.cloneNode(true));translate($('sheetContent'));hydrateSheet();loadLists(name);
 if(['gpu','ramlab','iostudio','kernel','compat'].includes(name))loadStudio();
 if(name==='process')loadProcess();}
function closeSheet(){active='';$('overlay').hidden=true;$('sheet').hidden=true;document.body.classList.remove('sheet-open');}
function hydrateSheet(){if(!active)return;const f=current.features||{},s=current;let node;
 if(active==='profiles') {node=$in('profileOptions');if(node){node.replaceChildren();profiles.forEach(p=>{const btn=document.createElement('button');btn.className='profilebtn'+(s.profile===p[0]?' selected':'');btn.dataset.profile=p[0];btn.innerHTML='<span class="profile-symbol">'+p[1]+'</span><b></b><small></small>';btn.querySelector('b').textContent=txt(p[2],p[3]);btn.querySelector('small').textContent=p[0]==='extreme'?'performance':p[0]==='quiet'?'conservative':p[0]==='ultra'?'powersave':'schedutil';btn.disabled=s.available&&s.available.length>0&&!s.available.includes(btn.querySelector('small').textContent);node.append(btn);});}}
 if(active==='sleep'){setText('sheetDeepState',formatSleep(s.deep));const off=s.deep==='off';if($in('sleepAuto'))$in('sleepAuto').checked=s.deepAuto?.[0]==='1';if($in('sleepStopApps'))$in('sleepStopApps').checked=s.deepOptions?.[3]==='1';const enter=$in('sheetSleepNow'),cancel=$in('sheetSleepCancel'),retry=$in('sheetSleepRetry');if(enter)enter.disabled=!off;if(cancel)cancel.disabled=off;if(retry)retry.disabled=s.deep!=='partial';const elapsed=Number(s.deepAuto?.[2]||0);setText('elapsedStatus',Math.floor(elapsed/60)+' / 60 '+txt('دقيقة','min'));setText('stoppedCount',s.deepApps||'0');setText('radioStatus',(s.deepRadios||[]).map((x,i)=>['Air','Wi-Fi','BT','NFC'][i]+':'+x).join(' · '));setText('sleepError',s.deepError||s.deepWarning||'');}
 if(active==='gaming'){$in('autoGame').checked=f.auto_game==='1';renderGames();}
 if(active==='renderer')renderRenders();
 if(active==='battery'){if($in('underclock'))$in('underclock').value=f.underclock||'stock';if($in('chargeLimit'))$in('chargeLimit').value=['500','1000','1500','2000'].includes(f.charge_ma)?f.charge_ma:'off';if($in('guardBattery'))$in('guardBattery').value=s.guard?.[0]||'off';if($in('guardTemp'))$in('guardTemp').value=s.guard?.[1]||'off';if($in('coreSaver'))$in('coreSaver').checked=f.core_saver==='1';}
 if(active==='network'){$in('netTune').checked=f.net_tune==='1';setText('netTcp',f.tcp||'—');setText('netDevice',s.device?.[0]||'—');}
 if(active==='dns'){renderDns();setText('dnsModeValue',f.dns_mode||'—');setText('dnsHostValue',f.dns_host||'—');}
 if(active==='cpu')renderPolicies();if(active==='tools')renderBackups();
 if(active==='standby'){
  const sv=s.screenSave||['60','0','0'];
  if($in('standbyDelay'))$in('standbyDelay').value=sv[0];
  setText('ssScreen',s.screen||'—');setText('ssElapsed',sv[1]+'s');
  setText('ssActive',sv[2]==='1'?txt('نعم','Yes'):txt('لا','No'));
 }
 if(active==='sleep'){
  const queued=s.deepQueue==='pending';
  setText('sleepOperation',queued?txt('◌ تم استلام الطلب · جاري تنفيذه بالخلفية','◌ REQUEST ACCEPTED · PROCESSING'):s.deep==='active'?txt('● الاتصالات مفصولة','● RADIOS OFFLINE'):s.deep==='partial'?txt('⚠ فصل جزئي · راجع الخطأ','⚠ PARTIAL · CHECK DETAILS'):'● READY');
  if($in('sheetSleepNow'))$in('sheetSleepNow').disabled=queued||s.deep!=='off';
  if($in('sheetSleepCancel'))$in('sheetSleepCancel').disabled=s.deep==='off'&&!queued;
 }

}
function setText(id,value){let el=$in(id);if(el)el.textContent=String(value);}
function rowInfo(main,small,buttonText,onClick){let row=document.createElement('div');row.className='listrow';let label=document.createElement('span');label.textContent=main;if(small){let sl=document.createElement('small');sl.textContent=small;label.append(sl);}row.append(label);if(buttonText){let b=document.createElement('button');b.textContent=buttonText;b.addEventListener('click',onClick);row.append(b);}return row;}
function renderGames(){const el=$in('gamesList');if(!el)return;el.replaceChildren();if(!(current.games||[]).length){el.append(rowInfo(txt('لا توجد ألعاب مسجلة','No registered games'),'','',()=>{}));return;}current.games.forEach(game=>{const row=rowInfo(appName(game),game,txt('حذف','Remove'),()=>action('fusion game-remove '+game,txt('حُذفت اللعبة','Game removed')));const icon=appIcon(game);if(icon)row.prepend(icon);el.append(row);});}
function renderRenders(){const el=$in('renderList');if(!el)return;el.replaceChildren();for(const item of current.render||[]){const [pkg,driver]=item.split('=');const row=rowInfo(appName(pkg),pkg+' · '+driver,txt('إلغاء','Reset'),()=>action('fusion render-set '+pkg+' default'));const icon=appIcon(pkg);if(icon)row.prepend(icon);el.append(row);}if(!el.children.length)el.append(rowInfo(txt('لا توجد إعدادات مخصصة','No custom render settings')));}
function renderDns(){const sel=$in('dnsProvider');if(!sel)return;if(sel.dataset.built){const host=current.features?.dns_host;sel.value=[...sel.options].some(o=>o.value===host)?host:(current.features?.dns_mode==='off'?'off':'auto');return;}sel.dataset.built='1';const defs=[['auto','Android Auto',null,'system'],['off','Disabled',null,'system']];for(const item of PROVIDERS)defs.push([item.host,item.name,item.ip,item.cat]);for(const [host,name,ip,cat] of defs){const opt=document.createElement('option');opt.value=host;opt.textContent=name+(ip?' · '+ip:'');sel.appendChild(opt);}const activeHost=current.features?.dns_host;sel.value=defs.some(d=>d[0]===activeHost)?activeHost:(current.features?.dns_mode==='off'?'off':'auto');}
function renderPolicies(){const area=$in('cpuPolicies');if(!area||area.children.length)return;area.replaceChildren();const allowed=current.available||[];['cpuOnGov','cpuOffGov'].forEach((id,i)=>{const el=$in(id);if(!el)return;el.replaceChildren();allowed.forEach(g=>{const op=document.createElement('option');op.value=g;op.textContent=g;el.append(op);});el.value=(i===0?current.on:current.off)||allowed[0];});if($in('cpuPoll'))$in('cpuPoll').value=current.poll||'3';
 for(const row of current.clocks||[]){const [policy,curmin,curmax,stockmin,stockmax,custommin,custommax,freqlist]=row;const div=document.createElement('div');div.className='box policy';const header=document.createElement('div');header.className='title';const h=document.createElement('h3');h.textContent=policy;const stat=document.createElement('small');stat.textContent='CURRENT '+curmin+' – '+curmax+' kHz';header.append(h,stat);div.append(header);const r=document.createElement('div');r.className='formrow';const choices=['stock',...(freqlist||'').split(',').filter(v=>/^\d+$/.test(v))];const selects=[];for(const selVal of [custommin,custommax]){const sel=document.createElement('select');choices.forEach(x=>{const op=document.createElement('option');op.value=x;op.textContent=x==='stock'?'STOCK':x+' kHz';sel.append(op);});if(!choices.includes(selVal)){let opt=document.createElement('option');opt.value=selVal;opt.textContent=selVal;sel.append(opt);}sel.value=selVal;selects.push(sel);r.append(sel);}div.append(r);const save=document.createElement('button');save.className='softbtn full';save.textContent=txt('حفظ تردد هذه المجموعة','Save policy frequencies');save.addEventListener('click',()=>action('set-freq '+policy+' '+selects[0].value+' '+selects[1].value));div.append(save);area.append(div);}
 if(!area.children.length)area.append(rowInfo(txt('لم يتم العثور على cpufreq policies','No CPU policy detected')));
}
function renderBackups(){const el=$in('backupList');if(!el)return;el.replaceChildren();for(let i=1;i<=3;i++){const slot=(current.backups||[]).find(x=>Number(x[0])===i)||[String(i),'empty','none'];const row=document.createElement('div');row.className='listrow';const label=document.createElement('span');label.textContent=txt('الخانة ','Slot ')+i;const small=document.createElement('small');small.textContent=slot[1]==='empty'?txt('فارغة','Empty'):slot[1]+' · '+slot[2];label.append(small);row.append(label);const controls=document.createElement('div');controls.className='buttonrow';const save=document.createElement('button');save.textContent=txt('حفظ','Save');save.addEventListener('click',()=>action('backup-save '+i));controls.append(save);if(slot[1]!=='empty'){const load=document.createElement('button');load.textContent=txt('استرجاع','Restore');load.addEventListener('click',()=>action('backup-restore '+i,'',txt('استعادة النسخة قد تغيّر إعدادات CPU. متابعة؟','Restore may change CPU settings. Continue?')));controls.append(load);}row.append(controls);el.append(row);}}
async function loadLists(which){if(!hasBridge())return;try{if(which==='gaming'||which==='renderer'){const raw=await call('fusion apps',100000);current.apps=raw.split(/\r?\n/).filter(x=>x.startsWith('APP|')).map(x=>x.slice(4));resolveNativeApps(current.apps);const list=which==='gaming'?$in('gamePackage'):$in('renderApp');if(list){list.replaceChildren();current.apps.forEach(pkg=>{const opt=document.createElement('option');opt.value=pkg;opt.textContent=appName(pkg)+' · '+pkg;list.append(opt);});}if(which==='gaming'){const games=await call('fusion games');current.games=games.split(/\r?\n/).filter(x=>x.startsWith('GAME|')).map(x=>x.slice(5));renderGames();}else{const render=await call('fusion render-list');current.render=render.split(/\r?\n/).filter(x=>x.startsWith('RENDER|')).map(x=>x.slice(7));renderRenders();}}
 if(which==='modules')await fetchModules();}
 catch(e){toast(e.message,true);}}
async function fetchModules(){const area=$in('modulesList');if(!area)return;area.replaceChildren();try{const raw=await call('fusion modules');const rows=raw.split(/\r?\n/).filter(x=>x.startsWith('MODULE|'));if(!rows.length){area.append(rowInfo(txt('لا توجد موديولات أخرى','No other active modules')));return;}rows.forEach(row=>{const [_,id,risk,enabled,name]=row.split('|');area.append(rowInfo(name||id,risk==='possible'?txt('تعارض محتمل','Possible overlap'):txt('غير محدد','Unknown'),enabled==='1'?txt('تعطيل','Disable'):txt('تفعيل','Enable'),()=>action('fusion module-toggle '+id+' '+(enabled==='1'?'0':'1'),'',txt('يتطلب تغيير الموديول إعادة التشغيل، وقد يتعطل نظامك إن كان أساسيًا. متابعة؟','Changing other modules can cause boot problems and needs reboot. Continue?'))));});}catch(e){area.append(rowInfo(e.message));}}
async function pollRequestedSleep(){
 if(sleepPolling)return;
 sleepPolling=true;
 try{
  for(let i=0;i<36;i++){
   await new Promise(resolve=>setTimeout(resolve,1300));
   if(!hasBridge())break;
   await refresh(true);
   if(current.deep==='active'){
     toast(txt('تأكد فصل الاتصالات. بروفايلك يعود عند الاستيقاظ فقط.','Deep Sleep confirmed; selected CPU profile restores on wake.'));break;
   }
   if(current.deep==='partial'){
     toast(txt('تم الفصل جزئيًا. راجع التحذيرات وأعد المحاولة.','Partial disconnection; check diagnostics and retry.'),true);break;
   }
   if(current.deepQueue!=='pending'&&i>4){
     toast(txt('لم يكتمل طلب النوم؛ افتح التشخيص أو جرّب Action.','Sleep request not completed; check diagnostics or try Action.'),true);break;
   }
  }
 }finally{sleepPolling=false;}
}
const STUDIO_NAMES={gpu_governor:['GPU Governor','سياسة GPU'],gpu_min:['GPU Minimum Clock','الحد الأدنى لـGPU'],gpu_max:['GPU Maximum Clock','الحد الأعلى لـGPU'],swappiness:['Swappiness','تبديل الذاكرة'],cache_pressure:['VFS Cache Pressure','ضغط كاش الملفات'],page_cluster:['Swap Page Cluster','صفحات Swap'],dirty_ratio:['Dirty Ratio','نسبة الذاكرة غير المكتوبة'],dirty_background:['Dirty Background','نسبة خلفية الكتابة'],watermark:['Watermark Scale','عتبة ذاكرة النواة'],io_scheduler:['I/O Scheduler','جدولة I/O'],io_readahead:['Storage Read-Ahead','قراءة التخزين المسبقة'],sched_autogroup:['Scheduler Autogroup','تجميع مهام المجدول'],tcp_ecn:['TCP ECN','إدارة ازدحام TCP'],dt2w:['Double Tap to Wake','النقر المزدوج للإيقاظ']};
const STUDIO_GROUPS={gpu:['gpu_governor','gpu_min','gpu_max'],ramlab:['swappiness','cache_pressure','page_cluster','dirty_ratio','dirty_background','watermark'],iostudio:['io_scheduler','io_readahead'],kernel:['sched_autogroup','tcp_ecn','dt2w']};
function studioText(key){return txt((STUDIO_NAMES[key]||[key,key])[1],(STUDIO_NAMES[key]||[key,key])[0]);}
function createMetric(k,v){const wrap=document.createElement('div');wrap.className='metric-card';const name=document.createElement('small');name.textContent=k.replaceAll('_',' ').replace(':','');const value=document.createElement('b');value.textContent=v;wrap.append(name,value);return wrap;}
function renderStudio(){
 if(!active)return;
 const metrics=$in('studioMetrics');
 if(metrics){metrics.replaceChildren();for(const [name,value] of studioState.metrics)metrics.append(createMetric(name,value));}
 const sup=$in('studioSupport');if(sup){sup.replaceChildren();for(const obj of studioState.knobs){const div=document.createElement('div');div.className='cap-row';const label=document.createElement('span');label.textContent=studioText(obj.key);const status=document.createElement('b');status.className=obj.supported==='1'?'cap-yes':'cap-no';status.textContent=obj.supported==='1'?txt('مدعوم','Supported'):txt('غير مدعوم','Unsupported');div.append(label,status);sup.append(div);}}
 const where=$in('studioKnobs');if(!where)return;where.replaceChildren();
 const keys=STUDIO_GROUPS[active]||[];
 for(const key of keys){const knob=studioState.knobs.find(r=>r.key===key)||{key,supported:'0',value:'unknown',options:'',unit:'-'};const box=document.createElement('div');box.className='box studio-box';
  const head=document.createElement('div');head.className='studio-heading';const title=document.createElement('h3');title.textContent=studioText(key);const chip=document.createElement('span');chip.className='cap-chip '+(knob.supported==='1'?'cap-ok':'cap-missing');chip.textContent=knob.supported==='1'?txt('متاح','SUPPORTED'):txt('غير مدعوم','UNSUPPORTED');head.append(title,chip);box.append(head);
  const reading=document.createElement('p');reading.className='kernel-read';reading.textContent=txt('القيمة الحالية: ','Current value: ')+knob.value+' · '+(knob.unit||'-');box.append(reading);
  if(knob.supported==='1'){
   const select=document.createElement('select');select.id='studioVal_'+key;select.setAttribute('aria-label',studioText(key));
   let opts=[];if(['swappiness','cache_pressure','page_cluster','dirty_ratio','dirty_background','watermark'].includes(key)){
    const pools={swappiness:['0','20','40','60','80','100','120','140','160','180','200'],cache_pressure:['20','50','75','100','125','150','175','200'],page_cluster:['0','1','2','3'],dirty_ratio:['5','10','15','20','25','30'],dirty_background:['2','3','5','8','10','12','15'],watermark:['10','25','40','60','80','100','150','200']};opts=pools[key];
   }else opts=(knob.options||'').split(/\s+/).filter(x=>/^[a-zA-Z0-9_.+-]+$/.test(x));
   if(/^[0-9]+$/.test(knob.value)&&!opts.includes(knob.value))opts.unshift(knob.value);
   if(!opts.includes(knob.value)&&!/\[/.test(knob.value))opts.unshift(knob.value);
   for(const val of [...new Set(opts)]){const option=document.createElement('option');option.value=val;option.textContent=val+(knob.unit==='hz'?' Hz':knob.unit==='kb'?' KB':'');select.append(option);}select.value=knob.value;box.append(select);
   const actions=document.createElement('div');actions.className='buttonrow';const apply=document.createElement('button');apply.className='solidbtn';apply.dataset.studioSave=key;apply.textContent=txt('تطبيق وفحص','Apply & verify');const reset=document.createElement('button');reset.className='softbtn';reset.dataset.studioReset=key;reset.textContent=txt('استرجاع الأصل','Restore stock');actions.append(apply,reset);box.append(actions);
  }else{const explain=document.createElement('p');explain.className='footnote';explain.textContent=txt('النواة لا تعرض مسارًا قابلًا للكتابة لهذه الخاصية. لن تُفرض قيمة وهمية.','No writable kernel control is exposed here; nothing will be forced.');box.append(explain);}
  where.append(box);
 }
}
async function loadStudio(){if(!hasBridge())return;try{
 const raw=await call('studio list',50000);
 const knobs=[],metrics=[];
 for(const line of raw.split(/\r?\n/)){
 const v=line.split('|');
 if(v[0]==='KNOB')knobs.push({key:v[1],supported:v[2],value:v[3],desired:v[4],options:v[5]||'',unit:v[6]||''});
 if(v[0]==='METRIC')metrics.push([v[1],v.slice(2).join('|')]);
 }
 studioState={knobs,metrics};renderStudio();
 }catch(e){toast(e.message,true);}
}
async function loadProcess(){if(!hasBridge()||active!=='process')return;
 try{
  const pkgs=await call('fusion apps',100000);const apps=pkgs.split(/\r?\n/).filter(v=>v.startsWith('APP|')).map(v=>v.substring(4));
  resolveNativeApps(apps);const sel=$in('processPackage');if(sel){sel.replaceChildren();for(const pkg of apps){const op=document.createElement('option');op.value=pkg;op.textContent=appName(pkg)+' · '+pkg;sel.append(op);}}
  const anim=await call('studio animation-status');const node=$in('animationStatus');if(node){node.replaceChildren();for(const line of anim.split(/\r?\n/)){const v=line.split('|');if(v[0]==='ANIM')node.append(createMetric(v[1],v[2]+'×'));}}
  const ble=await call('studio ble-status');setText('bleState',ble.replace('BLE|',txt('قيمة فحص BLE الحالية: ','BLE scan global setting: ')));
 }catch(e){toast(e.message,true);}
}
async function engageSleep(){if(busy)return;let s=current.deep;if(s!=='off'&&s!=='partial')return;const msg=txt('سيتم قطع جميع الاتصالات وإيقاف تطبيقات المستخدم غير المحمية. قد تفقد عملاً غير محفوظ ولن تصلك مكالمات. هل تتابع؟','Radios will disconnect and unprotected third-party apps will be force-stopped. Unsaved work and calls may be lost. Continue?');if(!window.confirm(msg))return;
 if(s==='partial')return void action('deep-retry');
 await action('deep-request',txt('تم إرسال الطلب إلى المراقب؛ جارٍ فصل الشبكات','Request queued; daemon is disconnecting radios'),undefined,12000);
 if(current.deepQueue==='pending'||current.deep==='entering'||current.deep==='off')void pollRequestedSleep();
}
async function switchLanguage(){language=language==='ar'?'en':'ar';window.AY_USER_SWITCH=true;translate();if(active){$('sheetTitle').textContent=language==='ar'?arTitle[active]:enTitle[active];hydrateSheet();}showOverview();if(hasBridge()){try{const raw=await call('set-ui '+language+' '+theme);if(!raw.startsWith('OK|'))throw Error(raw);}catch(e){toast(e.message,true);}}}
async function switchTheme(){theme=theme==='dark'?'light':'dark';root.dataset.theme=theme;window.AY_USER_SWITCH=true;if(hasBridge()){try{await call('set-ui '+language+' '+theme);}catch(e){toast(e.message,true);}}}
$('refreshBtn').addEventListener('click',()=>refresh(false));$('langBtn').addEventListener('click',switchLanguage);$('themeBtn').addEventListener('click',switchTheme);
$('enterSleep').addEventListener('click',engageSleep);document.querySelectorAll('[data-go]').forEach(x=>x.addEventListener('click',()=>openSheet(x.dataset.go)));$('leaveSleep').addEventListener('click',()=>action('deep-cancel',txt('استُعيدت الاتصالات التي كانت مفعلة قبل النوم','Saved radio states restored'),txt('إلغاء النوم واستعادة الاتصالات؟','Exit sleep and restore connections?'),180000));
document.querySelectorAll('.tile[data-sheet]').forEach(b=>b.addEventListener('click',()=>openSheet(b.dataset.sheet)));
function applyFilters(){const word=($('quickSearch')?.value||'').trim().toLowerCase();document.querySelectorAll('.tile').forEach(el=>{
 const category=lastPage==='all'||el.dataset.category===lastPage;
 const match=!word||el.textContent.toLowerCase().includes(word)||String(el.dataset.sheet).includes(word);
 el.hidden=!(category&&match);
 });}
 document.querySelectorAll('.filter').forEach(b=>b.addEventListener('click',()=>{lastPage=b.dataset.filter;document.querySelectorAll('.filter').forEach(a=>a.classList.toggle('active',a===b));applyFilters();}));
 if($('quickSearch'))$('quickSearch').addEventListener('input',applyFilters);
$('overlay').addEventListener('click',closeSheet);$('closeSheet').addEventListener('click',closeSheet);document.addEventListener('keydown',e=>{if(e.key==='Escape'&&active)closeSheet();});
$('sheetContent').addEventListener('click',e=>{const tgt=e.target.closest('button');if(!tgt||busy)return;
 if(tgt.dataset.studioSave){const name=tgt.dataset.studioSave;const select=$in('studioVal_'+name);if(!select)return;
   return void action('studio set '+name+' '+select.value,txt('تم التحقق من كتابة القيمة','Value written and verified'));}
 if(tgt.dataset.studioReset)return void action('studio reset '+tgt.dataset.studioReset,'',txt('استعادة القيمة الأصلية المحفوظة؟','Restore saved stock value?'));
 if(tgt.dataset.profile)return void action('set-profile '+tgt.dataset.profile,txt('تم تطبيق البروفايل المحدد','Selected profile applied'));
 if(tgt.dataset.cmd){const confirmText=/fusion resolution (540|720)/.test(tgt.dataset.cmd)?txt('هل تريد تغيير دقة الشاشة؟','Change the current display resolution?'):null;return void action(tgt.dataset.cmd,'',confirmText);}
 switch(tgt.id){
  case 'saveStandby':return void action('screen-delay '+$in('standbyDelay').value,txt('حُفظت مدة التوفير','Screen-off delay saved'));
  case 'studioResetAll':return void action('studio reset-all','',txt('هل تريد استعادة جميع إعدادات Studio إلى قيمها الأصلية المحفوظة؟','Restore all saved Studio settings?'));
  case 'setAppBucket':return void action('studio app-bucket '+$in('processPackage').value+' '+$in('processBucket').value,'',txt('قد تتأخر إشعارات التطبيق. متابعة؟','App notifications may be delayed. Continue?'));
  case 'saveAnimation':return void action('studio animation '+$in('animationKey').value+' '+$in('animationValue').value);
  case 'resetAnimation':return void action('studio animation-reset '+$in('animationKey').value);
  case 'sheetSleepNow':return void engageSleep();
  case 'sheetSleepCancel':return void action('deep-cancel','',txt('استعادة الاتصالات المحفوظة؟','Restore saved radios?'),180000);
  case 'sheetSleepRetry':return void action('deep-retry');
  case 'saveSleepOptions':return void(async()=>{if(current.deep!=='off')return toast(txt('ألغِ النوم قبل تغيير الخيارات','Cancel Deep Sleep before changing settings'),true);const kill=$in('sleepStopApps').checked?'1':'0';const auto=$in('sleepAuto').checked?'1':'0';busy=true;lockButtons(true);try{await call('deep-options 1 1 1 '+kill);await call('deep-auto '+auto);toast(txt('حُفظت خيارات النوم','Sleep preferences saved'));}catch(err){toast(err.message,true);}finally{busy=false;lockButtons(false);await refresh(true);}})();
  case 'addGame':return void action('fusion game-add '+$in('gamePackage').value);
  case 'scanGames':return void action('fusion game-scan','',txt('فحص قائمة تطبيقات المستخدم بحثًا عن ألعاب (قد يطول حسب الجهاز). متابعة؟','Scan installed apps for Android game categories? May take a while.'),180000);
  case 'saveRender':return void action('fusion render-set '+$in('renderApp').value+' '+$in('renderChoice').value);
  case 'saveCharge':return void action('fusion charge '+$in('chargeLimit').value,'',txt('هذا يحد تيار الشحن على مسار يدعمه الجهاز. متابعة؟','Apply a lower kernel charging-current cap if supported?'));
  case 'saveUnderclock':return void action('fusion underclock '+$in('underclock').value);
  case 'saveGuard':return void action('set-guard '+$in('guardBattery').value+' '+$in('guardTemp').value);
  case 'refreshSignal':return void action('fusion net-refresh','',txt('سيُقطع الاتصال الخلوي لفترة قصيرة. متابعة؟','Cellular service will disconnect briefly. Continue?'),75000);
  case 'saveDns':return void action('fusion dns '+$in('dnsProvider').value);
  case 'pingDns':{const host=$in('dnsProvider').value;const server=PROVIDERS.find(p=>p.host===host);if(!server||!server.ip)return void toast(txt('اختر مزودًا بقيمة IP معروفة','Choose a provider with a known IP'),true);
   return void(async()=>{try{const result=await call('fusion dns-ping '+server.ip,12000);setText('dnsProbeResult',result.replace(/^OK\|/,''));}catch(e){toast(e.message,true);}})();}
  case 'applyCustomDns':{const host=$in('dnsCustom').value.trim();if(!/^[a-z0-9.-]+$/i.test(host)||!host.includes('.'))return toast(txt('اسم DNS غير صالح','Invalid DNS hostname'),true);return void action('fusion dns '+host);}
  case 'saveSpoof':return void action('fusion spoof '+$in('spoofModel').value,'',txt('هذه ميزة تجريبية قد تُربك بعض التطبيقات، ولن تتجاوز الحماية أو تضمن FPS. متابعة؟','Experimental: some apps may misidentify the device; does not unlock FPS. Continue?'));
  case 'scanModules':return void fetchModules();
  case 'saveAutoGov':return void action('set-auto '+$in('cpuOnGov').value+' '+$in('cpuOffGov').value+' '+$in('cpuPoll').value);
  case 'resetExtras':return void action('fusion reset-fusion','',txt('ستُعاد إعدادات Fusion الافتراضية، مع إبقاء بروفايل CPU. متابعة؟','Reset optional Fusion features, retain selected CPU profile?'));
  case 'loadLogs':case 'loadDiagnostics':case 'loadThermal':return void(async()=>{try{const query=tgt.id==='loadLogs'?'logs':tgt.id==='loadThermal'?'fusion thermal':'status';$in('consoleOutput').textContent=await call(query,60000);}catch(err){$in('consoleOutput').textContent=err.message;}})();
 }
});
$('sheetContent').addEventListener('change',e=>{const el=e.target;if(busy)return;if(el.id==='autoGame')action('fusion feature auto_game '+(el.checked?'1':'0'));if(el.id==='coreSaver')action('fusion feature core_saver '+(el.checked?'1':'0'));if(el.id==='netTune')action('fusion net-tune '+(el.checked?'1':'0'));});
if(!hasBridge()){toast(txt('وضع المعاينة فقط: افتح الواجهة من مدير الروت لتفعيل الأزرار','Preview only: launch WebUI from your root manager to control the device.'),true);$('dashMonitor').textContent=txt('معاينة','Preview');}else{refresh(true);document.addEventListener('visibilitychange',()=>{if(!document.hidden&&!busy)refresh(true);});setInterval(()=>{if(!document.hidden&&!busy)refresh(true);},20000);}
translate();
// Provider catalogue included offline; no runtime CDN or other network dependency.
const PROVIDERS=[{"name":"Cloudflare (1.1.1.1)","host":"one.one.one.one","ip":"1.1.1.1","cat":"speed"},{"name":"Google Public DNS","host":"dns.google","ip":"8.8.8.8","cat":"speed"},{"name":"DNS.SB (Ultra Fast)","host":"dot.sb","ip":"185.222.222.222","cat":"speed"},{"name":"Control D Standard","host":"p0.freedns.controld.com","ip":"76.76.2.0","cat":"speed"},{"name":"OpenDNS / Cisco","host":"dns.opendns.com","ip":"208.67.222.222","cat":"speed"},{"name":"Quad9 Uncensored","host":"dns9.quad9.net","ip":"9.9.9.10","cat":"speed"},{"name":"G-Core Anycast","host":"ns1.gcorelabs.net","ip":"95.85.95.85","cat":"speed"},{"name":"AliDNS (Asia Fast)","host":"dns.alidns.com","ip":"223.5.5.5","cat":"speed"},{"name":"DNSPod (Tencent)","host":"dot.pub","ip":"119.29.29.29","cat":"speed"},{"name":"AdGuard Non-Filtering","host":"unfiltered.adguard-dns.com","ip":"94.140.14.140","cat":"speed"},{"name":"AdGuard Default (Ads)","host":"dns.adguard-dns.com","ip":"94.140.14.14","cat":"adblock"},{"name":"Mullvad AdBlock","host":"adblock.dns.mullvad.net","ip":"194.242.2.3","cat":"adblock"},{"name":"Mullvad Base Ads+Track","host":"base.dns.mullvad.net","ip":"194.242.2.4","cat":"adblock"},{"name":"Mullvad Extended (All)","host":"extended.dns.mullvad.net","ip":"194.242.2.5","cat":"adblock"},{"name":"Control D Ads & Tracker","host":"p2.freedns.controld.com","ip":"76.76.2.2","cat":"adblock"},{"name":"NextDNS AdGuard Engine","host":"dns.nextdns.io","ip":"45.90.28.0","cat":"adblock"},{"name":"RethinkDNS Block & Safe","host":"max.rethinkdns.com","ip":"104.21.36.177","cat":"adblock"},{"name":"LibreDNS NoAds","host":"noads.libredns.gr","ip":"116.202.176.26","cat":"adblock"},{"name":"AhaDNS Blitz Adblock","host":"dot.nl.ahadns.net","ip":"5.2.75.143","cat":"adblock"},{"name":"BlahDNS AdBlocker","host":"dot-jp.blahdns.com","ip":"45.32.55.120","cat":"adblock"},{"name":"Quad9 Security (Malware)","host":"dns.quad9.net","ip":"9.9.9.9","cat":"security"},{"name":"Cloudflare 1.1.1.2 Safe","host":"security.cloudflare-dns.com","ip":"1.1.1.2","cat":"security"},{"name":"CleanBrowsing Security","host":"security-filter-dns.cleanbrowsing.org","ip":"185.228.168.9","cat":"security"},{"name":"Control D Anti-Phishing","host":"p1.freedns.controld.com","ip":"76.76.2.1","cat":"security"},{"name":"Comodo Secure DNS","host":"dns.comodo.com","ip":"8.26.56.26","cat":"security"},{"name":"SafeDNS Protect","host":"dot.safedns.com","ip":"195.46.39.39","cat":"security"},{"name":"CIRA Shield Security","host":"private.canadianshield.cira.ca","ip":"149.112.166.2","cat":"security"},{"name":"Cloudflare 1.1.1.3 Family","host":"family.cloudflare-dns.com","ip":"1.1.1.3","cat":"family"},{"name":"AdGuard Family Protection","host":"family.adguard-dns.com","ip":"94.140.14.15","cat":"family"},{"name":"CleanBrowsing Family","host":"family-filter-dns.cleanbrowsing.org","ip":"185.228.168.168","cat":"family"},{"name":"CleanBrowsing Adult Guard","host":"adult-filter-dns.cleanbrowsing.org","ip":"185.228.168.10","cat":"family"},{"name":"Control D Family Safe","host":"p3.freedns.controld.com","ip":"76.76.2.3","cat":"family"},{"name":"OpenDNS FamilyShield","host":"familyshield.opendns.com","ip":"208.67.222.123","cat":"family"},{"name":"Mullvad No-Log Privacy","host":"dns.mullvad.net","ip":"194.242.2.2","cat":"privacy"},{"name":"Applied Privacy (Austria)","host":"dot1.applied-privacy.net","ip":"146.255.56.98","cat":"privacy"},{"name":"DNSForge (Germany NoLog)","host":"dnsforge.de","ip":"176.9.93.198","cat":"privacy"},{"name":"FFDN (France Zero-Log)","host":"ns0.fdn.fr","ip":"80.67.169.12","cat":"privacy"},{"name":"Digitale Gesellschaft CH","host":"dns.digitale-gesellschaft.ch","ip":"185.95.218.42","cat":"privacy"},{"name":"SWITCH DNS (Swiss)","host":"dns.switch.ch","ip":"130.59.31.251","cat":"privacy"}];
})();
