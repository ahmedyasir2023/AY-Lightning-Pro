#!/system/bin/sh
# AY KILL APP v7: capability-driven, reversible kernel controls.
# No thermal bypass, SELinux disable, CPU watchdog modifications, or arbitrary sysfs paths.
MODDIR=${YASIR_MODDIR:-${0%/*}}
AY_DATA_DIR=${AY_DATA_DIR:-/data/adb/ay_lightning}
ST="$AY_DATA_DIR/studio"
SYSROOT=${AY_STUDIO_SYSROOT:-/sys}
PROCROOT=${AY_STUDIO_PROCROOT:-/proc}
BOOT_ID=${YASIR_BOOT_ID:-/proc/sys/kernel/random/boot_id}
ERR=
st_fail(){ printf 'ERROR|%s\n' "$1"; exit 2; }
st_ok(){ printf 'OK|%s\n' "$1"; }
st_safe(){ case "$1" in ''|*[!a-zA-Z0-9_.,:/@+-]*) return 1;; esac; }
st_number(){ case "$1" in ''|*[!0-9]*) return 1 ;; esac; }
st_read(){ sed -n '1p' "$1" 2>/dev/null | sed 's/[[:space:]]*$//' | tr '|' '/'; }
st_gpu_dir(){
    GPU_DIR=
    for d in "$SYSROOT/class/kgsl/kgsl-3d0/devfreq" "$SYSROOT"/class/devfreq/*gpu* "$SYSROOT"/class/devfreq/*mali* "$SYSROOT"/class/devfreq/*3d*; do
        [ -d "$d" ] || continue
        [ -r "$d/governor" ] || [ -r "$d/cur_freq" ] || continue
        GPU_DIR=$d; return 0
    done
    return 1
}
st_disk_dir(){
    DISK_DIR=
    for d in "$SYSROOT"/block/sd[a-z] "$SYSROOT"/block/mmcblk[0-9] "$SYSROOT"/block/nvme[0-9]n[0-9] "$SYSROOT"/block/ufs*; do
        [ -d "$d" ] && [ -r "$d/queue/scheduler" ] && { DISK_DIR=$d; return 0; }
    done
    return 1
}
st_path(){
    NODE=; CHOICES=; LIMIT=; UNIT=
    case "$1" in
        gpu_governor)
            st_gpu_dir || return 1
            NODE="$GPU_DIR/governor"
            CHOICES=$(cat "$GPU_DIR/available_governors" 2>/dev/null)
            # A few KGSL drivers publish governors under the shared device.
            [ -n "$CHOICES" ] || CHOICES=$(cat "$GPU_DIR/../available_governors" 2>/dev/null)
            [ -n "$CHOICES" ] || return 1
            UNIT=enum ;;
        gpu_min|gpu_max)
            st_gpu_dir || return 1
            case "$1" in gpu_min) NODE="$GPU_DIR/min_freq" ;; gpu_max) NODE="$GPU_DIR/max_freq" ;; esac
            CHOICES=$(cat "$GPU_DIR/available_frequencies" 2>/dev/null)
            [ -n "$CHOICES" ] || CHOICES=$(cat "$GPU_DIR/../gpu_available_frequencies" 2>/dev/null)
            [ -n "$CHOICES" ] || return 1
            UNIT=hz ;;
        swappiness) NODE="$PROCROOT/sys/vm/swappiness"; LIMIT='0 200'; UNIT=percent ;;
        cache_pressure) NODE="$PROCROOT/sys/vm/vfs_cache_pressure"; LIMIT='20 200'; UNIT=percent ;;
        page_cluster) NODE="$PROCROOT/sys/vm/page-cluster"; LIMIT='0 3'; UNIT=pages ;;
        dirty_ratio) NODE="$PROCROOT/sys/vm/dirty_ratio"; LIMIT='5 30'; UNIT=percent ;;
        dirty_background) NODE="$PROCROOT/sys/vm/dirty_background_ratio"; LIMIT='2 15'; UNIT=percent ;;
        watermark) NODE="$PROCROOT/sys/vm/watermark_scale_factor"; LIMIT='10 200'; UNIT=ratio ;;
        io_scheduler)
            st_disk_dir || return 1
            NODE="$DISK_DIR/queue/scheduler"
            CHOICES=$(cat "$NODE" 2>/dev/null | tr '[]' '  ')
            UNIT=enum ;;
        io_readahead)
            st_disk_dir || return 1
            NODE="$DISK_DIR/queue/read_ahead_kb"
            CHOICES='128 256 512 1024'
            UNIT=kb ;;
        sched_autogroup) NODE="$PROCROOT/sys/kernel/sched_autogroup_enabled"; CHOICES='0 1'; UNIT=toggle ;;
        dt2w)
            for testnode in "$SYSROOT/touchpanel/double_tap" "$PROCROOT/touchpanel/double_tap_enable" "$SYSROOT/class/touch/touch_dev/doubletap2wake" "$SYSROOT/android_touch/doubletap2wake"; do
                [ -r "$testnode" ] && { NODE=$testnode; break; }
            done
            [ -n "$NODE" ] || return 1
            CHOICES='0 1'; UNIT=toggle ;;
        tcp_ecn) NODE="$PROCROOT/sys/net/ipv4/tcp_ecn"; CHOICES='0 1 2'; UNIT=enum ;;
        *) return 1 ;;
    esac
    [ -r "$NODE" ] || return 1
}
st_validate_value(){
    VAL=$1
    st_safe "$VAL" || return 1
    if [ -n "$LIMIT" ]; then
        st_number "$VAL" || return 1
        low=${LIMIT%% *}; high=${LIMIT#* }
        [ "$VAL" -ge "$low" ] && [ "$VAL" -le "$high" ] || return 1
    else
        case " $CHOICES " in *" $VAL "*) : ;; *) return 1 ;; esac
    fi
    return 0
}
st_boot_check(){
    mkdir -p "$ST/original" "$ST/desired" || return 1
    chmod 700 "$ST" "$ST/original" "$ST/desired" 2>/dev/null || :
    old=$(cat "$ST/current_boot" 2>/dev/null)
    now=$(cat "$BOOT_ID" 2>/dev/null)
    if [ "$old" != "$now" ]; then
        rm -f "$ST/original/"* 2>/dev/null || :
        printf '%s\n' "$now" > "$ST/current_boot" || return 1
    fi
}
st_apply(){
    key=$1; value=$2
    st_path "$key" || st_fail "Unsupported control: $key"
    [ -w "$NODE" ] || st_fail "Read-only kernel path: $key"
    st_validate_value "$value" || st_fail "Value rejected or not advertised by kernel: $key=$value"
    st_boot_check || st_fail 'Cannot prepare backups'
    current=$(st_read "$NODE")
    # GPU cap must never exceed original OEM max; changes to min must stay <= current max.
    if [ "$key" = gpu_max ]; then
        base=$(cat "$ST/original/gpu_max" 2>/dev/null || printf '%s' "$current")
        st_number "$base" && [ "$value" -le "$base" ] || st_fail 'GPU maximum above stock limit is prohibited'
    fi
    case "$key" in
        gpu_min)
            current_max=$(st_read "$GPU_DIR/max_freq")
            st_number "$current_max" && [ "$value" -le "$current_max" ] || st_fail 'GPU min exceeds current max' ;;
        dirty_background)
            current_dr=$(st_read "$PROCROOT/sys/vm/dirty_ratio")
            st_number "$current_dr" && [ "$value" -lt "$current_dr" ] || st_fail 'Background dirty ratio must be below dirty ratio' ;;
        dirty_ratio)
            current_db=$(st_read "$PROCROOT/sys/vm/dirty_background_ratio")
            st_number "$current_db" && [ "$value" -gt "$current_db" ] || st_fail 'Dirty ratio must exceed background ratio' ;;
    esac
    [ -f "$ST/original/$key" ] || printf '%s\n' "$current" > "$ST/original/$key"
    # Write original sysfs enum without the [selected] indicators.
    printf '%s\n' "$value" > "$NODE" 2>/dev/null || st_fail "Kernel refused write: $key"
    actual=$(st_read "$NODE")
    if [ "$key" = io_scheduler ]; then actual=$(printf '%s\n' "$actual" | sed -n 's/.*\[\([^]]*\)\].*/\1/p'); [ -n "$actual" ] || actual=$(st_read "$NODE"); fi
    if [ "$actual" != "$value" ]; then
        printf '%s\n' "$current" > "$NODE" 2>/dev/null || :
        st_fail "Kernel returned $actual instead of $value ($key)"
    fi
    printf '%s\n' "$value" > "$ST/desired/$key" || st_fail 'Cannot persist setting'
    st_ok "$key=$value verified; OEM thermal policy untouched"
}
st_reset(){
    key=$1
    st_path "$key" || st_fail "Control unsupported: $key"
    [ -r "$ST/original/$key" ] || { rm -f "$ST/desired/$key"; st_ok "$key already stock"; return 0; }
    [ -w "$NODE" ] || st_fail "Cannot restore read-only $key"
    old=$(cat "$ST/original/$key" 2>/dev/null)
    if [ "$key" = io_scheduler ]; then old_parsed=$(printf '%s\n' "$old" | sed -n 's/.*\[\([^]]*\)\].*/\1/p'); [ -n "$old_parsed" ] && old=$old_parsed; fi
    st_safe "$old" || st_fail "Invalid original snapshot: $key"
    if [ -n "$LIMIT" ]; then
        st_number "$old" || st_fail "Invalid saved numeric value: $key"
    else
        case " $CHOICES " in *" $old "*) : ;; *) st_fail "Original value not in supported options: $key" ;; esac
    fi
    printf '%s\n' "$old" > "$NODE" 2>/dev/null || st_fail "Kernel refused restore $key"
    rm -f "$ST/original/$key" "$ST/desired/$key"
    st_ok "$key restored"
}
st_list(){
    st_boot_check || return 1
    for key in gpu_governor gpu_min gpu_max swappiness cache_pressure page_cluster dirty_ratio dirty_background watermark io_scheduler io_readahead sched_autogroup dt2w tcp_ecn; do
        if st_path "$key"; then
            curr=$(st_read "$NODE")
            if [ "$key" = io_scheduler ]; then curr=$(printf '%s\n' "$curr" | sed -n 's/.*\[\([^]]*\)\].*/\1/p'); [ -n "$curr" ] || curr=$(st_read "$NODE"); fi
            opts=${CHOICES:-$LIMIT}
            opts=$(printf '%s' "$opts" | tr '\n|' '  ')
            if [ -w "$NODE" ]; then support=1; else support=0; fi
            desired=$(cat "$ST/desired/$key" 2>/dev/null)
            printf 'KNOB|%s|%s|%s|%s|%s|%s\n' "$key" "$support" "$curr" "${desired:--}" "$opts" "$UNIT"
        else
            printf 'KNOB|%s|0|unsupported|-|-|-\n' "$key"
        fi
    done
    for x in "$SYSROOT/block/zram0/disksize" "$SYSROOT/block/zram0/comp_algorithm" "$SYSROOT/kernel/mm/lru_gen/enabled"; do
        [ -r "$x" ] && printf 'METRIC|%s|%s\n' "${x##*/}" "$(st_read "$x")"
    done
    rom=$(getprop ro.miui.ui.version.name 2>/dev/null)
    [ -n "$rom" ] && [ "$rom" != null ] && printf 'METRIC|rom_flavor|MIUI/HyperOS %s\n' "$rom" || printf 'METRIC|rom_flavor|AOSP / other\n'
    [ -r "$PROCROOT/meminfo" ] && awk '/^(MemTotal|MemAvailable|SwapTotal|SwapFree):/{printf "METRIC|%s|%s kB\n",$1,$2}' "$PROCROOT/meminfo"
    if st_gpu_dir; then
        [ -r "$GPU_DIR/cur_freq" ] && printf 'METRIC|gpu_clock|%s Hz\n' "$(st_read "$GPU_DIR/cur_freq")"
    fi
}
st_onboot(){
    st_boot_check || return 1
    for p in "$ST/desired/"*; do
        [ -f "$p" ] || continue
        key=${p##*/}
        case "$key" in gpu_governor|gpu_min|gpu_max|swappiness|cache_pressure|page_cluster|dirty_ratio|dirty_background|watermark|io_scheduler|io_readahead|sched_autogroup|dt2w|tcp_ecn) : ;; *) continue ;; esac
        val=$(cat "$p" 2>/dev/null)
        (st_apply "$key" "$val") >/dev/null 2>&1 || printf 'STUDIO_WARNING|%s\n' "$key"
    done
}
st_all_reset(){
    for p in "$ST/desired/"*; do
        [ -f "$p" ] || continue
        key=${p##*/}
        (st_reset "$key") || :
    done
}
st_apps(){
    pkg=$1; bucket=$2
    case "$pkg" in ''|*[!a-zA-Z0-9_.]*) st_fail 'Invalid package name' ;; esac
    case "$bucket" in active|working_set|frequent|rare|restricted) : ;; *) st_fail 'Invalid standby bucket' ;; esac
    # Important apps and root managers are deliberately excluded.
    case "$pkg" in android|com.android.*|*magisk*|*kernelsu*|*ksunext*|*sukisu*|*apatch*|*mmrl*|*launcher*|*inputmethod*) st_fail 'Protected system / root package' ;; esac
    pm path "$pkg" >/dev/null 2>&1 || st_fail 'App is not installed'
    mkdir -p "$ST/buckets" || st_fail 'Cannot prepare app data'
    [ -f "$ST/buckets/$pkg" ] || am get-standby-bucket "$pkg" > "$ST/buckets/$pkg" 2>/dev/null || :
    am set-standby-bucket "$pkg" "$bucket" >/dev/null 2>&1 || st_fail 'Android refused standby bucket'
    observed=$(am get-standby-bucket "$pkg" 2>/dev/null | tr -d '\r\n')
    st_ok "App $pkg standby bucket set to $bucket (reported $observed)"
}
st_animation(){
    k=$1; value=$2
    case "$k" in window_animation_scale|transition_animation_scale|animator_duration_scale) : ;; *) st_fail 'Unknown animation control' ;; esac
    case "$value" in 0|0.5|1|1.5) : ;; *) st_fail 'Unsupported animation scale' ;; esac
    st_boot_check || st_fail 'Cannot save settings'
    orig=$(settings get global "$k" 2>/dev/null)
    mkdir -p "$ST/android_original" || st_fail 'Cannot save Android settings'
    [ -f "$ST/android_original/$k" ] || printf '%s\n' "$orig" > "$ST/android_original/$k"
    settings put global "$k" "$value" >/dev/null 2>&1 || st_fail 'Android rejected animation scale'
    actual=$(settings get global "$k" 2>/dev/null)
    [ "$actual" = "$value" ] || st_fail 'Android did not verify animation value'
    printf '%s\n' "$value" > "$ST/desired/$k"
    st_ok "$k=$value"
}
st_animation_reset(){
    key=$1
    case "$key" in window_animation_scale|transition_animation_scale|animator_duration_scale) : ;; *) st_fail 'Unknown animation control' ;; esac
    [ -f "$ST/android_original/$key" ] || { st_ok 'Already default'; return; }
    old=$(cat "$ST/android_original/$key" 2>/dev/null)
    if [ "$old" = null ] || [ -z "$old" ]; then settings delete global "$key" >/dev/null 2>&1 || :; else settings put global "$key" "$old" >/dev/null 2>&1 || st_fail 'Restore failed'; fi
    rm -f "$ST/android_original/$key" "$ST/desired/$key"
    st_ok "$key restored"
}
st_ble_scan(){
    val=$1
    case "$val" in 0|1) : ;; *) st_fail 'Invalid BLE scanning setting' ;; esac
    st_boot_check || st_fail 'Cannot save BLE snapshot'
    key=ble_scan_always_enabled
    old=$(settings get global "$key" 2>/dev/null)
    [ "$old" = null ] && st_fail 'BLE always-scan setting unavailable on this ROM'
    mkdir -p "$ST/android_original" || st_fail 'Cannot save BLE setting'
    [ -f "$ST/android_original/$key" ] || printf '%s\n' "$old" > "$ST/android_original/$key"
    settings put global "$key" "$val" >/dev/null 2>&1 || st_fail 'ROM refused BLE scanning change'
    got=$(settings get global "$key" 2>/dev/null)
    [ "$got" = "$val" ] || st_fail 'ROM did not verify BLE scanning setting'
    printf '%s\n' "$val" > "$ST/desired/$key"
    st_ok "BLE scanning while Bluetooth OFF set to $val"
}
st_ble_reset(){
    key=ble_scan_always_enabled
    [ -r "$ST/android_original/$key" ] || { st_ok 'BLE already stock'; return; }
    old=$(cat "$ST/android_original/$key" 2>/dev/null)
    if [ "$old" = null ] || [ -z "$old" ]; then settings delete global "$key" >/dev/null 2>&1 || st_fail 'BLE restore failed'; else settings put global "$key" "$old" >/dev/null 2>&1 || st_fail 'BLE restore failed'; fi
    rm -f "$ST/android_original/$key" "$ST/desired/$key"
    st_ok 'BLE restored'
}
case "${1:-}" in
    list|status) st_list ;;
    set) st_apply "${2:-}" "${3:-}" ;;
    reset) st_reset "${2:-}" ;;
    reset-all) st_all_reset; st_ble_reset >/dev/null 2>&1 || :; for k in window_animation_scale transition_animation_scale animator_duration_scale; do st_animation_reset "$k" >/dev/null 2>&1 || :; done; st_ok 'All reversible Studio controls restored where supported' ;;
    boot) st_onboot ;;
    app-bucket) st_apps "${2:-}" "${3:-}" ;;
    animation) st_animation "${2:-}" "${3:-}" ;;
    animation-reset) st_animation_reset "${2:-}" ;;
    ble-set) st_ble_scan "${2:-}" ;;
    ble-reset) st_ble_reset ;;
    ble-status) printf 'BLE|%s\n' "$(settings get global ble_scan_always_enabled 2>/dev/null)" ;;
    animation-status) for k in window_animation_scale transition_animation_scale animator_duration_scale; do printf 'ANIM|%s|%s\n' "$k" "$(settings get global "$k" 2>/dev/null)"; done ;;
    *) st_fail 'Valid studio commands: list/set/reset/reset-all/boot/app-bucket/animation/animation-reset/animation-status' ;;
esac
